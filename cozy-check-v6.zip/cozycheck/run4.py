"""Cozy Town check, stage 'run4' (check version 6, 17 Oct 2026): lines N15 to N41 for the run-4 jobs.
Every line starts as FAIL and passes only on proof measured in a test copy. Nothing here is ever made weaker.
The one clock is faked in a test copy by replacing the game's realMs() (window.__setClock / __clockMs in crawl.INSTR); the real date by realDate() as in night 3.
A line whose job is not built yet says so and FAILS."""
import asyncio, json, os, re, time
from harness import md5b
from crawl import INSTR
from checks import start_from_save, weight_static, compare_static, parse_limits
from night3 import fx, begin, L, guarded, fake_date_build
from look4 import n30, n31, n32
from map4 import n26
from gran4 import n24
from small4 import n27, n29, n35, n41
from house4 import n33, n34
from hol4 import n20, n21, n22
from pets4 import n28
from furn4 import n36
from tut4 import n38

HERE = os.path.dirname(os.path.abspath(__file__))
DAYRE = re.compile(r'\bDay \d')
def hm(t): H = int(t); M = int((t - H) * 60); return f'{H}:{M:02d}'

# ---------------- N15 one clock ----------------
WRAP = "()=>{if(window.__sgw)return;window.__sgw=1;const f0=startGame;startGame=function(){const t0=performance.now();try{return f0.apply(this,arguments);}finally{window.__loadMs=performance.now()-t0;}};}"
async def n15(run, live_w, new_wb, FIX):
    probs = []; det = []
    src = new_wb.decode('utf-8', 'replace'); k = src.find('const COZY_BUILD='); code = src[k:] if k >= 0 else src
    if 'function realMs' not in code or 'function clockAt' not in code or 'function msAt' not in code: return False, 'the game has no one clock yet (realMs / clockAt / msAt)'
    bad = re.findall(r"Day \$\{|'Day '|\"Day \"|day '\+|· Day \d|Day '\+", code)
    det.append(f'the code writes a day number in {len(bad)} places')
    if bad: probs.append(f'the code still writes a day number: {bad[:3]}')
    a58 = fx(FIX, 'save-prerun4-day58.json'); a1 = fx(FIX, 'save-prerun4-day1.json')
    if not a58 or not a1: return False, 'the day-58 / day-1 saves (save-prerun4-day58.json / save-prerun4-day1.json) are missing from the kit'
    # A: the day-58 save on an iPad; B: the day-1 save on a PC in dark mode
    A = await run.open(new_wb, 'web', 'ipad-landscape', 'light', 'n15-A', save=dict(a58, name='ZZTEST-CLKA')); await A.manual(); await A.ev(WRAP); await start_from_save(A); await A.ev(INSTR); await A.step(6)
    B = await run.open(new_wb, 'web', 'pc-1366', 'dark', 'n15-B', save=dict(a1, name='ZZTEST-CLKB')); await B.manual(); await B.ev(WRAP); await start_from_save(B); await B.ev(INSTR); await B.step(6)
    ja = await A.ev("()=>({day:S.day,now:clockNow().day,ms:window.__loadMs,coins:S.coins,items:S.home.items.length,pets:S.pets.length,job:S.job,order:!!(S.ds&&S.ds.o),skills:S.skills,garden:S.garden.map(x=>x&&x.seed?[x.seed,x.g]:null),name:S.name})")
    jb = await B.ev("()=>({day:S.day,now:clockNow().day,ms:window.__loadMs,coins:S.coins,name:S.name})")
    det.append(f"the day-58 save loaded in {ja['ms']:.0f} ms and jumped once to the shared day (the clock's day); the day-1 save loaded in {jb['ms']:.0f} ms and jumped to the same day: {ja['day'] == jb['day']}")
    if ja['day'] != ja['now'] or ja['day'] == 58 or jb['day'] != jb['now'] or jb['day'] == 1 or ja['day'] != jb['day']: probs.append('the saves did not jump to the shared day')
    if not (ja['ms'] < 1000 and jb['ms'] < 1000): probs.append('a save took 1 s or more to load')
    sk_same = all((ja['skills'] or {}).get(k, {}).get('lv') == v.get('lv') for k, v in (a58.get('skills') or {}).items())
    gd = [x for x in a58['garden'] if x and x.get('seed')]; gn = [x for x in ja['garden'] if x]
    g_same = len(gd) == len(gn) and all(a['seed'] == b[0] and b[1] >= a['g'] for a, b in zip(gd, gn))
    keep = ja['coins'] >= a58['coins'] and ja['items'] == len(a58['home']['items']) and ja['pets'] == len(a58['pets']) and ja['job'] == a58['job'] and ja['order'] and sk_same and g_same and ja['name'] == 'ZZTEST-CLKA'
    det.append(f"after the jump: coins {a58['coins']} -> {ja['coins']}, furniture {ja['items']} of {len(a58['home']['items'])}, pets {ja['pets']} of {len(a58['pets'])}, job {ja['job']} with its order {ja['order']}, skills kept {sk_same}, garden plants kept {g_same} ({gn})")
    if not keep: probs.append('the day-58 save lost something in the jump')
    # the same time, weekday and weather on two devices whose clocks are 1 s apart, at three moments
    D = ja['day']; rows = []
    for dd, h in ((0, 10.0), (0, 22.5), (3, 14.0)):
        for g, off in ((A, 0), (B, 1000)): await g.ev("([d,h,o])=>__clockMs(msAt(d,h)+o)", [D + dd, h, off])
        for _ in range(3): await A.step(4); await B.step(4)
        ra = await A.ev("()=>({t:S.time,wd:wdName(),wx:WX.cur,day:S.day,chip:$('clock').textContent+' '+$('dayN').textContent})"); rb = await B.ev("()=>({t:S.time,wd:wdName(),wx:WX.cur,day:S.day,chip:$('clock').textContent+' '+$('dayN').textContent})")
        same = abs(ra['t'] - rb['t']) <= 1 / 6 and ra['wd'] == rb['wd'] and ra['wx'] == rb['wx'] and ra['day'] == rb['day']
        rows.append(f"{'+%d d ' % dd if dd else ''}{hm(h)}: A {hm(ra['t'])} {ra['wd'][:3]} {ra['wx']} / B {hm(rb['t'])} {rb['wd'][:3]} {rb['wx']}{'' if same else ' DIFFERENT'}")
        if not same: probs.append(f'two players differ at {hm(h)}')
        if not re.match(r'^\d{1,2}:\d\d (🏆 )?(Mon|Tue|Wed|Thu|Fri|Sat|Sun)$', ra['chip']): probs.append(f"the clock chip says {ra['chip']!r}")   # the time and the weekday only (the Pet Show trophy marks Saturdays since night 3); never a day number
        if dd == 0 and h == 10.0: await A.shot('one-clock-A', both=False); await B.shot('one-clock-B', both=False)
    det.append('two devices 1 s apart: ' + '; '.join(rows))
    # in bed you wait for 7:00 on a sleep screen; no skip; the morning line has no day number
    bed = await A.ev("""(D)=>{__setClock(D,22.0);__goto('home');__run(2);if(![...HOME_ITEMS.values()].some(r=>FURN[r.it.t].use==='sleep')){S.home.items.push({u:'zzbed',t:'bed',c:'#ff9ec4',x:-4.6,z:-3.85,r:0});rebuildHome();}   /* (the save has no bed: one is placed for the test) */
      const rec=[...HOME_ITEMS.values()].find(r=>FURN[r.it.t].use==='sleep');if(!rec)return {err:'no bed at home'};
      P.x=rec.g.position.x+1;P.z=rec.g.position.z;window.__lastToast='';rec.inter.act();__run(2);const t0=S.time;__run(120);const el=$('zzScr'),on=!!(el&&!el.hidden),r=on?$('zzUp').getBoundingClientRect():null;
      return {inBed:zzIn(),t0,t1:S.time,scr:on,txt:on?el.textContent:'',btn:r?[Math.round(r.width),Math.round(r.height)]:null,skipped:S.time>=7&&S.time<21};}""", D)
    if bed.get('err'): probs.append(bed['err']); det.append(bed['err'])
    else:
        await A.shot('sleep-screen', both=True)
        morn = await A.ev("(D)=>{window.__lastToast='';__setClock(D+1,7.02);__run(3);const el=$('zzScr');return {inBed:zzIn(),toast:window.__lastToast||'',scr:!!(el&&!el.hidden)};}", D)
        det.append(f"in bed at {hm(bed['t0'])}: still in bed after 6 s {bed['inBed']} (clock {hm(bed['t1'])}, skipped {bed['skipped']}), sleep screen {bed['scr']} says {bed['txt'][:40]!r}, Wake up button {bed['btn']} px; at 7:02: in bed {morn['inBed']}, screen {morn['scr']}, toast {morn['toast'][:40]!r}")
        if not (bed['inBed'] and bed['scr'] and not bed['skipped'] and 22 <= bed['t1'] < 23 and bed['btn'] and min(bed['btn']) >= 44): probs.append('the bed does not wait for 7:00 on a sleep screen')
        if morn['inBed'] or morn['scr'] or not morn['toast'].startswith('Good morning') or DAYRE.search(morn['toast']) or re.search(r'day \d', morn['toast'], re.I): probs.append(f"the morning did not come right: {morn['toast']!r}")
    # no "Day N" anywhere on the screen: the clock chip, the phone's home, calendar and messages
    tx = await A.ev("""()=>{const out={};__setClock(null,9.7);__run(2);updHud(true);out.hud=$('stats').innerText;openPhone();__run(1);out.home=$('card').innerText;openPhone('cal');__run(1);out.cal=$('card').innerText;openPhone('msg','ro');__run(1);out.msg=$('card').innerText;closePanel();
      out.chip=$('clock').textContent+' '+$('dayN').textContent;return out;}""")
    await A.ev("()=>{openPhone('cal');}"); await A.step(2); await A.shot('phone-calendar-no-day-numbers', both=False); await A.ev("()=>closePanel()")
    shown = [k for k in ('hud', 'home', 'cal', 'msg') if DAYRE.search(tx[k] or '')]
    det.append(f"the clock chip says {tx['chip']!r}; 'Day N' on the screen: {shown or 'nowhere'}")
    if shown or not re.match(r'^\d{1,2}:\d\d (Mon|Tue|Wed|Thu|Fri|Sat|Sun)$', tx['chip']): probs.append(f'a day number shows on the screen: {shown}')
    errs = A.errors + B.errors; await run.close(A); await run.close(B)
    if errs: probs.append(f'browser errors: {errs[:2]}')
    return not probs, '; '.join(det) + (f' | PROBLEMS: {probs}' if probs else '')

# ---------------- N16 grey sky in bad weather ----------------
SKY_JS = """([w,h])=>{__goto('city');__setClock(null,h);wxForce(w);__run(10);const T=skyU.top.value,Bm=skyU.bot.value,a={},b={};T.getHSL(a);Bm.getHSL(b);
  return {top:'#'+T.getHexString(),bot:'#'+Bm.getHexString(),st:+a.s.toFixed(2),sb:+b.s.toFixed(2),bt:+(T.b-Math.max(T.r,T.g)).toFixed(2),bb:+(Bm.b-Math.max(Bm.r,Bm.g)).toFixed(2),sun:!!sunSprite.visible,rain:!!(RAINM&&RAINM.visible),snow:!!(SNOWM&&SNOWM.visible),cur:WX.cur};}"""
def grey(r): return r['st'] <= .3 and r['sb'] <= .3 and r['bt'] < .12 and r['bb'] < .12   # low saturation, and blue never clearly above red and green
async def n16(run, new_wb, FIX):
    save = fx(FIX, 'save-prenight3-pets.json'); probs = []; det = []
    g = await begin(run, new_wb, 'ipad-landscape', 'n16-sky', save)
    if not await g.ev("()=>typeof WX_SKY!=='undefined'&&typeof WX!=='undefined'&&('sky' in WX)&&typeof __setClock==='function'"):
        await run.close(g); return False, 'the game has no grey-sky weather (WX_SKY / WX.sky) yet'
    rows = []
    for wx in ('cloudy', 'rain', 'snow'):
        for h in (8, 12, 18, 23):
            r = await g.ev(SKY_JS, [wx, h]); ok = grey(r)
            rows.append(f"{wx} {h}:00 {r['top']}/{r['bot']}{'' if ok else ' NOT GREY'}{' SUN SHOWING' if r['sun'] else ''}")
            if not ok: probs.append(f"{wx} at {h}:00: sky {r['top']}/{r['bot']}")
            if r['sun']: probs.append(f'the sun shows in {wx} at {h}:00')
            if (wx == 'rain' and not r['rain']) or (wx == 'snow' and not r['snow']): probs.append(f'no {wx} falls at {h}:00')
            if h in (12, 23): await g.ev("()=>{P.x=-22;P.z=12;P.yaw=Math.PI;P.pitch=.05;}"); await g.step(4); await g.shot(f'sky-{wx}-{h}', both=False)
    det.append('; '.join(rows))
    # a sunny day: the sky is blue again (the grey is not stuck)
    s = await g.ev(SKY_JS, ['sunny', 12]); det.append(f"sunny 12:00 {s['top']} sun {s['sun']}")
    if grey(s) or not s['sun']: probs.append('the sunny sky is not blue, or the sun is missing')
    # the change into rain (the last hour of the block before it fades): rain may only fall under a grey sky
    fade = await g.ev("""()=>{wxForce(null);const d0=S.day;let hit=null;for(let d=d0;d<d0+400&&!hit;d++)for(let b=0;b<8;b++){const nd=b===7?d+1:d,nb=b===7?0:b+1;if(wxAt(d,b*3+1.5)==='sunny'&&wxAt(nd,nb*3+1.5)==='rain'){hit=[d,b];break;}}
      if(!hit)return {err:'no sunny-to-rain change found in 400 days'};const out=[];for(const f of [.05,.2,.35,.5,.65,.8,.95]){__setClock(hit[0],hit[1]*3+2+f);__run(10);const T=skyU.top.value,a={};T.getHSL(a);
        out.push({f,rain:!!(RAINM&&RAINM.visible),s:+a.s.toFixed(2),bt:+(T.b-Math.max(T.r,T.g)).toFixed(2),top:'#'+T.getHexString(),sun:!!sunSprite.visible});}
      return {hit,out};}""")
    if fade.get('err'): probs.append(fade['err']); det.append(fade['err'])
    else:
        bad = [o for o in fade['out'] if o['rain'] and (o['s'] > .3 or o['bt'] >= .12 or o['sun'])]
        det.append('a sunny-to-rain change (day %d, block %d), minutes into the fading hour: ' % tuple(fade['hit']) + ', '.join(f"+{round(o['f'] * 60)} min rain {o['rain']} sky {o['top']}" for o in fade['out']))
        if bad: probs.append(f'rain fell under a blue sky during the change: {bad[:2]}')
        if not any(o['rain'] for o in fade['out']): probs.append('no rain fell by the end of the fading hour')
    await g.ev("()=>wxForce(null)")
    errs = g.errors[:]; await run.close(g)
    if errs: probs.append(f'browser errors: {errs[:2]}')
    return not probs, '; '.join(det) + (f' | PROBLEMS: {probs}' if probs else '')

# ---------------- N17 updates ----------------
async def n17(run, live_w, new_wb, FIX):
    probs = []; det = []
    src = new_wb.decode('utf-8', 'replace'); m = re.search(r'const COZY_BUILD=(\d+);', src)
    if not m or 'function updCalm' not in src: return False, 'the game has no calm-moment update (updCalm) yet'
    stamp = int(m.group(1)); mk = lambda n, tag: src.replace(f'const COZY_BUILD={stamp};', f'const COZY_BUILD={stamp + n};/*{tag}*/', 1).encode()
    newer = mk(1, 'run4 N17 newer'); newer2 = mk(2, 'run4 N17 newer again')
    save = dict(fx(FIX, 'save-prenight3-pets.json'), name='ZZTEST-UPD')
    g = await run.open(new_wb, 'web', 'ipad-landscape', 'light', 'n17-upd', save=save); await start_from_save(g); await g.ev(INSTR); await g.step(6)
    on = await g.ev("()=>({on:UPD.on,web:!!(window.WEBNET&&WEBNET.on)})")
    if not on['on']: await run.close(g); return False, f'the update check is off in the test copy ({on})'
    g.box['newer'] = newer
    # busy moments: the phone open, then a scene: the newer file is found but nothing happens
    r1 = await g.ev("()=>new Promise(res=>{S.coins=777;window.__lastToast='';UPD.last=-1e9;openPhone();updCheck().then(()=>setTimeout(()=>res({newer:!!UPD.newer,toast:window.__lastToast,go:UPD.go,note:UPD.note||0}),2600));})")
    r2 = await g.ev("()=>new Promise(res=>{closePanel();window.__lastToast='';CUT={test:1};setTimeout(()=>{const o={newer:!!UPD.newer,toast:window.__lastToast,go:UPD.go};CUT=null;res(o);},2600);})")
    det.append(f"a newer file found while the phone was open: update started {r1['go']} (toast {r1['toast'][:30]!r}); during a scene: started {r2['go']}")
    if not r1['newer']: probs.append('the newer file was not found')
    if r1['go'] or r2['go'] or 'Updating' in r1['toast'] or 'Updating' in r2['toast']: probs.append('the game updated during a card or a scene')
    # calm: the note shows, then the game saves and reloads by itself
    r3 = None
    try:
        r3 = await g.ev("()=>new Promise(res=>{const t0=performance.now();let seen='';const iv=setInterval(()=>{if(/Updating/.test(window.__lastToast||''))seen=window.__lastToast;if(UPD.go||performance.now()-t0>9000){clearInterval(iv);res({toast:seen,go:UPD.go,ms:Math.round(performance.now()-t0)});}},100);})")
    except Exception as e: r3 = {'toast': '?', 'go': 'page went away: ' + repr(e)[:60], 'ms': -1}
    try:
        await g.page.wait_for_function("()=>typeof $==='function'&&$('tPlay')&&!$('tPlay').disabled&&typeof COZY_BUILD!=='undefined'", timeout=120000); await g.manual()
        after = await g.ev("()=>({build:COZY_BUILD,msg:($('tUpd')||{}).textContent||'',title:!$('title').hidden,coins:(()=>{try{return JSON.parse(localStorage.getItem('cozytown-save-1')).coins}catch(e){return null}})(),tried:(()=>{try{return (JSON.parse(sessionStorage.getItem('cozytown-update'))||{}).tried||[]}catch(e){return []}})()})")
    except Exception as e: after = {'build': None, 'msg': '', 'title': False, 'coins': None, 'tried': [], 'err': repr(e)[:80]}
    det.append(f"calm: note {r3['toast'][:34]!r} then reload after {r3['ms']} ms; the page now runs version {after['build']} (title {after['title']}, says {after['msg']!r}); the save made first has coins {after['coins']}; tried this session: {len(after['tried'])}")
    if not (r3 and 'Updating' in (r3['toast'] or '')): probs.append('no "Updating Cozy Town" note before the reload')
    if after['build'] != stamp + 1 or not after['title'] or 'updated' not in after['msg']: probs.append(f"the game did not reload into the newer file ({after})")
    if after['coins'] != 777: probs.append('the game did not save before reloading')
    await g.shot('after-update-title', both=False)
    # the loop guard: the same version never twice (a version already tried only shows the button)
    g.box['newer'] = newer2
    r4 = await g.ev("(t)=>new Promise(res=>{const id=updRead(t).id,o=(()=>{try{return JSON.parse(sessionStorage.getItem('cozytown-update'))||{}}catch(e){return {}}})();o.tried=(o.tried||[]).concat(id);sessionStorage.setItem('cozytown-update',JSON.stringify(o));UPD.last=-1e9;UPD.newer=null;\n      updCheck().then(()=>setTimeout(()=>{const b=$('updBtn');res({newer:!!UPD.newer,go:UPD.go,btn:!!(b&&!b.hidden),build:COZY_BUILD});},1800));})", newer2.decode('utf-8', 'replace'))
    det.append(f"a version already tried this session: found {r4['newer']}, reloaded {r4['go']}, the button shows instead {r4['btn']}")
    if r4['go'] or not r4['newer'] or not r4['btn']: probs.append('the loop guard failed (a tried version reloaded again, or no button)')
    g.box['newer'] = None
    # an older-version player (the live game sends no stamp) shows "⏳ older version" by the name: in the friends list and on the name tag
    await start_from_save(g); await g.ev(INSTR)
    o = await begin(run, live_w, 'pc-1366', 'n17-old', dict(fx(FIX, 'save-prenight3-pets.json'), name='ZZTEST-OLDV', px=-15.5))
    for _ in range(8): await g.step(6); await o.step(6); await asyncio.sleep(.25)
    tag = await g.ev("()=>{const a=[...MP.peers.values()].find(p=>p.nm==='ZZTEST-OLDV');if(!a)return {found:false};openPhone('mp');const html=$('card').innerHTML;closePanel();return {found:true,old:!!a.old,tag:a.av&&a.av.tag?a.av.tag.userData.txt:'',list:/older version/.test(html)};}")
    mine = await o.ev("()=>{const a=[...MP.peers.values()].find(p=>p.nm==='ZZTEST-UPD');return a?{found:true,av:!!a.av}:{found:false};}")
    det.append(f"an old-version friend: seen {tag.get('found')}, marked old {tag.get('old')}, name tag {tag.get('tag')!r}, in the friends list {tag.get('list')}; the old version still sees the new player: {mine}")
    if not (tag.get('found') and tag.get('old') and 'older version' in (tag.get('tag') or '') and tag.get('list') and mine.get('av')): probs.append('the older-version tag is missing (or the old version lost sight of the new one)')
    await g.shot('older-version-tag', both=False)
    errs = [e for e in g.errors + o.errors if 'Execution context' not in e]; await run.close(g); await run.close(o)
    if errs: probs.append(f'browser errors: {errs[:2]}')
    return not probs, '; '.join(det) + (f' | PROBLEMS: {probs}' if probs else '')

# ---------------- N18 the same for everyone ----------------
SIG_JS = """()=>{const h=s=>{let x=0;for(let i=0;i<s.length;i++)x=(Math.imul(x,31)+s.charCodeAt(i))|0;return (x>>>0).toString(36);};
  let geo='';if(typeof HOL!=='undefined'&&HOL.g)HOL.g.traverse(o=>{if(!o.isMesh||!o.geometry)return;for(const k of ['position','ctr']){const a=o.geometry.attributes[k];if(!a)continue;let t=0;for(let i=0;i<a.array.length;i+=7)t=(Math.imul(t,31)+Math.round(a.array[i]*20))|0;geo+=k+(t>>>0).toString(36)+';';}});
  const C=LOC.city,lane=(C.lane||[]).map(lp=>{const o=LANE.own[lp.j];return o?[o.nm,o.big?1:0,o.gd||'']:null;}),drawn=(C.lane||[]).map(lp=>lp.gdKey||'');
  const gran=typeof GRAN!=='undefined'&&GRAN.g&&typeof granPose==='function'?GRAN.g.map(q=>{const ps=granPose(q.i,realMs());return [ps.k,ps.stop,q.on?1:0,q.sitting?1:0];}):null;   /* each grandma's turn, place, out and sitting (run 4, job 8's grandmas) */
  return {t:S.time,wd:wdName(),wx:WX.cur,hol:typeof HOL!=='undefined'?HOL.cur:null,holN:typeof HOL!=='undefined'?HOL.n:null,holSig:h(geo),litter:LITTER.map(l=>[l.k,Math.round(l.x*10),Math.round(l.z*10)]).sort(),lane,drawn,gran};}"""
STAIR_JS = """()=>{const L=LOC.__L__;const out=[];if(!L||!L.shellG)return out;const rc=new THREE.Raycaster(),W=L===LOC.home?HOMEW:L.W,H=3.2;
  /* looks along the stair slope, from eyes 1.5 m above the steps: up the stairs from the bottom, and back down through the doorway from the middle and the top (that is where a window hung) */
  const looks=(x0,down)=>{const o=[];for(const [t,first,nm] of [[.05,1,down?'from the top looking down the stairs':'from the bottom looking up the stairs'],[.5,0,down?'from the middle looking back up to the doorway':'from the middle looking back down to the doorway'],[.95,0,down?'from the bottom looking up to the doorway':'from the top looking down to the doorway']]){
    const x=x0-4.2*t,y=(down?-3.2*t:3.2*t)+1.5,v=new THREE.Vector3(first?-4.2:4.2,down?(first?-3.2:3.2):(first?3.2:-3.2),0).normalize();   /* along the slope: away from the doorway on the first look, back towards it on the others */
    rc.set(new THREE.Vector3(x,y,L.oz),v);const hits=rc.intersectObject(L.shellG,true).filter(h=>h.distance>.05&&!(h.object.material&&h.object.material.side===THREE.BackSide));o.push({fl:down?2:1,nm,d:+(hits.length?hits[0].distance:99).toFixed(2)});}return o;};
  out.push(...looks(L.ox-W,false));if(L.up)out.push(...looks(L.ox+UPX-W,true));return out;}"""
async def n18(run, live_w, new_wb, FIX):
    probs = []; det = []
    if b'gardenSnap' not in new_wb or b'W:HOMEW,D:HOMED' not in new_wb: return False, 'the game does not send the room size and the garden yet (job 2)'
    fb = fake_date_build(new_wb, '2026-10-25T12:00:00') or new_wb
    big = fx(FIX, 'save-prenight3-bighouse.json'); pets = fx(FIX, 'save-prenight3-pets.json')
    A = dict(big, name='ZZTEST-SAMEA'); A['garden'] = [{'seed': 'tomato', 'g': .45, 'w': big['day']}, {'seed': 'carrot', 'g': 1, 'w': big['day'] - 1}, {}, {}, {}, {}]
    B = dict(pets, name='ZZTEST-SAMEB', px=(pets.get('px') or -17) + 1.5)
    a = await begin(run, fb, 'ipad-landscape', 'n18-A', A); b = await begin(run, fb, 'pc-1366', 'n18-B', B)
    base = await a.ev("()=>msAt(clockNow().day,14.2)")
    for g in (a, b): await g.ev("(ms)=>__clockMs(ms)", base); await g.ev("()=>__goto('city')")
    for _ in range(8): await a.step(6); await b.step(6); await asyncio.sleep(.25)
    sa = await a.ev(SIG_JS); sb = await b.ev(SIG_JS)
    diff = [k for k in ('wd', 'wx', 'hol', 'holN', 'holSig', 'litter', 'lane', 'gran') if sa[k] != sb[k]]
    if abs(sa['t'] - sb['t']) > 1 / 6: diff.append('time')
    det.append(f"iPad and PC: time {hm(sa['t'])} / {hm(sb['t'])}, {sa['wd']} / {sb['wd']}, weather {sa['wx']} / {sb['wx']}, holiday {sa['hol']} with {sa['holN']} / {sb['holN']} pieces (same shapes {sa['holSig'] == sb['holSig']}), trash spots {len(sa['litter'])} same {sa['litter'] == sb['litter']}, Friends Lane lots (owner, floors, garden) same {sa['lane'] == sb['lane']}, grandmas same {sa['gran'] == sb['gran']}")
    if diff: probs.append(f'different on the two devices: {diff}')
    if not any(sb['drawn']): probs.append("the PC player does not see the iPad player's garden on the lane")
    await a.shot('same-A-lane', both=False); await b.shot('same-B-lane', both=False)
    # B visits A: every piece at the same x, z, turn and floor; the right room size
    await b.ev("()=>closePanel()"); await a.ev("()=>closePanel()")
    r1 = await b.tap('#bPhone'); await b.step(3); await b.wait(300); r2 = await b.tap('#card [data-a="phapp:mp"]'); await b.step(3); await b.wait(300)
    idx = await b.ev("()=>MP.list?MP.list.findIndex(p=>p.nm==='ZZTEST-SAMEA'):-1")
    r3 = await b.tap(f'#card [data-a="mpvisit:{idx}"]') if idx >= 0 else 'no A in the list'
    card = False
    for _ in range(30):
        await b.step(6); await b.wait(200); await a.step(6)
        if not card and await a.center('#kcYes'): card = True; await a.tap('#kcYes')
        if await b.ev("()=>CUR.id==='visit'&&!fading"): break
    await b.step(12); await a.step(6)
    vis = await b.ev("()=>{const L=LOC.visit;return {loc:CUR.id,W:L.W,D:L.D,up:!!L.up,wide:!!L.wide,rows:L.items.children.map(g=>g.userData.row).filter(Boolean).map(r=>[r.t,Math.round(r.x*100),Math.round(r.z*100),r.r,r.fl]).sort()};}")
    host = await a.ev("()=>({W:HOMEW,D:HOMED,big:!!S.bighouse,rows:S.home.items.map(it=>[it.t,Math.round(it.x*100),Math.round(it.z*100),it.r|0,it.f?1:0]).sort()})")
    same = vis['loc'] == 'visit' and vis['rows'] == host['rows'] and vis['W'] == host['W'] and vis['D'] == host['D'] and vis['up'] == host['big'] and not vis['wide']
    det.append(f"B visits A ({r1}/{r2}/{r3}, let in {card}): in {vis['loc']}, room {vis['W'] * 2}x{vis['D'] * 2} (host {host['W'] * 2}x{host['D'] * 2}), upstairs {vis['up']}, {len(vis['rows'])} of {len(host['rows'])} pieces at the same x, z, turn and floor: {vis['rows'] == host['rows']}")
    if not same:
        off = [r for r in host['rows'] if r not in vis['rows']][:3]; probs.append(f'the visitor does not see the same house: missing or moved {off}')
    await b.shot('same-B-visits-A', both=True)
    # the stairs: no wall or window across the view, in A's own house (both floors) and in B's visit
    await a.ev("()=>{__goto('home');__run(2);return null;}"); st_home = await a.ev(STAIR_JS.replace('__L__', 'home'))
    st_vis = await b.ev(STAIR_JS.replace('__L__', 'visit'))
    blocked = [f"home floor {s['fl']} {s['nm']} hits at {s['d']} m" for s in st_home if s['d'] < 3.0] + [f"visit floor {s['fl']} {s['nm']} hits at {s['d']} m" for s in st_vis if s['d'] < 3.0]
    det.append(f"stairs: {len(st_home)} looks in A's house and {len(st_vis)} in B's visit, nearest wall or window {min([s['d'] for s in st_home + st_vis] or [0])} m")
    if not st_home or not st_vis or blocked: probs.append(f'something crosses the view on the stairs: {blocked[:3]}')
    await a.ev("()=>{P.x=LOC.home.ox-HOMEW+1.2;P.z=LOC.home.oz;P.yaw=Math.PI/2;P.pitch=-.15;}"); await a.step(3); await a.shot('stairs-view-home', both=False)
    errs = a.errors + b.errors; await run.close(a); await run.close(b)
    if errs: probs.append(f'browser errors: {errs[:2]}')
    return not probs, '; '.join(det) + (f' | PROBLEMS: {probs}' if probs else '')

# ---------------- N19 Halloween, all of October ----------------
async def n19(run, live_w, new_wb, FIX):
    probs = []; det = []
    if b'const COSTUMES=' not in new_wb or b'SPOOK_WAY' not in new_wb or b'function holPiece' not in new_wb: return False, 'the game has no costumes / Flower Corner spooky path / piece bookkeeping yet (job 3)'
    save = dict(fx(FIX, 'save-prenight3-pets.json'), coins=2000)
    g = await begin(run, new_wb, 'ipad-landscape', 'n19', save)
    async def at(iso, hour, label=None):
        st = await g.ev("([d,h])=>{realDate=()=>new Date(d);__setClock(null,h);holCheck();__run(8);return {cur:HOL.cur,n:HOL.n,open:SPOOK.open(),pieces:HOL.pieces.length,ghosts:HOL.ghosts.length};}", [iso, hour])
        if label: await g.ev("()=>{__goto('city');P.x=-17;P.z=-4.2;P.yaw=0;P.pitch=-.04;}"); await g.step(4); await g.shot(label, both=False)
        return st
    w = {}
    for iso, h, k in (('2026-10-01T00:10:00', 9, 'oct1-day'), ('2026-10-01T00:10:00', 19.5, 'oct1-night'), ('2026-10-31T23:00:00', 12, 'oct31-day'), ('2026-10-31T23:00:00', 22, 'oct31-night'), ('2026-11-01T00:10:00', 12, 'nov1'), ('2026-09-30T23:50:00', 12, 'sep30')):
        w[k] = await at(iso, h, 'halloween-' + k if k in ('oct1-day', 'oct31-night', 'nov1') else None)
    det.append('; '.join(f"{k}: {v['cur']} ({v['n']} pieces, path open {v['open']})" for k, v in w.items()))
    if not all(w[k]['cur'] == 'halloween' and w[k]['n'] > 0 for k in ('oct1-day', 'oct1-night', 'oct31-day', 'oct31-night')): probs.append('Halloween is missing on 1 or 31 October')
    if not (w['oct1-night']['open'] and w['oct31-night']['open'] and not w['oct1-day']['open']): probs.append('the spooky path is not open after 18:00 only')
    if w['nov1']['cur'] is not None or w['nov1']['n'] != 0 or w['sep30']['cur'] is not None: probs.append('something shows on 1 Nov or 30 Sep')
    # costumes: for sale in October, worn over the clothes, sent to others; the shop stops selling after October, what you bought stays wearable
    await at('2026-10-20T12:00:00', 12)
    c = await g.ev("""()=>{__goto('city');openClothes();const html=$('card').innerHTML,forSale=['co_cat','co_dog','co_ghost','co_dino'].filter(k=>html.includes('cloth:'+k));closePanel();
      const c0=S.coins;ACT.cloth('co_cat');const bought=!!(S.wardrobe&&S.wardrobe.co_cat),paid=c0-S.coins;closePanel();
      S.look.co='cat';buildPlayerBody();const legs=PB.legs[0].children.length;const pk=packLook();
      const p=makePerson(lookToPerson(cleanLook(pk))),n1=p.root.children[0].children.length;const q=makePerson(lookToPerson(cleanLook(Object.assign({},pk,{co:null})))),n0=q.root.children[0].children.length;
      return {forSale,bought,paid,co:pk.co,parts:n1-n0,legs,price:CLOTHES.co_cat.p};}""")
    det.append(f"October shop: costumes for sale {c['forSale']}; bought the cat costume for {c['paid']} 🪙 ({c['bought']}); worn: look.co {c['co']!r}, {c['parts']} extra body parts over the clothes")
    if len(c['forSale']) != 4 or not c['bought'] or c['paid'] != c['price'] or c['co'] != 'cat' or c['parts'] < 4: probs.append('costumes are not for sale, bought and worn right')
    await g.ev("()=>{__goto('city');P.x=-17;P.z=-4.2;P.yaw=0;openCreator('edit');}")
    for _ in range(8):
        await g.step(5); await g.wait(150)
        if await g.ev("()=>!!(CR&&CR.av)&&!fading"): break
    await g.step(4); await g.shot('costume-mirror', both=False)
    mir = await g.ev("()=>{const b=document.querySelector('#card .crow[data-k=\"co\"]');const pills=b?[...b.querySelectorAll('.pill')].map(p=>p.textContent):[];const r={row:!!b,pills,on:b?[...b.querySelectorAll('.pill.on')].map(p=>p.dataset.a):[]};if(b){ACT.lk('co:cat');r.off=CR.look.co;ACT.lk('co:cat');r.on2=CR.look.co;}ACT.crcancel();return r;}")
    for _ in range(8):
        await g.step(5); await g.wait(150)
        if await g.ev("()=>!CR&&!fading"): break
    det.append(f"mirror: costume row {mir['row']} {mir['pills']}, tap on the worn costume takes it off ({mir.get('off')!r}), tap again puts it on ({mir.get('on2')!r})")
    if not (mir['row'] and mir.get('off') is None and mir.get('on2') == 'cat'): probs.append('the mirror does not switch the costume with one tap')
    nov = await g.ev("([d,h])=>{realDate=()=>new Date(d);__setClock(null,h);holCheck();__run(4);openClothes();const html=$('card').innerHTML;closePanel();return {sale:['co_dog','co_ghost','co_dino'].filter(k=>html.includes('cloth:'+k)),mine:html.includes('cloth:co_cat'),co:S.look.co};}", ['2026-11-05T12:00:00', 12])
    det.append(f"5 Nov: still for sale {nov['sale']}, the bought one still in the wardrobe {nov['mine']}, still worn {nov['co']!r}")
    if nov['sale'] or not nov['mine'] or nov['co'] != 'cat': probs.append('after October the shop still sells costumes, or a bought one is lost')
    # the path at the Flower Corner: length, inside the corner, 5 kinds; each scare turns you to face it with a shake and a soft sound (only with sound on); once per night
    await at('2026-10-20T12:00:00', 19.5)
    pth = await g.ev("()=>({len:+SPOOK.len.toFixed(2),inside:SPOOK_WAY.every(([x,z])=>x>-23.4&&x<-10.6&&z>-24.5&&z<-7),kinds:[...new Set(SPOOK.spots.map(q=>q.k))],spots:SPOOK.spots.length})")
    det.append(f"the path: {pth['len']} m (the park's was 13.6 m), inside the Flower Corner {pth['inside']}, {pth['spots']} spots with {len(pth['kinds'])} kinds {pth['kinds']}")
    if pth['len'] < 13.6 * 1.2 or not pth['inside'] or len(pth['kinds']) < 5: probs.append('the path is too short, outside the corner or has fewer than 5 kinds')
    await g.ev("()=>{SET.sound=true;AC=AC||{state:'running',currentTime:0,sampleRate:44100,createOscillator(){return{type:'',frequency:{setValueAtTime(){},exponentialRampToValueAtTime(){}},connect(){},start(){},stop(){}}},createGain(){return{gain:{setValueAtTime(){},exponentialRampToValueAtTime(){}},connect(){}}},createBuffer(){return{getChannelData(){return new Float32Array(10)}}},createBufferSource(){return{connect(){},start(){},stop(){},disconnect(){}}},createBiquadFilter(){return{frequency:{},connect(){}}},destination:{}};if(!window.__tn0){window.__tn0=1;const t0=tone;tone=function(){if(SET.sound&&AC)window.__tn++;return t0.apply(this,arguments);};}window.__tn=0;}")   # counts only tones that would really play (tone() itself returns at once with sound off)
    sc = await g.ev("""()=>{const out=[];__goto('city');__setClock(null,19.5);S.spook=null;for(const [i,q] of SPOOK.spots.entries()){SET.sound=i!==1;window.__tn=0;SPOOK.cur=null;P.x=q.x;P.z=q.z;P.yaw=Math.atan2(-(q.px-P.x),-(q.pz-P.z))+2.4;P.freeze=0;SHAKE.t=0;__run(1);
        const c=SPOOK.cur,r={k:q.k,popped:!!c,freeze:P.freeze>0,shake:SHAKE.t>0,tones:window.__tn,vis:!!(c&&c.g.visible)};if(c){__run(16);const d=Math.abs(((P.yaw-c.face+Math.PI)%(2*Math.PI)+2*Math.PI)%(2*Math.PI)-Math.PI);r.faced=+d.toFixed(2);}
        __run(60);P.x+=3;__run(10);P.x-=3;window.__tn=0;__run(10);r.again=!!SPOOK.cur;out.push(r);}
      SET.sound=true;return out;}""")
    bad = [r for r in sc if not (r['popped'] and r['freeze'] and r['shake'] and r['vis'] and r.get('faced', 9) < .2 and not r['again'])]
    snd_on = [r['tones'] > 0 for r in sc if r['k'] != sc[1]['k'] or sc.index(r) != 1]; snd_off = sc[1]['tones']
    det.append('scares: ' + ', '.join(f"{r['k']}: popped {r['popped']}, stopped {r['freeze']}, shake {r['shake']}, faced it (off by {r.get('faced')} rad), {r['tones']} sounds, again {r['again']}" for r in sc))
    if bad: probs.append(f'a scare did not stop you, turn you to face it and shake: {[r["k"] for r in bad]}')
    if not all(r['tones'] > 0 for i, r in enumerate(sc) if i != 1) or snd_off != 0: probs.append(f'the soft sound did not follow the sound setting (off: {snd_off} sounds)')
    await g.ev("()=>{const q=SPOOK.spots[0];S.spook=null;SPOOK.cur=null;P.x=q.x;P.z=q.z;P.yaw=Math.atan2(-(q.px-P.x),-(q.pz-P.z));__run(12);}"); await g.shot('spooky-path-scare', both=False)
    # ghosts all over town, none inside a building; every holiday piece on the ground or hanging on something
    gh = await g.ev("""()=>{const C=LOC.city,G=HOL.ghosts,rects=C.cols.filter(c=>c.cr===undefined&&(c.x2-c.x1)>2.5&&(c.z2-c.z1)>2.5);
      const inside=G.filter(([x,z])=>rects.some(r=>x>r.x1+.2&&x<r.x2-.2&&z>r.z1+.2&&z<r.z2-.2));
      const park=G.filter(([x,z])=>x>-40&&x<-10&&z>8&&z<40).length,lane=G.filter(([x])=>x<-85).length,corner=G.filter(([x,z])=>x>-23.4&&x<-10.6&&z>-24.5&&z<-7).length;
      return {n:G.length,inside:inside.length,park,lane,corner,streets:G.length-park-lane-corner};}""")
    det.append(f"ghosts: {gh['n']} all over town ({gh['streets']} over the streets, {gh['park']} in the park, {gh['lane']} on Friends Lane, {gh['corner']} at the Flower Corner), inside a building: {gh['inside']}")
    if gh['n'] < 30 or gh['inside'] or gh['park'] < 3 or gh['lane'] < 3 or gh['corner'] < 3 or gh['streets'] < 15: probs.append('the ghosts are not all over town (or one is inside a building)')
    PIECES = """()=>{const C=LOC.city,near=(x,z,r)=>C.cols.some(c=>c.cr!==undefined?Math.hypot(x-c.cx,z-c.cz)<c.cr+r:x>c.x1-r&&x<c.x2+r&&z>c.z1-r&&z<c.z2+r);const bad=[];let n=0,h=0;
      for(const p of HOL.pieces){n++;if(p.hang){h++;if(p.k==='garland')continue;if(!p.hang.every(([x,y,z])=>near(x,z,.6)))bad.push(p.k+' at '+p.x.toFixed(1)+','+p.z.toFixed(1)+' hangs on nothing');}
        else{const gap=p.b-p.s;if(gap>.02||gap<-.08)bad.push(p.k+' at '+p.x.toFixed(1)+','+p.z.toFixed(1)+' gap '+gap.toFixed(3));}}
      return {n,h,bad:bad.slice(0,8),nbad:bad.length};}"""
    for iso, nm in (('2026-10-20T12:00:00', 'halloween'), ('2026-12-20T12:00:00', 'christmas'), ('2027-03-28T12:00:00', 'easter')):
        await at(iso, 12); r = await g.ev(PIECES)
        det.append(f"{nm}: {r['n']} pieces written down ({r['h']} hanging), floating or sunk: {r['nbad']}" + (f" {r['bad']}" if r['bad'] else ''))
        if r['n'] < 10 or r['nbad']: probs.append(f'{nm}: a piece floats or hangs on nothing: {r["bad"][:3]}')
    errs = g.errors[:]; await run.close(g)
    # an old-version friend sees the clothes, not the costume (cleanLook drops co); a new-version friend sees the costume
    o = await begin(run, live_w, 'pc-1366', 'n19-old', dict(fx(FIX, 'save-prenight3-pets.json'), name='ZZTEST-OLDC'))
    old = await o.ev("()=>{const l=cleanLook({co:'cat',top:'#ffd45c'});return {co:l.co,top:l.top};}"); await run.close(o)
    det.append(f"an old version reading a costume in presence: co {old['co']!r} (the clothes stay {old['top']})")
    if old['co'] is not None: probs.append('an old version would try to draw the costume')
    if errs: probs.append(f'browser errors: {errs[:2]}')
    return not probs, '; '.join(det) + (f' | PROBLEMS: {probs}' if probs else '')

# ---------------- N23 signs ----------------
SIGNS_JS = """()=>{const out=[],vis=o=>{for(let q=o;q;q=q.parent)if(q.visible===false)return false;return true;},hex=h=>[1,3,5].map(i=>parseInt(h.slice(i,i+2),16));
  const rc=new THREE.Raycaster(),n=new THREE.Vector3(),p=new THREE.Vector3(),q=new THREE.Quaternion(),ux=new THREE.Vector3(),uy=new THREE.Vector3(),o=new THREE.Vector3();rc.camera=camera;
  for(const id in LOC){const L=LOC[id];if(!L.g)continue;setLoc(id);const signs=[];L.g.traverse(m=>{if(m.isMesh&&m.userData.sign)signs.push(m);});
    for(const m of signs){const S0=m.userData.sign,c=S0.c,W=c.width,H=c.height,d=c.getContext('2d').getImageData(0,0,W,H).data,bg=hex(S0.bg);let x1=W,y1=H,x2=-1,y2=-1;
      for(let j=0;j<H;j++)for(let i=0;i<W;i++){const k=(j*W+i)*4;if(Math.abs(d[k]-bg[0])+Math.abs(d[k+1]-bg[1])+Math.abs(d[k+2]-bg[2])>90){if(i<x1)x1=i;if(i>x2)x2=i;if(j<y1)y1=j;if(j>y2)y2=j;}}
      const r={text:S0.text,loc:id,W,H,x1,x2:x2+1,y1,y2:y2+1,cx:(x1+x2+1)/2,cy:(y1+y2+1)/2,crossed:[],coplanar:0,rays:0};
      m.getWorldPosition(p);m.getWorldQuaternion(q);n.set(0,0,1).applyQuaternion(q);ux.set(1,0,0).applyQuaternion(q);uy.set(0,1,0).applyQuaternion(q);
      for(let a=0;a<5;a++)for(let b=0;b<3;b++){const u=x1+(x2+1-x1)*(a+.5)/5,v=y1+(y2+1-y1)*(b+.5)/3,px=(u/W-.5)*S0.w,py=(.5-v/H)*S0.h;
        o.copy(p).addScaledVector(ux,px).addScaledVector(uy,py).addScaledVector(n,1.2);rc.set(o,n.clone().negate());r.rays++;
        const hits=rc.intersectObject(L.g,true).filter(h=>!h.object.isSprite&&vis(h.object)&&!(h.object.material&&h.object.material.side===THREE.BackSide));
        const f=hits[0];if(!f||f.object!==m){const ob=f?f.object:null,col=ob&&ob.material&&ob.material.color?'#'+ob.material.color.getHexString():'?';r.crossed.push((ob?(ob.name||ob.type):'nothing')+' '+col+' at '+(f?f.distance.toFixed(2):'-'));}
        else{const g2=hits.find(h=>h.object!==m);if(g2&&g2.distance-f.distance<.01)r.coplanar++;}}   /* a ray through the plane's own diagonal hits both its triangles: not coplanar with anything */
      out.push(r);}}
  return out;}"""
async def n23(run, live_w, new_wb, FIX):
    probs = []; det = []
    if b'function inkOf' not in new_wb or b'userData.sign=' not in new_wb: return False, 'the game does not fit signs by their inked pixels yet (job 5)'
    save = fx(FIX, 'save-prenight3-pets.json')
    fb = fake_date_build(new_wb, '2026-10-20T12:00:00') or new_wb   # October: the spooky signs stand too
    g = await begin(run, fb, 'ipad-landscape', 'n23-signs', save)
    res = await g.ev(SIGNS_JS); await g.ev("()=>__goto('city')")
    def judge(r):
        W, H = r['W'], r['H']; off = max(abs(r['cx'] - W / 2) / W, abs(r['cy'] - H / 2) / H)
        inside = r['x1'] >= .02 * W and r['x2'] <= .98 * W and r['y1'] >= .02 * H and r['y2'] <= .98 * H
        return off, inside
    bad = []
    for r in res:
        off, inside = judge(r)
        if off > .03 or not inside or r['crossed'] or r['coplanar']: bad.append(f"{r['text']!r} ({r['loc']}): off centre {off * 100:.1f}%, inside {inside}, crossed {sorted(set(r['crossed']))[:2]}, coplanar {r['coplanar']}")
    det.append(f"{len(res)} signs in {len(set(r['loc'] for r in res))} places; the worst off-centre {max(judge(r)[0] for r in res) * 100:.1f}% (limit 3%); crossed or coplanar: {sum(1 for r in res if r['crossed'] or r['coplanar'])}")
    if bad: probs.append(f'signs not clean: {bad[:4]}')
    named = ['🏖 To the beach', '🏰 Knights & castles', '🏆 Pet Show', 'Open after 18:00 🌙', '🍔 Food truck']
    for t in named:
        r = next((r for r in res if r['text'] == t), None)
        if not r: probs.append(f'the sign {t!r} was not found'); continue
        off, inside = judge(r); det.append(f"{t!r}: off centre {off * 100:.1f}%, inside {inside}, nothing crosses it {not r['crossed']}, nothing coplanar {not r['coplanar']}")
    # a font that draws glyphs wider than it measures (a colour emoji on an iPad; this machine has one, so the measurement is bent on purpose): still centred and inside
    bent = await g.ev("""()=>{const P=CanvasRenderingContext2D.prototype,m0=P.measureText;const out={};for(const [nm,k] of [['wider',.7],['narrower',1.35]]){P.measureText=function(t){const r=m0.call(this,t);return {width:r.width*k};};
      const rows=[];for(const t of ['🏖 To the beach','🏰 Knights & castles','🏆 Pet Show','Open after 18:00 🌙','🍔 Food truck','A B C D E F G H I J K L M N O P Q R S T U V W X Y Z']){const s=signPlane(t,3,.6,'#ffffff','#3d2c5e'),c=s.userData.sign.c,W=c.width,H=c.height,d=c.getContext('2d').getImageData(0,0,W,H).data;let x1=W,y1=H,x2=-1,y2=-1;
        for(let j=0;j<H;j++)for(let i=0;i<W;i++){const q=(j*W+i)*4;if(Math.abs(d[q]-255)+Math.abs(d[q+1]-255)+Math.abs(d[q+2]-255)>90){if(i<x1)x1=i;if(i>x2)x2=i;if(j<y1)y1=j;if(j>y2)y2=j;}}
        rows.push({t,off:+Math.max(Math.abs((x1+x2+1)/2-W/2)/W,Math.abs((y1+y2+1)/2-H/2)/H).toFixed(3),inside:x1>=.02*W&&x2+1<=.98*W&&y1>=.02*H&&y2+1<=.98*H});s.material.map.dispose();}
      out[nm]=rows;}P.measureText=m0;return out;}""")
    for nm, rows in bent.items():
        worst = max(r['off'] for r in rows); ok = worst <= .03 and all(r['inside'] for r in rows)
        det.append(f"measureText bent {nm}: {len(rows)} signs, worst off centre {worst * 100:.1f}%, all inside {all(r['inside'] for r in rows)}")
        if not ok: probs.append(f'with a font that draws {nm} than it measures, a sign is off: {[r for r in rows if r["off"] > .03 or not r["inside"]][:2]}')
    # pictures of the named signs
    for nm, loc, x, z, yaw, pitch in (('sign-beach', 'city', 74.5, 0, -Math_PI_2(), .05), ('sign-pet-show', 'city', -34.6, 22, 1.57, .12), ('sign-food-truck', 'city', -27.3, 11.45, 1.57, .35), ('sign-spooky', 'city', -13.2, -5.0, 0, .08)):
        await g.ev("([l,x,z,yaw,pitch])=>{__goto(l);P.x=x;P.z=z;P.yaw=yaw;P.pitch=pitch;}", [loc, x, z, yaw, pitch]); await g.step(4); await g.shot(nm, both=False)
    await g.ev("()=>{__goto('cl_history');P.x=LOC.cl_history.ox-3.2;P.z=LOC.cl_history.oz-2.5;P.yaw=1.57;P.pitch=.05;}"); await g.step(4); await g.shot('sign-history-class', both=False)
    errs = g.errors[:]; await run.close(g)
    if errs: probs.append(f'browser errors: {errs[:2]}')
    return not probs, '; '.join(det) + (f' | PROBLEMS: {probs}' if probs else '')
def Math_PI_2(): return 1.5708

# ---------------- lines whose job is not built yet ----------------
async def todo(what):
    return False, f'not proved: {what} is not built yet (the job is still to come)'

# ---------------- the stage ----------------
async def s_run4(run, d, live_w, new_wb, FIX, limits):
    """Every line below starts as FAIL and passes only when the test copy proves it."""
    tests = [('N15', 'One clock: two players with saves on day 1 and day 58, device clocks 1 s apart, show the same time (within 10 game minutes), the same weekday and the same weather; no "Day" in any text; in bed you wait for 7:00, no skip; an old save jumps once, keeps everything (B1) and loads in under 1 s', lambda: n15(run, live_w, new_wb, FIX)),
             ('N16', 'Rain sky: in rain, snow and cloudy weather the sky top and bottom are grey, never bright blue, at 8:00, 12:00, 18:00 and 23:00', lambda: n16(run, new_wb, FIX)),
             ('N17', 'Updates: a newer file appears while playing -> the game saves and reloads by itself at the next calm moment, never inside a job, scene, class, show, bus ride, shoot, dance round or typing; never twice for one version; an older-version player shows "⏳ older version"', lambda: n17(run, live_w, new_wb, FIX)),
             ('N18', "Same for everyone: an iPad-size player and a PC-size player see the same time, weather, every house's floors and colour, every furniture piece (x, z, turn, floor) on visits, gardens, holiday pieces, ghosts, trash, grandmas; on every house's stairs no wall or window crosses the view", lambda: n18(run, live_w, new_wb, FIX)),
             ('N19', 'Halloween: October 1 and 31 (day and night) show it, 1 Nov doesn\'t; costumes on sale only in October, wearable, seen by others, kept after; the spooky path at the Flower Corner at least 20% longer than the park\'s was, at least 5 scare kinds, each turns you to face it with a small shake and a soft sound only with sound on; ghosts all over town, none inside; every holiday piece touches the ground or a support (gap under 2 cm)', lambda: n19(run, live_w, new_wb, FIX)),
             ('N20', 'Holiday spot: February heart fountain and petals; in the Easter month the bunny and 25 eggs (all 25 -> bunny costume and 50 coins, once a year); December Christmas tree and Santa (10 coins on 1 Dec, 300 on 31 Dec, once per real day); other months the flower garden as before', lambda: n20(run, new_wb, FIX)),
             ('N21', 'New Year: fireworks every game night 28 to 31 Dec; party hats on everyone and confetti on 31 Dec and 1 Jan; nothing on 2 Jan', lambda: n21(run, new_wb, FIX)),
             ('N22', 'School: on 1 Sep balloons around and in the school; a teacher gives the globe once; nothing on 2 Sep', lambda: n22(run, new_wb, FIX)),
             ('N23', 'Signs: every sign\'s text centered (within 3% of the sign) and inside its box with a margin, with and without a colour emoji font; the four named signs clean; no post, roof, light or spike crosses any sign\'s text', lambda: n23(run, live_w, new_wb, FIX)),
             ('N24', 'Grandmas: exactly 3; none by the town houses; they sit on the duck-pond bench feeding the ducks at times, walk to places and talk about them; the same places for two players', lambda: n24(run, new_wb, FIX)),
             ('N25', 'Photographer: one booking plays from the message to the pay on iPad, sideways iPhone and PC; a perfect photo gets 5 stars; a photo with someone cut off gets fewer', lambda: todo('the photographer job (job 15)')),
             ('N26', 'Map: the corner map and 📱 Map draw the town (never one flat colour) on every screen size; the facing arrow turns every frame you turn; the corner map shows wherever it should', lambda: n26(run, new_wb, FIX)),
             ('N27', 'Trash: only cans, paper, peels and cups; picking up still works', lambda: n27(run, new_wb, FIX)),
             ('N28', 'Pet shop: two floors; each kind in its own area upstairs, no kind in another\'s area; clothes and snacks on shelves downstairs; adopting and buying still work', lambda: n28(run, new_wb, FIX)),
             ('N29', 'Pond: no bridge; nobody can walk on the water', lambda: n29(run, new_wb, FIX)),
             ('N30', 'Sky: clouds soft (no outlines, no hard dark faces) by day and night; no orange specks above the trees; any leaves are leaf-shaped and near trees', lambda: n30(run, new_wb, FIX)),
             ('N31', 'Trees: no tree crown inside any building; no white smear on any wall', lambda: n31(run, new_wb, FIX)),
             ('N32', 'Food trucks: no flicker (no two surfaces closer than 1 cm facing the same way); the sign and the burger picture clean', lambda: n32(run, live_w, new_wb, FIX, SIGNS_JS)),
             ('N33', 'Levels and garden: every skill reaches 50 and stops there; +6 seed spots at gardening 10/20/30/40/50; another player sees your plants', lambda: n33(run, new_wb, FIX)),
             ('N34', 'House floors and colour: 2 floors at decorating 10 up to 6 at 50; the stairs work up and down on every floor; the outside shows the floors and the chosen colour, also for others; old saves keep every piece', lambda: n34(run, new_wb, FIX)),
             ('N35', 'Notepad switch: off hides it, on brings it back with the notes kept', lambda: n35(run, new_wb, FIX)),
             ('N36', 'Furniture: at least 60 new pieces across every kind, each buyable, placeable, saved and seen by a visitor', lambda: n36(run, new_wb, FIX)),
             ('N37', 'Tree park: each of the three paths can be finished; zip lines work; signs readable; free; a fall puts you back on the last platform; on every device', lambda: todo('the tree adventure park (job 16)')),
             ('N38', 'Tutorials: the hairstylist and pizza jobs show a picture tutorial the first time and from "?"', lambda: n38(run, new_wb, FIX)),
             ('N39', 'Parties: host at the mailbox and pick a time; every online test player gets the note with the host\'s name and can accept or decline; with a disco floor and ball the dance game runs for two; hits make dance moves; the score bar slides smoothly (never jumps), even = middle with both faces; an old version doesn\'t crash', lambda: todo('the parties and the dance game (job 17)')),
             ('N40', 'Smooth and light: E1 within the run-4 limits (town 15%/25% with Halloween, rain and ghosts on; pet shop up to double; home within 10% with 6 floors; the tree park within the beach\'s size; others 10%); index.html under 1.8 MB', lambda: __import__('night3').n14(run, live_w, new_wb, FIX, limits)),
             ('N41', 'Bus: with the one clock the bus still comes 3 days a week and the pill shows the next bus with its weekday', lambda: n41(run, new_wb, FIX))]
    only = [x for x in os.environ.get('N4_ONLY', '').split(',') if x]   # a quick check after one job runs only its lines; the full check runs all 27
    for cid, name, fn in tests:
        if only and cid not in only: continue
        t0 = time.time(); ok, det = await guarded(fn)
        d['lines'].append(L(cid, name, ok, f'{det} ({round(time.time() - t0)} s)'))
        print('   ', 'PASS' if ok else 'FAIL', '|', cid, '|', str(det)[:300], flush=True)
    return d
