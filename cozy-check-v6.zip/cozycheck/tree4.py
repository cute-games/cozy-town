"""Run 4, job 16: N37 (the Tree Park: each of the three paths can be finished; zip lines work; signs readable; free; a fall puts you back on the last platform; on every device)."""
import json
from night3 import fx, begin
from checks import STATIC_JS

PROFS = ('ipad-landscape', 'iphone-portrait', 'iphone-landscape', 'pc-1366')
# stand on the edge of the current deck facing the next one, then jump holding forward (the keyboard on a PC, the joystick on touch), until you land
JUMP = """([path,i,touch])=>{const cur=TP.decks.find(q=>q.path===path&&q.i===i),n=TP.decks.find(q=>q.path===path&&q.i===i+1);if(!cur||!n)return {err:'no deck '+i};
  const dx=n.x-cur.x,dz=n.z-cur.z,L=Math.hypot(dx,dz),ux=dx/L,uz=dz/L;const ex=Math.abs(ux)>1e-6?(cur.w/2-.05)/Math.abs(ux):1e9,ez=Math.abs(uz)>1e-6?(cur.d/2-.05)/Math.abs(uz):1e9,t=Math.min(ex,ez);
  P.x=cur.x+ux*t;P.z=cur.z+uz*t;P.cy=cur.h;P.jy=0;P.vy=0;P.yaw=Math.atan2(-ux,-uz);TP.px=P.x;TP.pz=P.z;TP.last=cur;__run(1);
  const edge=Math.hypot(P.x-(cur.x+ux*t),P.z-(cur.z+uz*t))<.01;   /* standing right on the edge is fine (no invisible wall) */
  if(touch){IN.joy.id=7;IN.joy.x=0;IN.joy.y=-1;}else IN.keys.KeyW=true;jump();let fr=0;for(;fr<120;fr++){__run(1);if(fr>4&&P.jy<=0&&P.vy<=0)break;}
  if(touch){IN.joy.id=null;IN.joy.x=IN.joy.y=0;}else IN.keys.KeyW=false;__run(2);const on=tpDeckAt(P.x,P.z,P.cy||0);
  return {i,to:n.i,gap:+Math.max(0,L-Math.hypot(Math.min(Math.abs(dx),cur.w/2+n.w/2),Math.min(Math.abs(dz),cur.d/2+n.d/2))).toFixed(2),dh:+(n.h-cur.h).toFixed(2),frames:fr,edge,cy:P.cy,on:on?on.i:null,ok:!!on&&on.i===n.i};}"""
BRIDGE = """([path,i,touch])=>{const cur=TP.decks.find(q=>q.path===path&&q.i===i),n=TP.decks.find(q=>q.path===path&&q.i===i+1);P.x=cur.x;P.z=cur.z;P.cy=cur.h;P.jy=0;P.vy=0;TP.px=P.x;TP.pz=P.z;TP.last=cur;
  const dx=n.x-cur.x,dz=n.z-cur.z;P.yaw=Math.atan2(-dx,-dz);let minCy=9,fr=0;if(touch){IN.joy.id=7;IN.joy.x=0;IN.joy.y=-1;}else IN.keys.KeyW=true;
  for(;fr<160;fr++){__run(1);minCy=Math.min(minCy,P.cy||0);if(Math.hypot(P.x-n.x,P.z-n.z)<.5)break;}if(touch){IN.joy.id=null;IN.joy.x=IN.joy.y=0;}else IN.keys.KeyW=false;
  const on=tpDeckAt(P.x,P.z,P.cy||0);return {i,to:n.i,frames:fr,minCy,ok:!!on&&on.i===n.i&&minCy>=Math.min(cur.h,n.h)-.01};}"""
ZIP = """([path,i])=>{const cur=TP.decks.find(q=>q.path===path&&q.i===i),n=TP.decks.find(q=>q.path===path&&q.i===i+1),Z=TP.zips.find(z=>z.from===cur);if(!Z)return {err:'no zip line from deck '+i};
  const L=Math.hypot(Z.bx-Z.ax,Z.bz-Z.az),ux=(Z.bx-Z.ax)/L,uz=(Z.bz-Z.az)/L;P.x=Z.ax-ux*.9;P.z=Z.az-uz*.9;P.cy=cur.h;P.jy=0;P.vy=0;TP.px=P.x;TP.pz=P.z;TP.last=cur;__run(2);
  const t=findTarget(),lab=t?(typeof t.label==='function'?t.label():t.label):null;if(!t||t.icon!=='🪢')return {err:'the zip line button is not there: '+lab};
  TARGET=t;useTarget();let fr=0;const ys=[];for(;fr<600&&P.ride;fr++){__run(1);if(fr%12===0)ys.push(+(P.cy||0).toFixed(2));}
  const on=tpDeckAt(P.x,P.z,P.cy||0);return {i,to:n.i,lab,frames:fr,secs:+(fr*.05).toFixed(1),ys,len:+L.toFixed(1),on:on?on.i:null,ok:!!on&&on.i===n.i&&fr>10&&fr<600};}"""

async def one(run, new_wb, FIX, prof, paths):
    probs = []; det = []; touch = not prof.startswith('pc')
    save = dict(fx(FIX, 'save-prenight3-pets.json'), name='ZZTEST-TREEPARK-' + prof, coins=500); save.pop('tp', None)
    g = await begin(run, new_wb, prof, 'n37-' + prof, save)
    if not await g.ev("()=>typeof TP!=='undefined'&&typeof buildTreePark==='function'&&!!LOC.treepark&&!!DOORS.treepark&&PLACES.some(p=>p.id==='treepark')"):
        await run.close(g); return False, f'{prof}: the Tree Park is not in the game'
    # the gate in the woods behind the Toy Store: the way in, free
    await g.ev("()=>{__goto('city');__setClock(null,11);P.x=72.2;P.z=-38;P.yaw=Math.PI*1.5;}"); await g.step(3)
    gate = await g.ev("()=>{const t=findTarget();return {t:t?[t.icon,typeof t.label==='function'?t.label():t.label]:null,coins:S.coins,map:PLACES.find(p=>p.id==='treepark')}}")
    det.append(f"the gate: button {gate['t']}, on the map as {gate['map']['n']} {gate['map']['i']} at {gate['map']['x']},{gate['map']['z']}")
    if not gate['t'] or gate['t'][0] != '🌲': probs.append(f'no gate button in the woods: {gate["t"]}')
    if prof == 'ipad-landscape': await g.ev("()=>{P.x=68.6;P.z=-38;P.yaw=Math.PI*1.5;P.pitch=0;}"); await g.step(2); await g.shot('treepark-gate', both=False); await g.ev("()=>{P.x=72.2;P.z=-38;}"); await g.step(2)
    await g.ev("()=>{TARGET=findTarget();if(TARGET)useTarget();}")
    for _ in range(30):
        await g.step(4); await g.wait(80)
        if await g.ev("()=>CUR.id==='treepark'&&!fading"): break
    inside = await g.ev("()=>({cur:CUR.id,coins:S.coins,cy:P.cy,signs:TP.signs.map(s=>s.userData.sign.text),decks:TP.decks.length,zips:TP.zips.length,bridges:TP.walk.length,gate:!!CUR.inter.find(t=>t.icon==='🏘')})")
    det.append(f"inside: {inside['cur']}, coins {gate['coins']} -> {inside['coins']} (free), signs {inside['signs']}, {inside['decks']} decks, {inside['bridges']} bridges, {inside['zips']} zip lines, a gate back {inside['gate']}")
    if inside['cur'] != 'treepark' or inside['coins'] != gate['coins'] or inside['decks'] < 20 or inside['zips'] < 3 or not inside['gate']: probs.append('the way in, or the park is not built right')
    want = ['🟢 Easy path', '🟡 Medium path', '🔴 Hard path', '🏁 Finish']
    if not all(any(w in s for s in inside['signs']) for w in want): probs.append(f'signs missing: {inside["signs"]}')
    # the signs are readable: each sign's ink sits inside its box with a margin (like N23), and the three path signs face you at the start
    signs = await g.ev("""()=>TP.signs.map(m=>{const S0=m.userData.sign,c=S0.c,W=c.width,H=c.height,d=c.getContext('2d').getImageData(0,0,W,H).data;const bg=[1,3,5].map(i=>parseInt(S0.bg.slice(i,i+2),16));let x1=W,x2=-1,y1=H,y2=-1;
      for(let y=0;y<H;y++)for(let x=0;x<W;x++){const i=(y*W+x)*4;if(Math.abs(d[i]-bg[0])+Math.abs(d[i+1]-bg[1])+Math.abs(d[i+2]-bg[2])>60){if(x<x1)x1=x;if(x>x2)x2=x;if(y<y1)y1=y;if(y>y2)y2=y;}}
      return {text:S0.text,inside:x1>W*.03&&x2<W*.97&&y1>H*.04&&y2<H*.96,cx:+(((x1+x2)/2-W/2)/W).toFixed(3),cy:+(((y1+y2)/2-H/2)/H).toFixed(3),px:W,h:S0.h};})""")
    bad = [s for s in signs if not s['inside'] or abs(s['cx']) > .03 or abs(s['cy']) > .03]
    det.append(f"signs readable (ink inside, centred within 3%): {len(signs) - len(bad)} of {len(signs)}" + (f' bad {bad}' if bad else ''))
    if bad: probs.append(f'signs: {bad}')
    if prof == 'ipad-landscape':
        await g.ev("()=>{P.x=0;P.z=TP_Z+22.5;P.yaw=0;P.pitch=0;}"); await g.step(2); await g.shot('treepark-start', both=True)
    # the paths
    for k in paths:
        await g.ev("(k)=>{const L=LOC.treepark,t=L.inter.find(t=>t.icon==='🪜'&&(typeof t.label==='function'?t.label():t.label).toLowerCase().includes('climb up: the '+k));P.x=t?t.x:[-9,0,9][['easy','medium','hard'].indexOf(k)];P.z=TP_Z+17.8;P.yaw=0;__run(2);}", k)   # (stage 3: the three signposts stand side by side; the ladder button is found where the game put it)
        t = await g.ev("()=>{const t=findTarget();return t?[t.icon,typeof t.label==='function'?t.label():t.label]:null}")
        if not t or t[0] != '🪜': probs.append(f'{k}: no ladder button at the sign: {t}'); await g.ev("(k)=>tpStart(k)", k)
        else: await g.ev("()=>{TARGET=findTarget();useTarget();}")
        for _ in range(20):
            await g.step(3); await g.wait(60)
            if not await g.ev("()=>fading"): break
        await g.step(3)
        st = await g.ev("(k)=>{const d=TP.decks.find(q=>q.path===k&&q.i===0);return {cy:P.cy,onFirst:!!tpDeckAt(P.x,P.z,P.cy||0)&&tpDeckAt(P.x,P.z,P.cy||0).i===0,n:TP_COURSE[k].length,steps:TP_COURSE[k].map(d=>d.b?'bridge':d.zip?'zip':d.fin?'finish':'jump')}}", k)
        if not st['onFirst']: probs.append(f'{k}: the ladder did not put you on the first deck')
        if k == 'easy' and prof == 'ipad-landscape': await g.shot('treepark-easy-first-deck', both=False)
        jumps = []; ok_all = True; zipped = False
        for i, step in enumerate(st['steps'][:-1]):
            if step == 'bridge': r = await g.ev(BRIDGE, [k, i, touch])
            elif step == 'zip': r = await g.ev(ZIP, [k, i]); zipped = zipped or r.get('ok')
            else: r = await g.ev(JUMP, [k, i, touch])
            if r.get('err') or not r.get('ok'): ok_all = False; probs.append(f'{k} step {i} ({step}): {r}')
            if await g.ev("()=>!!(TP.falling||fading)"): await g.wait(700); await g.step(3)   # a fall's short fade runs on real time: let it finish before the next step
            jumps.append(f"{step} {i}->{i+1}" + (f" gap {r['gap']} m dh {r['dh']}" if 'gap' in r else '') + (f" {r['secs']} s over {r['len']} m" if 'secs' in r else '') + ('' if r.get('ok') else ' FAILED'))
            if k == 'easy' and step == 'zip' and prof == 'ipad-landscape':
                pass
        # the bell at the finish
        fin = await g.ev("(k)=>{const d=TP.decks.find(q=>q.path===k&&q.fin);P.x=d.x;P.z=d.z;P.cy=d.h;P.jy=0;P.vy=0;TP.last=d;TP.px=P.x;TP.pz=P.z;__run(2);const t=findTarget();const lab=t?(typeof t.label==='function'?t.label():t.label):null;const c0=S.coins;if(t&&t.icon==='🔔'){TARGET=t;useTarget();}__run(4);return {lab,done:!!(S.tp&&S.tp.done&&S.tp.done[k]),coins:S.coins-c0};}", k)
        det.append(f"{k} ({st['n']} decks): " + ', '.join(jumps) + f"; the bell: {fin['lab']} -> finished {fin['done']} (+{fin['coins']} coins)")
        if not fin['done'] or not zipped: probs.append(f'{k}: not finished ({fin}) or no zip line ridden')
        if k == 'easy' and prof == 'ipad-landscape': await g.shot('treepark-finish', both=False)
    # the device's own jump control: the ⬆️ button on touch, Space on a PC
    await g.ev("()=>{P.x=0;P.z=TP_Z+21;P.cy=0;P.jy=0;P.vy=0;TP.last=null;P.yaw=0;}"); await g.step(2)
    if touch: await g.tap('#bJump')
    else: await g.key('Space')
    await g.step(1); jumped = await g.ev("()=>P.jy>0||P.vy>0")
    det.append(f"{'the ⬆️ button' if touch else 'the Space key'} makes you jump: {jumped}")
    if not jumped: probs.append('the jump control')
    await g.step(30)
    # a fall: walk off a deck -> a soft landing on the ground, then (a short fade) back on the last deck
    fall = await g.ev("""()=>{const d=TP.decks.find(q=>q.path==='easy'&&q.i===2);P.x=d.x;P.z=d.z;P.cy=d.h;P.jy=0;P.vy=0;TP.last=d;TP.px=P.x;TP.pz=P.z;window.__f0=(S.tp&&S.tp.falls)||0;__run(1);
      const dirs=[[1,0],[-1,0],[0,1],[0,-1]].filter(([ux,uz])=>{const x=d.x+ux*(d.w/2+1.2),z=d.z+uz*(d.d/2+1.2),p=collideXZ(x,z,.3,CUR);return Math.hypot(p[0]-x,p[1]-z)<.02&&!tpSupport(x,z,d.h);});const [ux,uz]=dirs[0]||[1,0];   /* walk off a side with nothing in the way (not into the deck's own tree) */
      P.yaw=Math.atan2(-ux,-uz);IN.keys.KeyW=true;let fr=0,minCy=9,fell=false;for(;fr<260;fr++){__run(1);const c=(P.cy||0)+P.jy;minCy=Math.min(minCy,c);if(c<.05)fell=true;if(TP.falling||fading)break;}IN.keys.KeyW=false;
      return {frames:fr,minCy:+minCy.toFixed(2),fell,falling:!!TP.falling,dir:[ux,uz]};}""")
    await g.wait(700); await g.step(4)
    back = await g.ev("()=>{const d=TP.decks.find(q=>q.path==='easy'&&q.i===2);return {back:Math.abs((P.cy||0)-d.h)<.01&&Math.abs(P.x-d.x)<.2&&Math.abs(P.z-d.z)<.2,falls:((S.tp&&S.tp.falls)||0)-window.__f0,hunger:S.hunger,fading};}")
    det.append(f"a fall from deck 3: reached the ground {fall['fell']} (lowest {fall['minCy']} m), picked up {fall['falling']}, back on the deck {back['back']}, falls counted {back['falls']}, tummy still {back['hunger']:.0f} (no harm)")
    if not fall['fell'] or not back['back'] or back['falls'] != 1: probs.append(f'the fall: {fall} {back}')
    # the way out, and the park's weight against the beach (the new-area rule)
    out = await g.ev("()=>{P.x=0;P.z=TP_Z+25.2;P.cy=0;P.jy=0;TP.last=null;__run(2);const t=findTarget();const lab=t?(typeof t.label==='function'?t.label():t.label):null;if(t)useTarget();return lab;}")
    for _ in range(30):
        await g.step(4); await g.wait(80)
        if await g.ev("()=>CUR.id==='city'&&!fading"): break
    back = await g.ev("()=>({cur:CUR.id,x:+P.x.toFixed(1),z:+P.z.toFixed(1)})")
    w = await g.ev(STATIC_JS); tp_w, b_w = w.get('treepark'), w.get('beach')
    det.append(f"out through the gate ({out}) -> {back}; weight: the park {tp_w} vs the beach {b_w}")
    if back['cur'] != 'city': probs.append('the way out')
    if not tp_w or not b_w or tp_w['meshes'] > b_w['meshes'] or tp_w['tris'] > b_w['tris']: probs.append(f'the park weighs more than the beach: {tp_w} vs {b_w}')
    errs = g.errors[:2]; await run.close(g)
    if errs: probs.append(f'browser errors: {errs}')
    return not probs, f"[{prof}] " + '; '.join(det) + (f' | PROBLEMS: {probs}' if probs else '')

async def n37(run, new_wb, FIX):
    if b'function buildTreePark' not in new_wb or b"makeLoc('treepark'" not in new_wb: return False, 'the Tree Park is not built yet (job 16)'
    oks = []; dets = []
    for prof in PROFS:
        ok, d = await one(run, new_wb, FIX, prof, ('easy', 'medium', 'hard') if prof == 'ipad-landscape' else ('easy',)); oks.append(ok); dets.append(d)
    return all(oks), ' || '.join(dets)
