"""Cozy Town FINAL CHECK (resumable). Every line starts as FAIL and passes only on proof.
Each stage saves its result in OUT/stages; running again skips stages already done for the same files.
usage: python3 cozy_check2.py --live-claude F --new-claude F --live-web F [--backup F --backup-title T]
                              [--published F] [--github F] [--out DIR] [--tag T] [--dry-run]"""
import argparse, asyncio, datetime, glob, json, os, sys, time, traceback
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
from harness import Run, PROFILES, md5b
from crawl import Crawler, INSTR, replay
import checks as C
import night3 as N3
import run4 as R4

CHECK_VERSION = '6'   # v6 (17 Oct, run 4): stage 'run4' with N15-N41 (run4.py; every line starts as FAIL); the one clock in the test pages (__setClock / __clockMs in crawl.INSTR, realMs replaced like realDate); B1 lets an old save jump once to the shared day (checks.py: exactly what a midnight renews); E1: a new area may use at most what the beach uses; N1/N6/N10/N14 rewritten to the owner's 17 Oct design, never weaker; six new fixtures made by the starting version (save-prerun4-*.json). v5.1 (17 Oct, after the night-3 merge): v5.1 (17 Oct, after the night-3 merge): the web part is put into the new Claude file by its neighbouring lines, not the old line number, so the GitHub file tested is the real one (it was 1566924e, the real file is 709bf763). v5 (17 Oct): stage 'night3' with N1-N14 for the night-3 jobs (night3.py; every line starts as FAIL); B1 lets a save that never had laneT get one (like pid). v4 (16 Oct): E1 per-area limits (--e1-limits; owner's OK 16 Oct: more for the town and the beach). v3 (9 Oct): W1/W2 the What's new book. v2: B1 lets a save with no player id get one; A2 backs up the GitHub file (GitHub first); --full
SMALL_LIMIT = 44
ap = argparse.ArgumentParser()
ap.add_argument('--live-claude', required=True); ap.add_argument('--new-claude', required=True); ap.add_argument('--live-web', required=True)
ap.add_argument('--backup'); ap.add_argument('--backup-title', default=''); ap.add_argument('--published'); ap.add_argument('--github')
ap.add_argument('--fixtures', default=os.path.join(HERE, 'fixtures')); ap.add_argument('--out', default='/home/claude/kit/run')
ap.add_argument('--tag', default='run'); ap.add_argument('--dry-run', action='store_true'); ap.add_argument('--agreed-removals', default='')
ap.add_argument('--crawl-budget', type=int, default=1500); ap.add_argument('--tour-budget', type=int, default=600)
ap.add_argument('--only', default='')
ap.add_argument('--full', action='store_true', help='full sweep for big updates: every screen on every device size')
ap.add_argument('--e1-limits', default='', help="per-area E1 limits, pieces and triangles: 'city:0.35:0.60,beach:0.35:0.60' (owner's OK 16 Oct for night 3); other areas stay at 10%")
A = ap.parse_args()
os.makedirs(os.path.join(A.out, 'stages'), exist_ok=True)
TODAY = datetime.date.today().isoformat()
rb = lambda p: open(p, 'rb').read()
live_c, new_c, live_w = rb(A.live_claude), rb(A.new_claude), rb(A.live_web)
sc, sn, sw = live_c.decode(), new_c.decode(), live_w.decode()
blocks = C.web_part(sc, sw)
new_w = C.apply_web_part(sn, blocks, sc) if blocks is not None else None   # v5.1: placed by the neighbouring lines, not the old line number
if blocks is not None and new_w is None: sys.exit('STOP: the web part cannot be placed in the new Claude file (a line next to it changed, or new lines sit between them); nothing is guessed')
new_wb = new_w.encode() if new_w else None
if new_w: open(os.path.join(A.out, 'github-index.html'), 'w').write(new_w)
FIX = []
for f in sorted(glob.glob(os.path.join(A.fixtures, '*.json'))):
    try: FIX.append((os.path.basename(f), json.load(open(f))))
    except Exception as e: print('fixture unreadable', f, e)
KEY = md5b(live_c + new_c + live_w + b'[]' + CHECK_VERSION.encode())   # same files + same check version = same result
FIXKEY = md5b(KEY.encode() + json.dumps([n for n, _ in FIX]).encode())   # the saves stage also depends on the saved games in the kit

def L(cid, name, ok, detail): return [cid, name, ok, detail]

async def stage(name, fn):
    p = os.path.join(A.out, 'stages', name + '.json'); key = FIXKEY if name == 'saves' else KEY
    if os.path.exists(p):
        d = json.load(open(p))
        if d.get('key') == key: print(f'[stage {name}: already done]', flush=True); return d
    if A.only and name not in A.only.split(','): return {'lines': [], 'skipped': True}
    t0 = time.time(); print(f'[stage {name}: running]', flush=True)
    d = {'lines': [], 'issues': [], 'btn': [], 'errors': [], 'served': {}, 'blocked': [], 'extra': {}}
    try:
        async with Run(A.tag, A.out) as run:
            d = await fn(run, d)
            d['issues'] = [i for g in run.all_games for i in g.issues]; d['btn'] = [b for g in run.all_games for b in g.btn]
            d['errors'] = [f'{g.profile} {g.name}: {e}' for g in run.all_games for e in g.errors]
            d['served'] = run.served; d['blocked'] = sorted(set(run.blocked))
    except Exception as e:
        tb = traceback.extract_tb(e.__traceback__); where = ' <- '.join(f'{os.path.basename(f.filename)}:{f.lineno} {f.name}' for f in tb[-3:])
        d['lines'].append(L('X', f'stage {name} crashed', False, repr(e)[:300] + f' (at {where})'))
        traceback.print_exc()
    d['key'] = key; d['secs'] = round(time.time() - t0)
    json.dump(d, open(p, 'w')); print(f'[stage {name}: done in {d["secs"]} s]', flush=True)
    for l in d['lines']: print('   ', 'PASS' if l[2] else 'FAIL', '|', l[0], l[1], '|', str(l[3])[:200], flush=True)
    return d

def keep(d, g):
    pass  # issues, buttons and errors are collected from every test page at the end of each stage

async def s_files(run, d):
    days = {os.path.basename(p): datetime.date.fromtimestamp(os.path.getmtime(p)).isoformat() for p in (A.live_claude, A.live_web)}
    d['lines'].append(L('A1', 'newest live versions read right before the check', all(v == TODAY for v in days.values()), ', '.join(f'{k} read on {v}' for k, v in days.items())))
    if A.backup:
        b = rb(A.backup); d['lines'].append(L('A2', 'dated private backup of the live game', md5b(b) == md5b(live_w) and TODAY in A.backup_title, f'backup {md5b(b)} vs live GitHub {md5b(live_w)}; title "{A.backup_title}"'))
    elif A.dry_run: d['lines'].append(L('A2', 'dated private backup of the live game', None, 'NOT RUN: dry run, nothing is being changed'))
    else: d['lines'].append(L('A2', 'dated private backup of the live game', False, 'no backup given'))
    d['lines'].append(L('F3a', 'live GitHub version = live Claude version + web part, nothing else', bool(blocks), f'{sum(len(x[1]) for x in blocks)} added lines in {len(blocks)} places, no lines removed or changed' if blocks else 'GitHub file has removed or changed lines'))
    d['lines'].append(L('F1', 'no ZZTEST test data in the file to publish', b'ZZTEST' not in new_c, f'ZZTEST appears {new_c.count(b"ZZTEST")} times'))
    oo, no = C.outside_addresses(sc), C.outside_addresses(sn); added = sorted(u for u in no - oo if not C.host_ok(u))
    d['lines'].append(L('F5', 'no new outside addresses (same 3D library and font)', not added, f'{sorted(no)}' + (f'; NEW: {added}' if added else '')))
    return d

async def s_counts(run, d):
    go = await run.open(live_w, 'web', 'pc-1366', 'light', 'count-old'); await go.manual(); co = await go.counts(); so = await C.weight_static(go); await go.play_intro('ZZTEST-W1'); wo = await C.weight(go); keep(d, go); await run.close(go)
    gn = await run.open(new_wb, 'web', 'pc-1366', 'light', 'count-new'); await gn.manual(); cn = await gn.counts(); sn_ = await C.weight_static(gn); await gn.play_intro('ZZTEST-W2'); wn = await C.weight(gn); keep(d, gn); await run.close(gn)
    miss, grew = C.compare_counts(co, cn, set(x for x in A.agreed_removals.split(',') if x))
    tot = lambda c: sum(len(v) for v in c.values())
    d['lines'].append(L('A3', 'everything in the live game is still in the new one, by name', not miss, f'{len(co)} lists, {tot(co)} things before, {tot(cn)} after' + (f'; MISSING: {json.dumps(miss)[:400]}' if miss else '') + (f'; grew: {json.dumps(grew)[:200]}' if grew else '')))
    per = C.parse_limits(A.e1_limits); worse = C.compare_static(so, sn_, per=per)
    lim_txt = ', '.join(f'{a} +{round(p*100)}% pieces / +{round(t*100)}% triangles' for a, (p, t) in per.items())
    tp = sum(v['meshes'] for v in sn_.values()); tt = sum(v['tris'] for v in sn_.values())
    d['lines'].append(L('E1', 'no more drawing work than before, area by area (more than 10% needs your OK)' + (f'; agreed more: {lim_txt}' if per else ''), not worse and len(sn_) >= len(so) > 0,
        f'{len(sn_)} areas, {tp} pieces, {tt} triangles in total' + (f' | MORE: {worse}' if worse else '') + ' | for information, seen from 5 spots: ' + '; '.join(f"{k} {v['calls']} draws" for k, v in wn.items() if v)))
    d['extra'] = {'counts_old': co, 'counts_new': cn, 'static_old': so, 'static_new': sn_, 'weight_old': wo, 'weight_new': wn}
    return d

async def s_saves(run, d):
    gs = await run.open(live_w, 'web', 'ipad-landscape', 'light', 'make-save'); await gs.manual(); await gs.play_intro('ZZTEST-S'); await gs.ev(INSTR)
    await gs.tap('#bBag'); await gs.step(4); await gs.tap('#card [data-a^="eat:"]'); await gs.step(4); await gs.ev("()=>closePanel()"); await gs.step(230)
    fresh = await gs.state(); keep(d, gs); await run.close(gs)
    fx = FIX + [(f'fresh save made by the live version today', fresh)]
    ok, det = await C.check_saves(run, live_w, new_wb, fx)
    d['lines'].append(L('B1', 'saved games from older versions load in the new one with nothing lost', ok, f'{len(fx)} saves tried: {det}'))
    d['lines'].append(L('B2', 'the new version keeps the same save key', 'same key: NO' not in det and 'same key: yes' in det, 'key cozytown-save-1'))
    d['extra'] = {'fresh': fresh}
    return d

async def s_players(run, d):
    sp = os.path.join(A.out, 'stages', 'saves.json')
    fresh = json.load(open(sp))['extra']['fresh'] if os.path.exists(sp) else dict(next((f for n, f in FIX if n == 'save-prenight3-pets.json'), FIX[0][1]), pets=[])   # (a quick check without the saves stage: a rich fixture stands in for the fresh save)
    fxA = dict(fresh, name='ZZTEST-A'); fxB = dict(fresh, name='ZZTEST-B', px=(fresh.get('px') or -17) + 1.5)
    (o1, t1), (o2, t2), (o3, t3) = await C.check_two_players(run, live_w, new_wb, fxA, fxB)
    d['lines'].append(L('D1', 'two players see each other, see each other walk, and chat (old + new version together)', o1, t1))
    d['lines'].append(L('D2', 'Friends Lane: each player gets a house', o2, t2))
    d['lines'].append(L('D3', "visiting a friend's house works: knock, let in, go inside", o3, t3))
    d['extra'] = {'areas': ['visit'] if o3 else []}
    return d

async def s_claude(run, d):
    g = await run.open(new_c, 'claude', 'ipad-landscape', 'light', 'claude'); await g.manual()
    ok = await g.play_intro('ZZTEST-C'); await g.step(20); mp = await g.ev("()=>MP.state"); await g.shot('claude-version-city', both=True)
    keep(d, g); await run.close(g)
    d['lines'].append(L('C7', 'the Claude version starts, plays the opening and goes online (test room)', ok and mp == 'on', f'opening played: {ok}; online: {mp}'))
    return d

AREA_GROUPS = {'town': ['city'], 'inA': ['home', 'market', 'pets', 'flowers', 'cafe'], 'inB': ['clothes', 'toys', 'bakery', 'icecream', 'library'],
               'inC': ['school', 'cl_math', 'cl_english', 'cl_history', 'fire', 'pizza'], 'inD': ['apt1', 'apt2', 'apt3']}
CRAWL_DEVICES = ('ipad-landscape',)   # lighter check (7 Oct): full play-through on iPad only
TOUR_DEVICES = ['iphone-portrait', 'iphone-landscape']   # lighter check: main screens on iPhone, upright and sideways
DROPPED = ['android-phone-portrait', 'android-phone-landscape', 'android-tablet-portrait', 'android-tablet-landscape', 'pc-1366']
if A.full: TOUR_DEVICES = TOUR_DEVICES + DROPPED; DROPPED = []   # full sweep for big updates (decision 7 Oct)
TEACH_DEVICES = ['ipad-landscape', 'iphone-landscape', 'pc-1920']

def fresh_save():
    p = os.path.join(A.out, 'stages', 'saves.json')
    return json.load(open(p))['extra']['fresh'] if os.path.exists(p) else None

def crawl_stage(prof, part):
    async def fn(run, d):
        sv = fresh_save()
        if part == 'hud' or not sv:
            g = await run.open(new_wb, 'web', prof, 'light', 'crawl-' + part); await g.manual(); await g.play_intro('ZZTEST-' + prof[:4].upper()); await g.step(5)
        else:
            g = await run.open(new_wb, 'web', prof, 'light', 'crawl-' + part, save=dict(sv, name='ZZTEST-' + part.upper()))
            await C.start_from_save(g)
        if part == 'town':
            # test setup (said openly in the log): take the designer job so a client's house can be entered from town
            run.log.note('town part: chose the designer job by code and waited for a client order (a house, not a flat) so the client room can be reached')
            await g.ev(INSTR); await g.ev("()=>{setJob('designer');}")
            for _ in range(60):
                await g.step(20)
                if await g.center('#dtSkip'): await g.tap('#dtSkip'); await g.step(3)
                o = await g.ev("()=>S.ds&&S.ds.o?{h:S.ds.o.h,flat:S.ds.o.flat||0}:null")
                if o and not o['flat']: break
                if o and o['flat']: await g.ev("()=>{S.ds.o=null;ds().wait=0;}")
                else: await g.ev("()=>{try{ds().wait=Math.min(ds().wait,0.1);}catch(e){}}")
            d['extra']['designer_order'] = await g.ev("()=>S.ds&&S.ds.o?S.ds.o.h:null")
        cr = Crawler(g, depth=2, per_label=1, budget_s=A.crawl_budget, recurse=False)
        res = await cr.run_areas(AREA_GROUPS.get(part, []), hud=(part == 'hud'))
        if part == 'town': d['extra']['walk'] = await C.check_walk(g)
        d['extra'].update({'res': res, 'recipes': cr.recipes, 'end_save': await g.state()})
        await run.close(g)
        return d
    return fn

def main_recipes(recs):
    out = []; na = nt = 0
    for r in recs:
        if r['kind'] == 'hud' and len(r.get('path', [])) <= 1: out.append(r)
        elif r['kind'] == 'target' and not r.get('path') and nt < 20: out.append(r); nt += 1
        elif r['kind'] == 'area' and na < 6: out.append(r); na += 1
    return out

def tour_recipes():
    # the client's room only exists during the designer job; it is checked in the iPad town part
    return [r for r in main_recipes(all_recipes()) if 'arrived-in-client' not in r.get('label', '')]

def all_recipes():
    recs = []; seen = set()
    for part in ['hud'] + list(AREA_GROUPS):
        p = os.path.join(A.out, 'stages', f'crawl_ipad-landscape_{part}.json')
        if not os.path.exists(p): continue
        for r in json.load(open(p))['extra'].get('recipes', []):
            pth = r.get('path', [])
            k = (r['kind'], r.get('loc'), r.get('tlabel'), r.get('sel'), tuple(x.split(':')[0] for x in pth[:1]), len(pth) > 1)   # one of each kind of screen
            if k in seen: continue
            seen.add(k); recs.append(r)
    return recs

TOUR_CHUNK = 30
def tour_stage(prof, k):
    async def fn(run, d):
        recs = tour_recipes()[k * TOUR_CHUNK:(k + 1) * TOUR_CHUNK]; sv = fresh_save()
        if k == 0 or not sv:
            g = await run.open(new_wb, 'web', prof, 'light', f'tour{k}'); await g.manual(); await g.play_intro('ZZTEST-T'); await g.step(5)
        else:
            g = await run.open(new_wb, 'web', prof, 'light', f'tour{k}', save=dict(sv, name='ZZTEST-T')); await C.start_from_save(g)
        cr = Crawler(g, depth=0, per_label=1, budget_s=A.tour_budget); await g.ev(INSTR)
        fails = []; done = 0; t0 = time.time()
        for rec in recs:
            if time.time() - t0 > A.tour_budget: fails.append(f'time ran out after {done} screens'); break
            try: r = await replay(cr, rec)
            except Exception as e: r = 'error ' + repr(e)[:80]
            if r == 'ok': await g.shot('tour-' + rec['label'], both=True); done += 1
            else: fails.append(f"{rec['label']}: {r}")
            await cr.recover(rec.get('loc', 'city'))
        if k == 0: d['extra']['walk'] = await C.check_walk(g)
        d['extra'].update({'done': done, 'total': len(recs), 'fails': fails})
        await run.close(g)
        return d
    return fn


import teacher as T
def teacher_stage(prof):
    async def fn(run, d):
        out = await T.play_teacher(run, new_wb, prof, 'light', classes=3)
        d['extra'] = {'teacher': out}
        return d
    return fn

async def s_pc_keys(run, d):
    sv = fresh_save()
    g = await run.open(new_wb, 'web', 'pc-1920', 'light', 'pc-keys', save=dict(sv, name='ZZTEST-PC')); await C.start_from_save(g); await g.ev(INSTR)
    await g.ev("()=>{if(typeof __setClock==='function')__setClock(null,12);}"); await g.step(3)   # the one clock (run 4) sets the hour from the real time: the Market is shut 20:00-8:00, so this line plays at noon
    wk = await C.check_walk(g); res = []
    for key, what in (('KeyP', 'phone'), ('KeyB', 'bag'), ('KeyM', 'map')):
        await g.key(key); await g.step(4); await g.wait(350); opened = await g.ev("()=>UI.open")
        await g.shot(f'pc-key-{what}', both=True)
        await g.key('Escape'); await g.step(3); await g.wait(250); closed = not await g.ev("()=>UI.open")
        res.append(f'{what}: opens {opened}, Escape closes {closed}')
    cr = Crawler(g, depth=0, per_label=1, budget_s=300); ts = await cr.targets()
    door = next((x for x in ts if x['when'] and 'market' in x['label'].lower()), None); e_ok = False
    if door and await cr.approach(door['i']) == 'ok':
        await g.key('KeyE'); await cr.settle(6, 800); e_ok = await g.ev("()=>CUR.id!=='city'")
        await g.shot('pc-key-E-door', both=True)
    res.append(f'E on the market door goes in: {e_ok}')
    await run.close(g)
    ok = wk[0] and e_ok and all('opens True' in r and 'closes True' in r for r in res[:3])
    d['lines'].append(L('K1', 'PC keyboard: walk with keys, P phone, B bag, M map, Escape closes, E uses', ok, wk[1] + '; ' + '; '.join(res)))
    d['extra'] = {'walk': wk}
    return d

def n_tour_chunks():
    n = len(tour_recipes())
    return max(1, -(-n // TOUR_CHUNK)) if n else 5

BOOK_DEVICES = ['ipad-landscape', 'iphone-portrait', 'iphone-landscape', 'pc-1920']
BOOK_ST = """()=>{const q=s=>document.querySelector(s),r=e=>{const b=e.getBoundingClientRect();return [Math.round(b.left),Math.round(b.top),Math.round(b.right),Math.round(b.bottom)]};
 const c=q('#book .bk-card');return {open:document.body.classList.contains('bookopen'),num:$('bkNum').textContent,lbl:$('bkNextW').textContent.trim(),
  dots:document.querySelectorAll('#bkDots .bk-dot').length,on:[...document.querySelectorAll('#bkDots .bk-dot')].findIndex(x=>x.classList.contains('on')),
  next:r($('bkNext')),imgs:[...document.querySelectorAll('#bkPage img')].map(i=>i.complete&&i.naturalWidth>0),
  inside:(()=>{const b=r(c);return b[0]>=0&&b[1]>=0&&b[2]<=innerWidth&&b[3]<=innerHeight})(),fits:c.scrollHeight<=c.clientHeight+1&&c.scrollWidth<=c.clientWidth+1,
  keyLeak:!!(IN.keys&&(IN.keys.ArrowRight||IN.keys.ArrowLeft||IN.keys.Escape))};}"""
async def book_swipe(g, dx):
    c = await g.center('#bkPage')
    if not c: return False
    x, y = c['x'], c['y']
    if g.p['touch']:
        cdp = await g.page.context.new_cdp_session(g.page)
        await cdp.send('Input.dispatchTouchEvent', {'type': 'touchStart', 'touchPoints': [{'x': x, 'y': y}]})
        for k in range(1, 7): await cdp.send('Input.dispatchTouchEvent', {'type': 'touchMove', 'touchPoints': [{'x': x + dx * k / 6, 'y': y}]})
        await cdp.send('Input.dispatchTouchEvent', {'type': 'touchEnd', 'touchPoints': []}); await cdp.detach()
    else:
        await g.page.mouse.move(x, y); await g.page.mouse.down(); await g.page.mouse.move(x + dx, y, steps=6); await g.page.mouse.up()
    await g.wait(250); return True

async def s_book(run, d):
    """W1/W2 (9 Oct): the What's new book on the title, and the "Designed by Izabele" line, on iPad, iPhone upright and sideways, and PC."""
    for prof in BOOK_DEVICES:
        g = await run.open(new_wb, 'web', prof, 'light', 'book-' + prof); await g.manual(); await g.wait(800)   # the game loop paused, as in the other stages
        if not await g.ev("()=>!!document.getElementById('tNew')"):
            d['lines'].append(L('W1', f"What's new book works ({prof})", False, "no What's new button on the title")); await run.close(g); continue
        await g.shot('title-with-whats-new', both=True)
        cr = await g.ev("""()=>{const c=$('tCred'),v=$('tVer'),r=c.getBoundingClientRect(),q=v&&v.getBoundingClientRect();
          const hit=(a,b)=>!(a.right<=b.left||a.left>=b.right||a.bottom<=b.top||a.top>=b.bottom);const btns=[...document.querySelectorAll('#title button')].filter(b=>b.offsetParent).map(b=>b.getBoundingClientRect());
          return {text:c.textContent,ver:!!q,onVer:!!q&&hit(r,q),onBtn:btns.some(b=>hit(r,b)),inside:r.left>=0&&r.right<=innerWidth&&r.bottom<=innerHeight&&r.top>=0}}""")
        d['lines'].append(L('W2', f'title says "Designed by Izabele 💗", on the screen, clear of the buttons and the version label ({prof})',
            cr['text'] == 'Designed by Izabele 💗' and cr['inside'] and not cr['onVer'] and not cr['onBtn'], f"text: {cr['text']!r}; on screen: {cr['inside']}; touches the version label: {cr['onVer']}; touches a button: {cr['onBtn']}"))
        probs = []; pages = []; NB = await g.ev('()=>BOOK_PAGES.length')   # the book's page count (9 on night 3, 7 on run 4 stage 1)
        t = await g.tap('#tNew'); await g.wait(400)
        if t != 'ok': probs.append(f"What's new tap: {t}")
        for i in range(NB):
            st = await g.ev(BOOK_ST)
            if not st['open']: probs.append(f'closed on page {i + 1}'); break
            await g.ev("()=>Promise.all($('book').getAnimations({subtree:true}).map(a=>a.finished.catch(()=>0)))")   # the card has finished popping in
            st['seen'] = await g.ev("()=>{const c=document.querySelector('#book .bk-card');return getComputedStyle($('book')).display!=='none'&&+getComputedStyle(c).opacity>0.99}")
            if not st['seen']: probs.append(f'page {i + 1}: the card is not fully shown')
            pages.append(st); await g.shot(f'book-page-{i + 1}', both=True)
            if st['num'] != f'{i + 1} / {NB}' or st['dots'] != NB or st['on'] != i: probs.append(f"page {i + 1}: number {st['num']!r}, dots {st['dots']}, lit {st['on'] + 1}")
            if not all(st['imgs']): probs.append(f'page {i + 1}: a picture did not load')
            if not st['inside'] or not st['fits']: probs.append(f"page {i + 1}: card inside the screen {st['inside']}, everything fits without scrolling {st['fits']}")
            if i < NB - 1:
                t = await g.tap('#bkNext'); await g.wait(300)
                if t != 'ok': probs.append(f'Next on page {i + 1}: {t}')
        last = pages[-1] if pages else {}
        if last.get('lbl') != 'Let’s play!': probs.append(f"last page button says {last.get('lbl')!r}")
        rights = [p['next'][2] for p in pages]; tops = [p['next'][1] for p in pages]
        steady = bool(pages) and max(rights) - min(rights) <= 2 and max(tops) - min(tops) <= 2
        # Back, swipe, arrow keys, Escape, the ✕, a tap outside, and Let's play!
        page = lambda: g.ev("()=>document.body.classList.contains('bookopen')?+$('bkNum').textContent.split(' ')[0]:0")
        ctl = []
        await g.tap('#bkPrev'); await g.wait(250); ctl.append(('Back', await page(), NB - 1))
        await book_swipe(g, 170); ctl.append(('swipe right', await page(), NB - 2))
        await book_swipe(g, -170); ctl.append(('swipe left', await page(), NB - 1))
        await g.key('ArrowLeft'); await g.wait(200); ctl.append(('arrow left', await page(), NB - 2))
        await g.key('ArrowRight'); await g.wait(200); ctl.append(('arrow right', await page(), NB - 1))
        leak = (await g.ev(BOOK_ST))['keyLeak']
        await g.key('Escape'); await g.wait(250); ctl.append(('Escape closes', await page(), 0))
        await g.tap('#tNew'); await g.wait(350); ctl.append(('opens on page 1 again', await page(), 1))
        await g.tap('#bkX'); await g.wait(250); ctl.append(('✕ closes', await page(), 0))
        await g.tap('#tNew'); await g.wait(350); vw = await g.ev('()=>[innerWidth,innerHeight]'); await g.tap_xy(3, vw[1] // 2); await g.wait(250); ctl.append(('tap outside closes', await page(), 0))
        await g.tap('#tNew'); await g.wait(350)
        for _ in range(NB - 1): await g.key('ArrowRight'); await g.wait(120)
        await g.tap('#bkNext'); await g.wait(900)
        play = await g.ev("()=>({open:document.body.classList.contains('bookopen'),played:$('tPlay').disabled||$('title').hidden||PLAYING})")
        ctl.append(("Let's play! closes and presses Play", 0 if not play['open'] and play['played'] else 1, 0))
        bad = [f'{n}: page {got}, wanted {want}' for n, got, want in ctl if got != want]
        if leak: bad.append('arrow keys reached the game')
        d['lines'].append(L('W1', f"What's new book: {NB} pages with pictures; Next, Back, swipe, arrow keys, Escape, ✕, tap outside and Let's play! work; Next stays in the same spot ({prof})",
            not probs and not bad and steady and len(pages) == NB,
            f"{len(pages)} pages; Next's right edge {min(rights) if rights else '?'}–{max(rights) if rights else '?'} px, top {min(tops) if tops else '?'}–{max(tops) if tops else '?'} px; {len(ctl)} controls tried" + (f'; PROBLEMS: {probs[:4]}' if probs else '') + (f'; NOT WORKING: {bad[:4]}' if bad else '')))
        await run.close(g)
    return d

ORDER = ['files', 'counts', 'saves', 'players', 'claude', 'book', 'night3', 'run4'] + [f'crawl_{p}_{part}' for p in CRAWL_DEVICES for part in ['hud'] + list(AREA_GROUPS)] + [f'teacher_{p}' for p in TEACH_DEVICES] + ['pc_keys']
FN = {'files': s_files, 'counts': s_counts, 'saves': s_saves, 'players': s_players, 'claude': s_claude, 'book': s_book, 'night3': lambda run, d: N3.s_night3(run, d, live_w, new_wb, FIX, A.e1_limits), 'run4': lambda run, d: R4.s_run4(run, d, live_w, new_wb, FIX, A.e1_limits)}
for p in CRAWL_DEVICES:
    for part in ['hud'] + list(AREA_GROUPS): FN[f'crawl_{p}_{part}'] = crawl_stage(p, part)
for p in TEACH_DEVICES: FN[f'teacher_{p}'] = teacher_stage(p)
FN['pc_keys'] = s_pc_keys


def close_orphans():
    """A test browser stopped between chat messages leaves 'open' lines with no 'closed' line. Its copy is gone; say so in the log."""
    import re
    p = os.path.join(A.out, f'testlog_{A.tag}.txt')
    if not os.path.exists(p): return
    opened = {}
    for l in open(p).read().splitlines():
        m = re.search(r'ACTION open test copy (\w+) build md5 \w+ on (\S+) (\S+) as (\S+)', l)
        if m: opened.setdefault(m.groups(), []).append(l)
        m = re.search(r'UNDONE closed test copy (\w+) (\S+) (\S+) (\S+?)[: ]', l)
        if m and opened.get(m.groups()): opened[m.groups()].pop()
    with open(p, 'a') as f:
        for k, v in opened.items():
            for _ in v: f.write(f'{time.strftime("%H:%M:%S")} UNDONE closed test copy {" ".join(k)}: the test browser stopped (between chat messages, or after failing to start), so this copy and its saves were thrown away\n')

async def main():
    close_orphans()
    t0 = time.time(); R = {}
    for n in ORDER: R[n] = await stage(n, FN[n])
    nt = n_tour_chunks()
    for p in TOUR_DEVICES:
        for k in range(nt):
            n = f'tour_{p}_{k}'; FN[n] = tour_stage(p, k); ORDER.append(n); R[n] = await stage(n, FN[n])
    if any(r.get('skipped') for r in R.values()): print('[partial run: some stages skipped by --only]'); return
    lines = [l for n in ORDER for l in R[n]['lines']]
    for p in CRAWL_DEVICES:
        parts = [R[f'crawl_{p}_{x}'].get('extra', {}).get('res', {}) for x in ['hud'] + list(AREA_GROUPS)]
        agg = {k: [v for r in parts for v in r.get(k, [])] for k in ('tested', 'dead', 'unreachable', 'stuck', 'covered', 'areas')}
        unf = [r.get('unfinished') for r in parts if r.get('unfinished')]; views = sum(r.get('views', 0) for r in parts)
        bad = {k: agg[k] for k in ('dead', 'unreachable', 'stuck', 'covered') if agg[k]}
        crashed = [x for x in ['hud'] + list(AREA_GROUPS) if any(l[0] == 'X' for l in R[f'crawl_{p}_{x}']['lines'])]
        lines.append(L('C2', f'every spot and button does something ({PROFILES[p]["group"]}, {"finger taps" if PROFILES[p]["touch"] else "keyboard"})', not bad and not unf and not crashed,
            f"{len(agg['tested'])} taps tested in {len(set(agg['areas']))} areas, {views} screens" + (f'; UNFINISHED: {unf}' if unf else '') + (f'; CRASHED parts: {crashed}' if crashed else '') +
            ''.join(f"; {k.upper()} ({len(v)}): {'; '.join(v[:6])}" for k, v in bad.items())))
        wk = R[f'crawl_{p}_town'].get('extra', {}).get('walk')
        lines.append(L('C3', f'walking works ({p})', bool(wk and wk[0]), wk[1] if wk else 'not measured'))
    for p in TEACH_DEVICES:
        t = R[f'teacher_{p}'].get('extra', {}).get('teacher', {}); cls = t.get('classes', [])
        crashed = any(l[0] == 'X' for l in R[f'teacher_{p}']['lines'])
        probs = [c.get('problem') for c in cls if c.get('problem')]
        lines.append(L('T1', f'teacher job plays from the school message to the end of class ({p})', not crashed and len(cls) == 3 and all(c.get('ended') for c in cls) and not probs,
            f"{len(cls)} classes: " + ', '.join(f"{c.get('subject')} {'ended' if c.get('ended') else 'NOT ended'}" for c in cls) + (f'; PROBLEMS: {probs}' if probs else '') + ('; CRASHED' if crashed else '')))
        taps = [x for c in cls for x in c.get('goof_taps', [])]; miss = [x for x in taps if not x['stopped']]
        side = lambda sd: f"{sum(1 for x in taps if x['side'] == sd and x['stopped'])} of {sum(1 for x in taps if x['side'] == sd)}"
        lines.append(L('T2', f'every goofing kid can be stopped, left and right ({p})', bool(taps) and not miss, f'left side {side("left")} taps worked, right side {side("right")}'))
        pap = [pp for c in cls for pp in c.get('papers', [])]; cov = [x for c in cls for x in c.get('covered', [])]
        small = [pp['buttons'] for pp in pap if any(min(b['w'], b['h']) < 44 for b in pp['buttons'])]; gaps = [pp['gap'] for pp in pap if pp.get('gap') is not None]
        lines.append(L('T3', f'homework right and wrong buttons: at least 44 px, at least 12 px apart, never covered ({p})', bool(pap) and not small and gaps and min(gaps) >= 12 and not cov,
            f"{len(pap)} papers; button size {pap[0]['buttons'][0]['w']}x{pap[0]['buttons'][0]['h']} px; smallest gap {min(gaps) if gaps else '?'} px; covered taps: {len(cov)}" + (f' ({cov[:2]})' if cov else '') if pap else 'no papers reached'))
        qt = [q for pp in pap for q in pp.get('qtext', [])]
        low = sorted({f"{q['t'][:18]} {q['c']} {q['fs']} (contrast {T.contrast(q['c'])})" for q in qt if T.contrast(q['c']) < 7 or float(q['fs'][:-2]) < 16})
        lines.append(L('T4', f'homework questions are easy to read: dark text, at least 16 px ({p})', bool(qt) and not low, f'{len(qt)} questions read' + (f'; TOO LIGHT OR SMALL: {low[:3]}' if low else '')))
    kw = R['pc_keys'].get('extra', {}).get('walk')
    lines.append(L('C3', 'walking works (pc-1920)', bool(kw and kw[0]), kw[1] if kw else 'not measured'))
    for p in DROPPED: lines.append(L('C1', f'every screen opens ({p})', None, 'NOT RUN: dropped for now (decision 7 Oct); the full sweep is for big updates'))
    for p in TOUR_DEVICES:
        ch = [R[n] for n in ORDER if n.startswith(f'tour_{p}_')]
        done = sum(c.get('extra', {}).get('done', 0) for c in ch); total = sum(c.get('extra', {}).get('total', 0) for c in ch)
        fails = [f for c in ch for f in c.get('extra', {}).get('fails', [])]
        lines.append(L('C1', f'every screen opens ({p}, light and dark)', total > 0 and done == total and not fails, f'{done} of {total} screens, each in light and dark' + (f'; FAILED ({len(fails)}): {"; ".join(fails[:5])}' if fails else '')))
        wk = ch[0].get('extra', {}).get('walk') if ch else None
        lines.append(L('C3', f'walking works ({p})', bool(wk and wk[0]), wk[1] if wk else 'not measured'))
    NEWB = {md5b(new_wb), md5b(new_c)}   # layout lines judge only screens of the NEW version
    issues = [i for n in ORDER for i in R[n].get('issues', []) if i.get('build') in NEWB]; btn = [b for n in ORDER for b in R[n].get('btn', []) if b.get('build') in NEWB]
    errors = [e for n in ORDER for e in R[n].get('errors', [])]; blocked = sorted(set(b for n in ORDER for b in R[n].get('blocked', [])))
    served = {}
    for n in ORDER:
        for k, v in R[n].get('served', {}).items(): served[k] = served.get(k, 0) + v
    json.dump(issues, open(os.path.join(A.out, 'layout_issues.json'), 'w'), indent=1)
    all_areas = R['counts'].get('extra', {}).get('counts_old', {}).get('areas', [])
    reached = set(R['players'].get('extra', {}).get('areas', []))
    for n in ORDER:
        if n.startswith('crawl_'): reached |= set(R[n].get('extra', {}).get('res', {}).get('areas', []))
    unreached = [x for x in all_areas if x not in reached and x != 'studio' or (x == 'studio' and x not in reached)]
    lines.insert(next((i for i, l in enumerate(lines) if l[0] == 'C3'), len(lines)), L('C2b', 'every area is reached by playing', bool(all_areas) and not unreached, f'{len(reached & set(all_areas))} of {len(all_areas)} areas' + (f'; NOT REACHED: {unreached}' if unreached else '')))
    by = {}
    for i in issues:
        if i['k'] == 'small-target' and min(i.get('size', [99, 99])) >= SMALL_LIMIT: continue
        by.setdefault(i['k'], {}).setdefault(i['el'], i)
    for k, name in (('cut-off', 'nothing is cut off the screen'), ('overlap', 'no buttons overlap'), ('text-overflow', 'all text fits its box'),
                    ('small-target', f'every button is at least {SMALL_LIMIT} px for a finger'), ('low-contrast', 'text is readable in light and dark')):
        v = by.get(k, {})
        ex = '; '.join((e + (f' {v[e].get("size")}' if k == 'small-target' else '') + f' ({v[e].get("profile","")} {v[e].get("theme","")})')[:110] for e in list(v)[:6])
        lines.append(L('C4', name, not v, f'{len(v)} problems' + (': ' + ex if v else '')))
    groups = {}
    for b in btn: groups.setdefault(b['cls'], set()).add((b['font'], b['rad'], b['bw']))
    mixed = {k: sorted(map(list, v)) for k, v in groups.items() if len(v) > 1}
    lines.append(L('C5', 'the same kind of button looks the same everywhere', not mixed, f'{len(groups)} kinds of button' + (f'; MIXED: {json.dumps(dict(list(mixed.items())[:4]))[:300]}' if mixed else '')))
    lines.append(L('C6', 'zero errors in the browser log', not errors, f'{len(errors)} errors' + (': ' + ' | '.join(errors[:4]) if errors else '')))
    lines.append(L('C8', 'test copies never reached the real internet', not blocked, f'{len(blocked)} outside requests stopped' + (f': {blocked[:4]}' if blocked else '')))
    lines.append(L('C1-WK', "every screen in Safari's engine (iPhone, iPad)", None, "NOT RUN: Safari's engine is not installed on this computer" if A.full else 'NOT RUN: dropped for now (decision 7 Oct)'))
    ok, det = C.check_log(os.path.join(A.out, f'testlog_{A.tag}.txt')); lines.append(L('F6', 'every test action is logged and undone', ok, det))
    want = {md5b(new_wb)} | ({md5b(new_c)})
    lines.append(L('F2a', 'the tests used exactly the files to publish', want <= set(served), f'files tested: {sorted(served)}; to publish: {sorted(want)}'))
    if A.published: p = rb(A.published); lines.append(L('F2', 'published Claude version = tested file', md5b(p) == md5b(new_c), f'{md5b(p)} vs {md5b(new_c)}'))
    else: lines.append(L('F2', 'published Claude version = tested file', None, 'NOT RUN: ' + ('dry run' if A.dry_run else 'not published yet')))
    if A.github: p = rb(A.github); lines.append(L('F3', 'GitHub file after upload = new Claude version + same web part, same address', md5b(p) == md5b(new_wb), f'{md5b(p)} vs {md5b(new_wb)}'))
    else: lines.append(L('F3', 'GitHub file after upload = new Claude version + same web part, same address', None, 'NOT RUN: ' + ('dry run' if A.dry_run else 'not uploaded yet')))
    lines.append(L('G', 'real devices, sound, smoothness, two real players online', None, 'NOT VERIFIED: in the "Try it for real" notebook until ticked'))
    mins = round(sum(R[n].get('secs', 0) for n in ORDER) / 60)
    print('\n===== COZY TOWN FINAL CHECK =====')
    kind = "DRY RUN on today's game (nothing changed)" if A.dry_run else ("update, full sweep for a big update" if A.full else "update")
    print(f'{TODAY} · check version {CHECK_VERSION} · {kind}')
    print(f'live Claude {md5b(live_c)} · new Claude {md5b(new_c)} · live GitHub {md5b(live_w)} · new GitHub {md5b(new_wb)}')
    for cid, name, ok, det in lines:
        print(f"{'PASS' if ok else ('NOT RUN' if ok is None and not str(det).startswith('NOT VERIFIED') else ('NOT VERIFIED' if ok is None else 'FAIL'))} | {cid} {name} | {det}")
    fails = [l for l in lines if l[2] is False]; nr = [l for l in lines if l[2] is None]
    print(f"RESULT: {'ALL PASS' if not fails else str(len(fails)) + ' FAIL'}" + (f', {len(nr)} not run or not verified' if nr else '') + f' · {mins} min of testing')
    json.dump(lines, open(os.path.join(A.out, 'result.json'), 'w'), indent=1)

asyncio.run(main())
