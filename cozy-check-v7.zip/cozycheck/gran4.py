"""Run 4, job 8: N24 (the three grandmas: exactly 3, none by the houses, the duck-pond bench, walking and talking, the same places for two players) and the
rewritten night-3 line N6 (out in dry daytime, gone in rain, snow and at night; the pond bench full while they sit and free when they are gone)."""
import json
from night3 import fx, begin

STATE_JS = """()=>{const B=GRAN.bench;return {n:GRAN.g.length,on:GRAN.g.map(q=>q.on),vis:GRAN.g.map(q=>q.p.root.visible),pos:GRAN.g.map(q=>[+q.x.toFixed(2),+q.z.toFixed(2)]),sit:GRAN.g.map(q=>q.sitting),seat:GRAN.g.map(q=>q.seat),
  stop:GRAN.g.map(q=>{const ps=granPose(q.i,realMs());return [ps.stop,GRAN_STOPS[ps.stop].id,ps.moving,ps.arrived,+ps.u.toFixed(1),+ps.d.toFixed(2)];}),bench:B?[+B.x.toFixed(1),+B.z.toFixed(1),seatTaken(B,0),seatTaken(B,1)]:null,
  bub:GRAN.g.map(q=>!!q.bub),fed:LOC.city.ducks.filter(d=>d.pond===0&&d.fed>0).length,crumbs:GRAN.crumbs.filter(c=>c.m.visible).length,day:GRAN.day,plan:GRAN.plan?GRAN.plan.length:0,
  houseBenches:BENCHES.filter(b=>b.loc==='city'&&Math.abs(Math.abs(b.z)-57.25)<.3).map(b=>[+b.x.toFixed(1),+b.z.toFixed(1),!!b.sit[0],!!b.sit[1],seatTaken(b,0),seatTaken(b,1)])};}"""
T0 = 1792497600000   # 2026-10-20 12:00:00 UTC in real milliseconds (the shared clock's input)

async def _at(g, ms, wx='sun', frames=3):
    """The shared clock at this real moment (the game hour follows from it: 15 real minutes make a game day), the weather forced, a few frames."""
    await g.ev("([ms,w])=>{__clockMs(ms);wxForce(w);granPlan(realMs());}", [ms, wx]); await g.ev("(n)=>__run(n)", frames)
    return await g.ev(STATE_JS)
DAY_JS = "(ms)=>{const t=clockAt(ms).time;return t>=9.5&&t<=17.5;}"   # a real moment at which the game clock says daytime (the grandmas are out 9:00 to 18:00)
async def _pond_turn(g, from_ms):
    """The first turn from this moment on with two grandmas at the pond whose 76th second falls in game daytime: [k, ms at 76 s]."""
    return await g.ev("""(ms0)=>{__clockMs(ms0);granPlan(realMs());const k0=Math.floor((ms0-GRAN.day0)/GRAN.T);for(let k=k0;k<GRAN.plan.length;k++){if(GRAN.plan[k].filter(s=>s===0).length!==2)continue;const ms=GRAN.day0+k*GRAN.T+76000,t=clockAt(ms).time;if(t>=9.5&&t<=17.5)return [k,ms];}return null;}""", from_ms)

async def n24(run, new_wb, FIX):
    probs = []; det = []
    if b'const GRAN_STOPS=' not in new_wb or b'function granPlan' not in new_wb: return False, 'the three grandmas are not built yet (job 8)'
    save = fx(FIX, 'save-prenight3-pets.json')
    A = await begin(run, new_wb, 'ipad-landscape', 'n24-grandmas-A', save); Bp = await begin(run, new_wb, 'pc-1366', 'n24-grandmas-B', save)
    for g in (A, Bp): await g.ev("()=>{__goto('city');}")
    moments = await A.ev("(T0)=>{const out=[];let ms=T0;while(out.length<8&&ms<T0+86400000){if(clockAt(ms).time>=9.5&&clockAt(ms).time<=17.5)out.push(ms);ms+=37000+out.length*61000;}return out;}", T0)
    s = await _at(A, moments[0]); det.append(f"{s['n']} grandmas; plan for the real day {s['day']} has {s['plan']} turns; {len(s['houseBenches'])} benches by the town houses, seats never held by a grandma: {all(not b[2] and not b[3] for b in s['houseBenches'])}")
    if s['n'] != 3: probs.append(f"not exactly 3 grandmas: {s['n']}")
    if len(s['houseBenches']) < 6 or any(b[2] or b[3] or b[4] or b[5] for b in s['houseBenches']): probs.append(f'a house bench is still held or taken: {s["houseBenches"]}')
    # the same places on two devices, at several real moments (clocks 1 s apart), and nobody within 3 m of a house bench
    same = []; same1 = []; nearHouse = 0
    for ms in moments:
        sa = await _at(A, ms); sb = await _at(Bp, ms); sb1 = await _at(Bp, ms + 1000)   # B at the same clock moment, then with its clock 1 s ahead
        gap = lambda S1, S2: max(((pa[0] - pb[0]) ** 2 + (pa[1] - pb[1]) ** 2) ** .5 for pa, pb in zip(S1['pos'], S2['pos']))
        same.append(round(gap(sa, sb), 2)); same1.append(round(gap(sa, sb1), 2))
        if [x[:2] for x in sa['stop']] != [x[:2] for x in sb['stop']]: probs.append(f'at the same moment the two devices send a grandma to different places: {sa["stop"]} / {sb["stop"]}')
        for p in sa['pos']:
            if any(((p[0] - b[0]) ** 2 + (p[1] - b[1]) ** 2) ** .5 < 3 for b in sa['houseBenches']): nearHouse += 1
    det.append(f"two devices, 8 moments: the same clock moment: the biggest difference in a grandma's place {max(same)} m (the same turn and stop on both: {'stop' not in ' '.join(probs)}); clocks 1 s apart: {max(same1)} m (1 s of walking is 1.15 m)")
    if max(same) > .35: probs.append(f'the two devices do not agree on where the grandmas are at the same moment: {same}')
    if max(same1) > 1.7: probs.append(f'with clocks 1 s apart the grandmas are more than a second of walking apart: {same1}')
    if nearHouse: probs.append(f'a grandma stood by a town house bench {nearHouse} times')
    # the pond: find a turn where two sit; crumbs and fed ducks within a few seconds of sitting
    pt = await _pond_turn(A, moments[0])
    if not pt: probs.append('no daytime turn of the day puts two grandmas at the pond')
    else:
        pk, pms = pt
        s1 = await _at(A, pms, frames=2)
        det.append(f"turn {pk}: at 76 s two sit {sum(s1['sit'])}, seats {s1['seat']}, the pond bench taken {s1['bench'][2:]}")
        if sum(s1['sit']) != 2 or not (s1['bench'][2] and s1['bench'][3]) or sorted(q for q, st in zip(s1['seat'], s1['sit']) if st) != [0, 1]: probs.append(f'the pond pair does not sit on the two seats: {s1}')
        await A.ev("()=>{P.x=35.6;P.z=-33.4;P.yaw=Math.atan2(-(32.6-P.x),-(-36.6-P.z));P.pitch=.08;}")   # from the pond side, looking at the bench
        await A.ev("(n)=>__run(n)", 480); s2 = await A.ev(STATE_JS)
        det.append(f"8 s later: ducks fed {s2['fed']}, bubbles {s2['bub']}")
        if s2['fed'] < 1: probs.append(f'no duck came for the crumbs: {s2}')
        await A.step(3); await A.shot('grandmas-pond', both=False)
        # the third one, and the two players seeing the same
        sb = await _at(Bp, pms + 1000, frames=2)
        if sum(sb['sit']) != 2: probs.append(f'the other device does not see the pair sitting: {sb}')
    # walking and talking at a shop
    wk = await A.ev("(ms0)=>{__clockMs(ms0);granPlan(realMs());const k0=Math.floor((ms0-GRAN.day0)/GRAN.T);for(let k=k0+1;k<GRAN.plan.length;k++)for(let g=0;g<3;g++){const ms=GRAN.day0+k*GRAN.T;if(GRAN.plan[k][g]!==0&&GRAN.plan[k][g]!==GRAN.plan[k-1][g]&&clockAt(ms).time>=9.5&&clockAt(ms+72000).time<=17.5){const L=granPath(GRAN.plan[k-1][g],GRAN.plan[k][g]).len;if(L>=20&&L<=70)return [k,g,ms,+L.toFixed(1)];}}return null;}", moments[0])
    if not wk: probs.append('nobody walks to a new place in daytime')
    else:
        k, gi, kms, plen = wk
        s5 = await _at(A, kms + 6000, frames=2); s15 = await _at(A, kms + 16000, frames=2); s70 = await _at(A, kms + 72000, frames=2)
        moved = s15['stop'][gi][5] - s5['stop'][gi][5]; chord = ((s5['pos'][gi][0] - s15['pos'][gi][0]) ** 2 + (s5['pos'][gi][1] - s15['pos'][gi][1]) ** 2) ** .5
        det.append(f"turn {k}, grandma {gi}: a {plen} m walk; {moved:.1f} m along her path between 6 s and 16 s (11.5 m expected; {chord:.1f} m as the crow flies), at 72 s standing at {s70['stop'][gi][1]} (arrived {s70['stop'][gi][3]})")
        if moved < 11 or moved > 12 or chord < 3 or not s70['stop'][gi][3] or s70['stop'][gi][0] == 0: probs.append(f'the walk is wrong: {moved} m, {s70["stop"][gi]}')
        await A.ev("([x,z,ms,st])=>{const L=GRAN_STOPS[st].look,dx=L[0]-x,dz=L[1]-z,d=Math.hypot(dx,dz)||1;P.x=x+dx/d*2.4;P.z=z+dz/d*2.4;P.yaw=Math.atan2(-(x-P.x),-(z-P.z));P.pitch=.05;__clockMs(ms);__run(2);}", [s70['pos'][gi][0], s70['pos'][gi][1], kms + 73000, s70['stop'][gi][0]]); s71 = await A.ev(STATE_JS)   # between her and the place, facing her
        det.append(f"a speech bubble about the place, standing next to her: {s71['bub'][gi]}")
        if not s71['bub'][gi]: probs.append('no bubble at the place')
        await A.step(3); await A.shot('grandma-at-a-place', both=False)
        hi = await A.ev("(g)=>{const q=GRAN.g[g],out=[];for(let i=0;i<4;i++){q.target.act();out.push(GRAN.last);}return out;}", gi)
        det.append(f"Say hi 4 times: {len(set(hi))} different lines, never the same twice in a row: {all(hi[i] != hi[i + 1] for i in range(3))}")
        if any(hi[i] == hi[i + 1] for i in range(3)): probs.append(f'the same line twice in a row: {hi}')
    for g in (A, Bp): await g.ev("()=>wxForce(null)")
    errs = A.errors[:] + Bp.errors[:]; await run.close(A); await run.close(Bp)
    if errs: probs.append(f'browser errors: {errs[:2]}')
    return not probs, '; '.join(det) + (f' | PROBLEMS: {probs}' if probs else '')

async def n6(run, new_wb, FIX):
    """The rewritten N6: the three grandmas out in dry daytime, gone in rain, snow and at night; the pond bench full while two sit on it, free when they are gone."""
    probs = []; det = []
    if b'const GRAN_STOPS=' not in new_wb: return False, 'the three grandmas are not built yet (job 8)'
    save = fx(FIX, 'save-prenight3-pets.json')
    g = await begin(run, new_wb, 'ipad-landscape', 'n6-grandmas', save); await g.ev("()=>__goto('city')")
    pt = await _pond_turn(g, T0)
    if not pt: await run.close(g); return False, 'no daytime turn of the day puts two grandmas at the pond'
    pk, ms = pt
    night = await g.ev("(ms)=>{for(let k=0;k<2000;k++){const m=ms+k*GRAN.T;const t=clockAt(m).time;if((t>=21.5||t<6.5)&&GRAN.plan[Math.floor((m-GRAN.day0)/GRAN.T)]&&GRAN.plan[Math.floor((m-GRAN.day0)/GRAN.T)].filter(s=>s===0).length===2)return m;}return null;}", ms)   # a night moment of a pond turn
    res = {}
    for nm, m, wx in (('day', ms, 'sun'), ('night', night or ms, 'sun'), ('rain', ms, 'rain'), ('snow', ms, 'snow'), ('day again', ms, 'sun')):
        s = await _at(g, m, wx); res[nm] = s
        det.append(f"{nm} (game clock {await g.ev('()=>clockStr(S.time)')}): out {s['on']}, drawn (within 48 m of the camera) {s['vis']}, sitting {s['sit']}, pond bench taken {s['bench'][2:]}")
    if not night: probs.append('no night moment found to test')
    if not all(res['day']['on']) or sum(res['day']['sit']) != 2 or not (res['day']['bench'][2] and res['day']['bench'][3]): probs.append('by day the grandmas are not all out / the pair is not on the pond bench')
    for nm in ('night', 'rain', 'snow'):
        if any(res[nm]['on']) or any(res[nm]['vis']) or res[nm]['bench'][2] or res[nm]['bench'][3]: probs.append(f'in {nm} the grandmas are still out or the bench is still taken')
    sat = await g.ev("(m)=>{__clockMs(m);__run(3);const B=GRAN.bench,s=B.seats[0];P.x=s.x+Math.sin(s.yaw)*.6;P.z=s.z+Math.cos(s.yaw)*.6;P.yaw=s.yaw;s.tg.act();const ok=!!P.sit;standUp();P.sit=null;return ok;}", night or ms)
    det.append(f"at night you can sit on the pond bench: {sat}")
    if not sat: probs.append('you cannot sit on the pond bench when the grandmas are gone')
    await g.ev("(m)=>{__clockMs(m);wxForce('sun');__run(3);P.x=35.6;P.z=-33.4;P.yaw=Math.atan2(-(32.6-P.x),-(-36.6-P.z));P.pitch=.08;}", ms); await g.step(20); await g.shot('grandmas-day', both=False)
    await g.ev("()=>wxForce(null)")
    errs = g.errors[:]; await run.close(g)
    if errs: probs.append(f'browser errors: {errs[:2]}')
    return not probs, '; '.join(det) + (f' | PROBLEMS: {probs}' if probs else '')
