"""Run 4, job 7 line N26: the corner map and 📱 Map on every screen size: drawn (never one flat colour), the facing arrow turns the frame you turn, the corner map shows for everyone in town."""
import json
from night3 import fx, begin

MINI_JS = """(yaw)=>{const cv=$('mm');if(!cv)return{missing:true};const n0=MM.n|0,P2=CanvasRenderingContext2D.prototype,r0=P2.rotate,rots=[];
  if(yaw!=null){P2.rotate=function(a){rots.push(a);return r0.call(this,a);};try{P.yaw=yaw;miniTick(.016);}finally{P2.rotate=r0;}}   /* one frame: the arrow must be drawn again, turned to the new facing */
  const N=cv.width,x=cv.getContext('2d'),d=x.getImageData(0,0,N,N).data,px=N/2,pz=N/2,cols=new Set();let pink=0,pinkNear=0;
  for(let j=0;j<N;j+=2)for(let i=0;i<N;i+=2){const q=(j*N+i)*4,r=d[q],g=d[q+1],b=d[q+2];cols.add((r>>4)+','+(g>>4)+','+(b>>4));if(Math.abs(r-255)<36&&Math.abs(g-77)<36&&Math.abs(b-141)<36){pink++;if(Math.hypot(i-px,j-pz)<N*.09)pinkNear++;}}
  const turned=rots.some(a=>Math.abs(Math.atan2(Math.sin(a+P.yaw),Math.cos(a+P.yaw)))<1e-6);   /* the arrow is drawn with rotate(-yaw) */
  return {N,colours:cols.size,pink,pinkNear,turned,drew:(MM.n|0)-n0,shown:!$('job').hidden&&!$('mmBtn').hidden,jobTxt:!$('jobTxt').hidden,nojob:$('job').classList.contains('nojob'),label:$('mmBtn').getAttribute('aria-label'),mmYaw:MM.yaw===P.yaw};}"""
BIG_JS = """()=>{const cv=$('mapc');if(!cv)return{missing:true};const W=cv.width,H=cv.height,x=cv.getContext('2d'),d=x.getImageData(0,0,W,H).data,cols=new Set(),step=Math.max(2,Math.floor(W/160));
  for(let j=0;j<H;j+=step)for(let i=0;i<W;i+=step){const q=(j*W+i)*4;cols.add((d[q]>>4)+','+(d[q+1]>>4)+','+(d[q+2]>>4));}
  return {W,H,css:[cv.clientWidth,cv.clientHeight],colours:cols.size,on:MAPV.on,s:+MAPV.s.toFixed(2)};}"""

async def n26(run, new_wb, FIX):
    probs = []; det = []
    if b'function miniTick' not in new_wb: return False, 'the map fixes are not built yet (job 7)'
    save = fx(FIX, 'save-prenight3-pets.json')
    for prof in ('ipad-landscape', 'iphone-portrait', 'iphone-landscape', 'pc-1366', 'android-tablet-portrait'):
        g = await begin(run, new_wb, prof, 'n26-map-' + prof, save)
        await g.ev("()=>{__goto('city');S.job=null;jobHud(true);P.x=-20;P.z=14;P.yaw=0;miniTick(1);}"); await g.step(3)
        m = await g.ev(MINI_JS, None)
        if m.get('missing'): probs.append(f'{prof}: no corner map canvas'); await run.close(g); continue
        det.append(f"{prof}: no job: corner map shown {m['shown']}, job text hidden {not m['jobTxt']}, {m['colours']} colours on {m['N']} px, label {m['label']!r}")
        if not m['shown'] or m['jobTxt'] or m['colours'] < 12 or not m['nojob'] or 'big map' not in (m['label'] or ''): probs.append(f'{prof}: corner map without a job is wrong: {m}')
        # the arrow follows every turn at once (one frame each, no waiting)
        turns = []
        for yaw in (0.4, 1.2, 2.5, -2.0, -0.6):
            r = await g.ev(MINI_JS, yaw); turns.append((r['drew'], r['turned'], r['pinkNear']))
        det.append(f"{prof}: 5 turns in a row, each one frame: (drawn that frame, the arrow turned to the new facing, pink arrow pixels at your spot): {turns}")
        if any(d != 1 or not t or pk < 4 for d, t, pk in turns): probs.append(f'{prof}: the facing arrow does not turn with you every frame: {turns}')
        # with each job: the box shows the text and the map, the map is drawn (the teacher and hairstylist used to get a green circle)
        for jb in ('teacher', 'hair', 'delivery', 'designer'):
            r = await g.ev("(j)=>{S.job=j;jobHud(true);miniTick(1);const cv=$('mm'),N=cv.width,d=cv.getContext('2d').getImageData(0,0,N,N).data,c=new Set();for(let q=0;q<d.length;q+=32)c.add((d[q]>>4)+','+(d[q+1]>>4)+','+(d[q+2]>>4));return {shown:!$('job').hidden&&!$('mmBtn').hidden,txt:!$('jobTxt').hidden,colours:c.size,label:$('mmBtn').getAttribute('aria-label')};}", jb)
            if not r['shown'] or not r['txt'] or r['colours'] < 12 or 'big map' not in (r['label'] or ''): probs.append(f'{prof}: corner map with the {jb} job wrong: {r}')
        det.append(f"{prof}: with the teacher, hair, delivery and designer jobs the box shows text and a drawn map")
        await g.ev("()=>{S.job='delivery';jobHud(true);miniTick(1);}"); await g.step(2); tp = await g.tap('#mmBtn'); await g.step(8)
        tb = await g.ev("()=>({on:MAPV.on,canvas:!!$('mapc'),picker:typeof openDot!=='undefined'||!!document.querySelector('[data-a^=dot]')})")
        det.append(f"{prof}: tap on the corner map with a job: {tp}, big map open {tb['on'] and tb['canvas']}, dot picker anywhere {tb['picker']}")
        if tp != 'ok' or not tb['on'] or not tb['canvas'] or tb['picker']: probs.append(f'{prof}: a tap on the corner map with a job does not open the big map, or the dot picker is still there: {tp} {tb}')
        await g.ev("()=>{closePanel();S.job=null;jobHud(true);}"); await g.step(3)
        if prof == 'ipad-landscape':
            pl = await g.ev("()=>{openPhone('map');const B=mapB(),it=new Set(mapItems().map(i=>i.k)),miss=[];for(const p of PLACES.filter(mapShown).concat(MAP_FARM)){const a=(MAP_AT[p.id]||[p.x,p.z]);if(!it.has(p.id)||a[0]<B.x1||a[0]>B.x2||a[1]<B.z1||a[1]>B.z2)miss.push(p.id);}const n=PLACES.filter(mapShown).length;closePanel();return {n,farm:MAP_FARM.map(p=>p.id),miss};}")
            det.append(f"{prof}: big map: {pl['n']} places + farm places {pl['farm']} inside its bounds, missing {pl['miss']}")
            if pl['miss'] or pl['n'] < 20 or len(pl['farm']) < 4: probs.append(f'{prof}: places missing from the big map: {pl}')
            for nm, js in (('farm', 'P.x=-100;P.z=-101;'), ('trail', 'P.x=-101;P.z=-152.4;'), ('lane', 'P.x=laneEnd()+40;P.z=0;')):
                r = await g.ev("(js)=>{__goto('city');S.job=null;jobHud(true);eval(js);miniTick(1);const cv=$('mm'),N=cv.width,d=cv.getContext('2d').getImageData(0,0,N,N).data,c=new Set();for(let q=0;q<d.length;q+=32)c.add((d[q]>>4)+','+(d[q+1]>>4)+','+(d[q+2]>>4));return {shown:!$('mmBtn').hidden,colours:c.size};}", js)
                det.append(f"{prof}: corner map at the {nm}: {r['colours']} colours"); await g.step(2); await g.shot('corner-map-' + nm, both=False)
                if not r['shown'] or r['colours'] < 12: probs.append(f'{prof}: the corner map at the {nm} is flat or hidden: {r}')
            c = await g.ev("()=>{P.x=-20;P.z=14;drawMini();const cv=$('mm'),t0=performance.now();for(let i=0;i<200;i++){P.x+=.05;drawMini();}cv.getContext('2d').getImageData(0,0,1,1);return +((performance.now()-t0)/200).toFixed(3);}")
            det.append(f"{prof}: one corner-map drawing {c} ms (200 in a row)")
            if not (c < 1): probs.append(f'{prof}: a corner-map drawing costs {c} ms (limit 1 ms)')
        inside = await g.ev("()=>{S.job=null;__goto('salon');jobHud(true);const vis=()=>!$('job').hidden&&!$('mmBtn').hidden&&$('mmBtn').offsetParent!==null;const a=!vis();__goto('city');jobHud(true);return [a,!vis()];}")
        det.append(f"{prof}: corner map hidden indoors {inside[0]}, back in town {not inside[1]}")
        if not inside[0] or inside[1]: probs.append(f'{prof}: the corner map shows indoors or stays hidden in town: {inside}')
        await g.shot('corner-map-' + prof, both=False)
        # the big map
        await g.ev("()=>{openPhone('map');}"); await g.step(12); b = await g.ev(BIG_JS)
        if b.get('missing'): probs.append(f'{prof}: the big map has no canvas')
        else:
            det.append(f"{prof}: 📱 Map {b['css'][0]}x{b['css'][1]} css px, {b['colours']} colours, zoom {b['s']}")
            if b['colours'] < 30 or b['css'][0] < 100 or b['css'][1] < 100: probs.append(f'{prof}: the big map is flat or tiny: {b}')
        await g.shot('big-map-' + prof, both=False)
        await g.ev("()=>{closePanel();}"); await g.step(3)
        errs = g.errors[:]; await run.close(g)
        if errs: probs.append(f'{prof}: browser errors: {errs[:2]}')
    return not probs, '; '.join(det) + (f' | PROBLEMS: {probs}' if probs else '')
