"""Make the Claude version from a GitHub file: remove the online part (online-part.json), nothing else.
Usage: python3 strip_online.py GITHUB.html CLAUDE_OUT.html
Stops with an error if a block of the online part is not found exactly once, so nothing is guessed."""
import json, os, sys, hashlib
HERE = os.path.dirname(os.path.abspath(__file__))
blocks = json.load(open(os.path.join(HERE, 'online-part.json')))['blocks']
src, out = sys.argv[1], sys.argv[2]
L = open(src, encoding='utf-8').read().split('\n'); rm = set()
for b in blocks:
    hits = [k for k in range(len(L) - len(b) + 1) if L[k:k + len(b)] == b]
    if len(hits) != 1: sys.exit(f'STOP: online-part block starting {b[0][:60]!r} found {len(hits)} times in {src}')
    rm.update(range(hits[0], hits[0] + len(b)))
res = '\n'.join(l for i, l in enumerate(L) if i not in rm)
open(out, 'w', encoding='utf-8').write(res)
print(f'{out}: removed {len(rm)} online-part lines; md5 {hashlib.md5(res.encode()).hexdigest()}')
