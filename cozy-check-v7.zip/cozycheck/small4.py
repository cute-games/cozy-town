"""Run 4, job 9 lines: N27 (trash), N29 (pond without its bridge), N35 (the Notepad switch), N41 (the bus with the one clock)."""
import json
from night3 import fx, begin

async def n27(run, new_wb, FIX):
    probs = []; det = []
    if b"const kind=['can','paper','peel','cup'][k%4]" not in new_wb: return False, 'the new trash is not built yet (job 9)'
    save = fx(FIX, 'save-prenight3-pets.json')
    g = await begin(run, new_wb, 'ipad-landscape', 'n27-trash', save)
    r = await g.ev("""()=>{__goto('city');const kinds={};for(const l of LITTER){const k=l.g.userData.kind||'?';kinds[k]=(kinds[k]||0)+1;}
      const it=LITTER[0],c0=S.coins,n0=LITTER.length;it.target.act();return {n:n0,kinds,picked:LITTER.length===n0-1&&S.coins===c0+3&&S.litter.got.includes(it.k),spots:LITTER_SPOTS.length};}""")
    det.append(f"{r['n']} pieces of trash out of {r['spots']} spots today, kinds {r['kinds']}; picking one up: {r['picked']} (+3 coins, remembered)")
    if set(r['kinds']) - {'can', 'paper', 'peel', 'cup'} or len(r['kinds']) < 3: probs.append(f'wrong kinds of trash: {r["kinds"]}')
    if not r['picked']: probs.append('picking up does not work as before')
    # every kind seen over a week of days
    seen = await g.ev("()=>{const all={};for(let d=1;d<=8;d++){S.day=d;spawnLitter();for(const l of LITTER)all[l.g.userData.kind]=1;}return Object.keys(all).sort();}")
    det.append(f"over 8 days the trash kinds are {seen}")
    if sorted(seen) != ['can', 'cup', 'paper', 'peel']: probs.append(f'a kind of trash never shows: {seen}')
    await g.ev("()=>{const l=LITTER.find(x=>x.g.userData.kind==='peel')||LITTER[0];P.x=l.x+1.2;P.z=l.z+1.2;P.yaw=Math.atan2(-(l.x-P.x),-(l.z-P.z));P.pitch=.55;}"); await g.step(4); await g.shot('trash-peel', both=False)
    await g.ev("()=>{const l=LITTER.find(x=>x.g.userData.kind==='can')||LITTER[0];P.x=l.x+1.2;P.z=l.z+1.2;P.yaw=Math.atan2(-(l.x-P.x),-(l.z-P.z));P.pitch=.55;}"); await g.step(4); await g.shot('trash-can', both=False)
    errs = g.errors[:]; await run.close(g)
    if errs: probs.append(f'browser errors: {errs[:2]}')
    return not probs, '; '.join(det) + (f' | PROBLEMS: {probs}' if probs else '')

async def n29(run, new_wb, FIX):
    probs = []; det = []
    if b'function buildBridge' in new_wb or b'br:1' in new_wb: return False, 'the pond bridge is still built (job 9)'
    save = fx(FIX, 'save-prenight3-pets.json')
    g = await begin(run, new_wb, 'ipad-landscape', 'n29-pond', save)
    r = await g.ev("""()=>{__goto('city');const L=LOC.city,p=PONDS[0],walk=(x0,z0,x1,z1)=>{let x=x0,z=z0;for(let i=0;i<200;i++){const dx=x1-x,dz=z1-z,d=Math.hypot(dx,dz);if(d<.05)break;const s=Math.min(.12,d);[x,z]=collideXZ(x+dx/d*s,z+dz/d*s,.3,L);}return Math.hypot(x-p.x,z-p.z);};
      const closest=Math.min(walk(p.x,p.z-5,p.x,p.z+5),walk(p.x-5,p.z,p.x+5,p.z),walk(p.x+3.5,p.z-3.5,p.x-3.5,p.z+3.5),walk(p.x+.5,p.z-5,p.x+.5,p.z+5));
      let planks=0;const v=new THREE.Vector3();L.g.traverse(m=>{if(m.isMesh&&m.geometry&&m.geometry.type==='TubeGeometry'){m.getWorldPosition(v);if(!m.geometry.boundingSphere)m.geometry.computeBoundingSphere();const c=m.geometry.boundingSphere.center.clone().applyMatrix4(m.matrixWorld);if(Math.hypot(c.x-p.x,c.z-p.z)<4)planks++;}});   /* hand rails near the pond (the lake pier has its own ropes) */
      const ducks=L.ducks.filter(d=>d.cx===undefined).length,inter=L.inter.filter(t=>t.label==='Feed the ducks').length,cols=L.cols.filter(c=>c.walk&&c.walk.some(w=>Math.hypot(w.ax-p.x,w.az-p.z)<6)).length;   /* walk strips through this pond's water */
      return {closest:+closest.toFixed(2),r:p.r,tubes:planks,ducks,inter,walkStrips:cols,h:brAt('city',p.x,p.z)};}""")
    det.append(f"walking at the pond from four sides stops {r['closest']} m from its middle (the water's edge is {r['r']} m); hand-rail tubes left: {r['tubes']}; ducks {r['ducks']}, Feed-the-ducks spots {r['inter']}, walk strips through water {r['walkStrips']}, height over the pond {r['h']}")
    if r['closest'] < r['r'] + .25: probs.append(f'you can still walk onto the water: {r}')
    if r['tubes'] or r['walkStrips'] or r['h']: probs.append('bits of the bridge are still there')
    if r['ducks'] < 2 or r['inter'] < 1: probs.append('the ducks or the feeding spot went with the bridge')
    await g.ev("()=>{P.x=36.2;P.z=-30.5;P.yaw=Math.PI;P.pitch=.2;}"); await g.step(4); await g.shot('pond-no-bridge', both=False)
    errs = g.errors[:]; await run.close(g)
    if errs: probs.append(f'browser errors: {errs[:2]}')
    return not probs, '; '.join(det) + (f' | PROBLEMS: {probs}' if probs else '')

async def n35(run, new_wb, FIX):
    probs = []; det = []
    if b'ACT.spad=' not in new_wb: return False, 'the Notepad switch is not built yet (job 9)'
    save = fx(FIX, 'save-prenight3-pets.json')
    g = await begin(run, new_wb, 'ipad-landscape', 'n35-notepad', save)
    vis = "()=>{const p=$('pad');return !p.hidden&&p.offsetParent!==null&&p.getBoundingClientRect().width>40;}"
    r0 = await g.ev("()=>{__goto('city');S.job=null;dcardUpd(true);PAD.pages[PAD.i]=PAD.pages[PAD.i]||[];return {on:SET.pad!==false,pages:JSON.stringify(PAD.pages).length};}"); v0 = await g.ev(vis)
    det.append(f"default: switch on {r0['on']}, notepad shown {v0}")
    if not r0['on'] or not v0: probs.append('the notepad is not on and shown by default')
    await g.ev("()=>{openSettings();}"); await g.step(2)
    btn = await g.ev("()=>{const b=document.querySelector('#card [data-a=\"spad\"]');return b?{text:b.textContent,w:b.getBoundingClientRect().width,h:b.getBoundingClientRect().height}:null;}")
    det.append(f"Settings has the switch: {btn}")
    if not btn or btn['h'] < 44: probs.append(f'no Notepad switch in Settings, or too small: {btn}')
    await g.ev("()=>{ACT.spad();}"); await g.step(3); v1 = await g.ev(vis); r1 = await g.ev("()=>({on:SET.pad!==false,saved:(JSON.parse(localStorage.getItem('cozytown-settings')||'{}').pad),pages:JSON.stringify(PAD.pages).length,btn:(document.querySelector('#card [data-a=\"spad\"]')||{}).textContent})")
    det.append(f"after Off: shown {v1}, switch {r1['btn']!r}, saved {r1['saved']}, notes kept {r1['pages'] == r0['pages']}")
    if v1 or r1['on'] or r1['saved'] is not False: probs.append(f'Off does not hide the notepad / is not saved: {r1}, shown {v1}')
    await g.shot('notepad-off', both=False)
    await g.ev("()=>{ACT.spad();}"); await g.step(3); v2 = await g.ev(vis); r2 = await g.ev("()=>({on:SET.pad!==false,pages:JSON.stringify(PAD.pages).length})")
    det.append(f"after On: shown {v2}, notes kept {r2['pages'] == r0['pages']}")
    if not v2 or not r2['on'] or r2['pages'] != r0['pages']: probs.append(f'On does not bring the notepad back with its notes: {r2}, shown {v2}')
    await g.ev("()=>{closePanel();}"); await g.step(2); await g.shot('notepad-on', both=False)
    # the designer card still takes the notepad's place while it shows, and the notepad comes back after
    r3 = await g.ev("()=>{S.job='designer';dcardUpd(true);const a=$('pad').hidden;S.job=null;dcardUpd(true);return [a,$('pad').hidden];}")
    det.append(f"with the designer card the notepad steps aside {r3[0]} and comes back {not r3[1]}")
    if not r3[0] or r3[1]: probs.append(f'the designer card and the notepad switch fight: {r3}')
    errs = g.errors[:]; await run.close(g)
    if errs: probs.append(f'browser errors: {errs[:2]}')
    return not probs, '; '.join(det) + (f' | PROBLEMS: {probs}' if probs else '')

async def n41(run, new_wb, FIX):
    probs = []; det = []
    save = fx(FIX, 'save-prenight3-pets.json')
    A = await begin(run, new_wb, 'ipad-landscape', 'n41-bus-A', save); Bp = await begin(run, new_wb, 'pc-1366', 'n41-bus-B', save)
    JS = """()=>{__goto('city');const weeks=[];for(let w=1;w<=6;w++){const d0=(w-1)*7+1,days=[];for(let d=d0;d<d0+7;d++)if(busArr(d)!==undefined)days.push([wdName(d),busArr(d)]);weeks.push(days);}
      return {weeks,day:S.day,time:+S.time.toFixed(2),ms:realMs()};}"""
    a = await A.ev(JS); b = await Bp.ev(JS)
    det.append(f"bus days per week (6 weeks): {[len(w) for w in a['weeks']]}; the two devices agree on every bus day and hour: {a['weeks'] == b['weeks']}")
    if any(len(w) != 3 for w in a['weeks']): probs.append(f'not 3 bus days in every week: {a["weeks"]}')
    if a['weeks'] != b['weeks']: probs.append('the two devices disagree on the bus days')
    # the pill by the park stop: on a day without a bus it names the weekday of the next bus; on a bus day the time
    r = await A.ev("""()=>{const out=[],d0=S.day;for(let d=d0;d<d0+10;d++){__setClock(d,9.5);P.x=-14.3;P.z=5.2;busTipUpd('park');const el=$('busTip');const n=busNext('park','beach');out.push({d,wd:wdName(d),bus:busArr(d),tip:el?el.textContent:'',next:n?[wdName(n.d),n.s.a]:null});}return out;}""")
    noBus = [x for x in r if x['bus'] is None]; withBus = [x for x in r if x['bus'] is not None]
    det.append(f"10 mornings at the park stop: {len(withBus)} bus days, {len(noBus)} without; a morning without a bus says e.g. {noBus[0]['tip'] if noBus else '-'}; a bus day says e.g. {withBus[0]['tip'] if withBus else '-'}")
    for x in noBus:
        if not x['next'] or x['next'][0][:3] not in x['tip']: probs.append(f"the pill does not name the next bus's weekday: {x}")
    for x in withBus:
        if 'Next bus' not in x['tip'] and 'bus' not in x['tip'].lower(): probs.append(f'no bus pill on a bus day: {x}')
    await A.ev("()=>{__setClock(null,9.5);P.x=-14.3;P.z=5.2;P.yaw=-1.2;P.pitch=.1;}"); await A.step(6); await A.shot('bus-pill', both=False)
    errs = A.errors[:] + Bp.errors[:]; await run.close(A); await run.close(Bp)
    if errs: probs.append(f'browser errors: {errs[:2]}')
    return not probs, '; '.join(det) + (f' | PROBLEMS: {probs}' if probs else '')
