"""Run 4, job 13: N36 (furniture: at least 60 new pieces across every kind, each buyable, placeable, saved and seen by a visitor)."""
import json
from night3 import fx, begin

KINDS = {'bed': ['canopybed', 'daybed', 'crib', 'carbed'], 'seat': ['cornersofa', 'loveseat', 'stool', 'barstool', 'rocking', 'eggchair', 'woodbench', 'pouf'],
         'table': ['coffeetable', 'sidetable', 'diningtable', 'roundtable', 'nightstand', 'vanity'], 'lamp': ['floorlamp', 'tablelamp', 'starlamp', 'neon', 'lantern'],
         'rug': ['rughearts', 'rugstripe', 'rugstar', 'doormat'], 'plant': ['palm', 'monstera', 'orchid', 'herbs', 'bamboo', 'hangplant'],
         'shelf': ['cubeshelf', 'cornershelf', 'chest', 'coatrack', 'shoerack', 'laddershelf'], 'kitchen': ['island', 'oven', 'dishwasher', 'coffeecorner', 'trolley', 'spicerack'],
         'bathroom': ['shower', 'toilet', 'towelrack', 'bathmat', 'laundry'], 'kids': ['slide', 'playtent', 'blocks', 'toytrain', 'drumkit', 'chalkboard'],
         'decoration': ['bigvase', 'candles', 'photoframe', 'wallclock', 'bunting', 'snowglobe', 'cuckoo', 'poster'], 'outdoor': ['sunlounger', 'parasol', 'birdbath', 'bbq', 'flamingo', 'picnictable'],
         'disco': ['discofloor', 'discoball']}

async def n36(run, new_wb, FIX):
    probs = []; det = []
    if b'r4:1' not in new_wb or b"discofloor:{" not in new_wb: return False, 'the new furniture is not built yet (job 13)'
    save = fx(FIX, 'save-prenight3-bighouse.json')
    A = await begin(run, new_wb, 'ipad-landscape', 'n36-A', dict(save, name='ZZTEST-FURN', coins=99999))
    info = await A.ev("""()=>{const out={keys:[],bad:[],kinds:{}};for(const k of Object.keys(FURN)){const F=FURN[k];if(!F.r4)continue;out.keys.push(k);
      const inShop=BUY_FURN.indexOf(k)>=0,ok={shop:inShop,price:F.p>0,size:F.w>0&&F.d>0,cols:!F.cols||F.cols.length>=2,use:!F.use||['sleep','sit','lamp','dress','cook','bath','piano'].indexOf(F.use)>=0};
      let parts=0,bb=null;try{const g=buildFurn(k,F.cols?F.cols[0]:undefined);g.traverse(o=>{if(o.isMesh)parts++;});g.updateMatrixWorld(true);bb=new THREE.Box3().setFromObject(g);}catch(e){ok.build='error '+e.message;}
      const fin=bb&&[bb.min.x,bb.min.y,bb.min.z,bb.max.x,bb.max.y,bb.max.z].every(Number.isFinite);ok.parts=parts>=1;ok.finite=!!fin;
      if(fin){const w=bb.max.x-bb.min.x,d=bb.max.z-bb.min.z,h=bb.max.y;ok.fits=w<=F.w+.45&&d<=F.d+.45&&h<=3.2&&bb.min.y>-.05;ok.box=[+w.toFixed(2),+d.toFixed(2),+h.toFixed(2)];}
      const badKeys=Object.keys(ok).filter(q=>q!=='box'&&ok[q]!==true);if(badKeys.length)out.bad.push([k,badKeys,ok.box]);}
      out.n=out.keys.length;out.cols=out.keys.filter(k=>FURN[k].cols&&FURN[k].cols.length>=2).length;return out;}""")
    det.append(f"{info['n']} new pieces (r4), {info['cols']} with several colours; builds, fits its footprint, buyable and priced: {info['n'] - len(info['bad'])} of {info['n']}")
    if info['n'] < 60: probs.append(f"only {info['n']} new pieces")
    if info['bad']: probs.append(f"pieces with a problem: {info['bad'][:8]}")
    missing = {kind: [k for k in ks if k not in info['keys']] for kind, ks in KINDS.items()}
    missing = {k: v for k, v in missing.items() if v}
    det.append(f"kinds covered: {len(KINDS) - len(missing)} of {len(KINDS)}" + (f" (missing {missing})" if missing else ''))
    if missing: probs.append(f'kinds not covered: {missing}')
    # the catalog shows them, thumbnails draw, the designer job can use most of them
    cat = await A.ev("""(keys)=>{__goto('home');openCatalog('buy');const n=keys.filter(k=>!!document.querySelector('#card [data-a="csel:'+k+'"]')).length;closePanel();
      const th=keys.slice(0,6).map(k=>{const u=thumb(k,FURN[k].cols?FURN[k].cols[0]:undefined);return u&&u.length>200;});const ds=keys.filter(k=>DS_ALL.indexOf(k)>=0).length;return {n,th,ds};}""", info['keys'])
    det.append(f"in the shop's list {cat['n']}, thumbnails drawn {sum(cat['th'])}/6, in the designer's pool {cat['ds']}")
    if cat['n'] < info['n'] or not all(cat['th']) or cat['ds'] < 50: probs.append(f'catalog/thumbnails/designer: {cat}')
    # placing and buying: every piece placed in the house once; a few bought through the catalog; saved and reloaded
    pl = await A.ev("""(keys)=>{__goto('home');const out={placed:0,fail:[]};for(const k of keys){const F=FURN[k];const it={t:k,c:F.cols?F.cols[0]:null,x:F.hang?0:0,z:F.hang?-HOMED+.3:0,r:0,u:'zz36'+k};try{S.home.items.push(it);addHomeItem(it);const rec=[...HOME_ITEMS.values()].find(r=>r.it===it);if(rec&&rec.g.children.length)out.placed++;else out.fail.push(k);removeHomeItem(it.u);S.home.items.splice(S.home.items.indexOf(it),1);}catch(e){out.fail.push(k+':'+e.message);}}
      const c0=S.coins;CAT.sel='loveseat';CAT.col=FURN.loveseat.cols[0];ACT.cbuy();out.bought=c0-S.coins;out.placing=!!DECO.placing;if(DECO.placing)decoCancel();
      const five=keys.slice(0,5).map(k=>({t:k,c:FURN[k].cols?FURN[k].cols[0]:null,x:1,z:1,r:0,u:'zzk'+k}));for(const it of five){S.home.items.push(it);addHomeItem(it);}saveLocal();const js=JSON.parse(saveJSON());out.saved=five.filter(it=>js.home.items.some(j=>j.u===it.u&&j.t===it.t)).length;
      const hm=homeSnap(100000);out.snap=five.filter(it=>(hm.i||'').indexOf(it.t+',')>=0).length;window.__hm=hm;return out;}""", info['keys'])
    det.append(f"placed in the house one by one: {pl['placed']} (failed {pl['fail'][:5]}); bought a loveseat from the catalog for {pl['bought']} coins (placing {pl['placing']}); 5 pieces saved and read back {pl['saved']}/5, in the home presence {pl['snap']}/5")
    if pl['placed'] != info['n'] or pl['fail'] or pl['bought'] != 190 or pl['saved'] != 5 or pl['snap'] != 5: probs.append(f'placing/buying/saving: {pl}')
    hm = await A.ev("()=>window.__hm")
    Bp = await begin(run, new_wb, 'pc-1366', 'n36-B', dict(fx(FIX, 'save-prenight3-pets.json'), name='ZZTEST-FURNB'))
    vb = await Bp.ev("(hm)=>{visFill(hm);const L=LOC.visit;return {items:L.items.children.length,parts:L.items.children.map(c=>{let n=0;c.traverse(o=>{if(o.isMesh)n++;});return n;})};}", hm)
    det.append(f"a visitor builds the host's room: {vb['items']} pieces, parts {vb['parts'][:8]}")
    if vb['items'] < 5 or any(p < 1 for p in vb['parts']): probs.append(f'the visitor does not see the new pieces: {vb}')
    await A.ev("()=>{P.x=LOC.home.ox-3;P.z=LOC.home.oz+3.5;P.yaw=Math.PI*.78;P.pitch=.05;}"); await A.step(4); await A.shot('new-furniture-in-the-house', both=False)
    errs = A.errors[:2] + Bp.errors[:2]; await run.close(A); await run.close(Bp)
    if errs: probs.append(f'browser errors: {errs}')
    return not probs, '; '.join(det) + (f' | PROBLEMS: {probs}' if probs else '')
