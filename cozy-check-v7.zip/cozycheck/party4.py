"""Run 4, job 17: N39 (parties: host at the mailbox and pick a time; every online test player gets the note with the host's name and can accept or decline;
with a disco floor and ball the dance game runs for two; hits make dance moves; the score bar slides smoothly (never jumps), even = middle with both faces; an old version doesn't crash)."""
import asyncio, json
from night3 import fx, begin

MAIL = [-15.4, -7.1]

async def both(pages, n=6, sleep=.25):
    for g in pages: await g.step(n)
    await asyncio.sleep(sleep)

async def until(pages, g, js, tries=40, n=6, sleep=.25):
    for _ in range(tries):
        if await g.ev(js): return True
        await both(pages, n, sleep)
    return False

async def n39(run, live_w, new_wb, FIX):
    probs = []; det = []
    try: return await n39_body(run, live_w, new_wb, FIX, probs, det)
    except Exception as e:
        import traceback; traceback.print_exc()
        return False, '; '.join(det) + f' | the test itself failed: {e!r}'[:400]

async def n39_body(run, live_w, new_wb, FIX, probs, det):
    if b'function hpMailMenu' not in new_wb or b'function dnPress' not in new_wb: return False, 'parties and the dance game are not built yet (job 17)'
    base = fx(FIX, 'save-prenight3-pets.json')
    A_save = dict(base, name='ZZTEST-HOSTA', coins=900, px=-17, pz=-4.6); A_save.pop('hp', None); A_save.pop('rsvp', None)
    A_save['home'] = dict(base.get('home') or {}); items = [dict(it) for it in (A_save['home'].get('items') or []) if it.get('t') not in ('discofloor', 'discoball')]
    items += [{'u': 'zzdf', 't': 'discofloor', 'c': '', 'x': 0, 'z': 0, 'r': 0, 'f': 0}, {'u': 'zzdb', 't': 'discoball', 'c': '', 'x': 0, 'z': -3.2, 'r': 0, 'f': 0, 'on': 1}]
    A_save['home']['items'] = items
    B_save = dict(base, name='ZZTEST-GUESTB', coins=100, px=-15.5, pz=-4.6); B_save.pop('hp', None); B_save.pop('rsvp', None)
    C_save = dict(base, name='ZZTEST-OLDC', px=-14, pz=-4.6)
    A = await begin(run, new_wb, 'ipad-landscape', 'n39-A', A_save); B = await begin(run, new_wb, 'pc-1366', 'n39-B', B_save)
    C = await begin(run, live_w, 'iphone-landscape', 'n39-Cold', C_save)
    P3 = (A, B, C); P2 = (A, B)
    noon = await A.ev("()=>msAt(clockNow().day,12)")
    for g in P3: await g.ev("(ms)=>__clockMs(ms)", noon); await g.ev("()=>__goto('city')")
    ok = await until(P3, A, "()=>MP.peers.size>=2")
    det.append(f"three players online together: {ok} (A sees {await A.ev('()=>[...MP.peers.values()].map(a=>a.nm)')})")
    if not ok: probs.append('the three test players did not meet online')
    # A: the mailbox -> host a party -> pick the first time
    m = await A.ev("()=>{const mb=CUR.inter.find(q=>/Mailbox/.test(typeof q.label==='function'?q.label():q.label));if(!mb)return null;P.x=mb.x;P.z=mb.z+1.3;P.yaw=0;__run(3);const t=findTarget();const lab=t?(typeof t.label==='function'?t.label():t.label):null;if(t&&/Mailbox/.test(lab)){TARGET=t;useTarget();}return lab;}")
    await A.step(2)
    menu = await A.ev("()=>({mail:!!document.querySelector('#card [data-a=hpmail]'),plan:!!document.querySelector('#card [data-a=hpplan]')})")
    r1 = await A.tap('#card [data-a="hpplan"]'); await A.step(2)
    opts = await A.ev("()=>[...document.querySelectorAll('#card [data-a^=\"hpset:\"]')].map(b=>b.textContent.trim())")
    r2 = await A.tap('#card [data-a^="hpset:"]'); await A.step(3)
    hp = await A.ev("()=>S.hp?{id:S.hp.id,at:S.hp.at,h:S.hp.h,d:S.hp.d,future:S.hp.at>realMs()}:null")
    det.append(f"A at the mailbox: button '{m}', menu mail {menu['mail']} / party {menu['plan']}, times offered {opts}, picked -> party {hp and {'h': hp['h'], 'future': hp['future']}}")
    if not m or not menu['mail'] or not menu['plan'] or len(opts) < 2 or not hp or not hp['future']: probs.append('hosting at the mailbox')
    # B and C: B gets the note with A's name and a card; the old C just carries on
    got = await until(P3, B, "()=>(!!$('hpCard')&&!$('hpCard').hidden)")
    await asyncio.sleep(.5); await B.step(2)   # (the card pops in over .35 s: measure it when it stands still)
    note = await B.ev("()=>({t:$('hpCard').querySelector('.kc-t').textContent,x:$('hpCard').querySelector('.kc-m').textContent,card:(!!$('hpCard')&&!$('hpCard').hidden),btns:[...document.querySelectorAll('#hpCard .btn')].map(b=>[b.textContent.trim(),b.offsetWidth,b.offsetHeight]),anim:$('hpCard').getAnimations().length,noteUp:!$('note').hidden})")
    det.append(f"B gets the news: {got}; the card '{note['t']}: {note['x']}' with {note['btns']} (stage 3: the card is the notification; no second note behind it: {not note['noteUp']})")
    if not got or 'ZZTEST-HOSTA' not in note['x'] or 'hosting a party' not in note['x'] or len(note['btns']) != 2 or any(w < 44 or h < 44 for _, w, h in note['btns']) or note['noteUp']: probs.append('the invitation on B')
    await B.shot('party-invitation', both=False)
    c_ok = await C.ev("()=>({peers:MP.peers.size,seesA:[...MP.peers.values()].some(a=>a.nm==='ZZTEST-HOSTA'),cur:CUR.id})")
    # B says yes; the host hears it
    r3 = await B.tap('#hpYes'); await both(P3, 6, .3); await both(P3, 6, .3)
    yes = await B.ev("(id)=>({rsvp:S.rsvp&&S.rsvp[id],card:(!!$('hpCard')&&!$('hpCard').hidden)})", hp['id'])
    heard = await until(P3, A, "()=>!!(S.rsvpIn&&Object.values(S.rsvpIn).some(v=>v===1))", 20)
    det.append(f"B says yes: {yes}; A hears it: {heard}")
    if yes['rsvp'] != 'yes' or yes['card'] or not heard: probs.append('accepting the invitation')
    # the party starts: the clocks move to the party time; B gets the reminder and the way to A's house; A is at home
    for g in P3: await g.ev("(ms)=>__clockMs(ms)", hp['at'] + 1500)
    await A.ev("()=>__goto('home')"); await both(P3, 6, .3)
    nav = await until(P3, B, "()=>!!(NAV&&NAV.id==='party')", 30)
    navd = await B.ev("()=>{const a=[...MP.peers.values()].find(q=>q.nm==='ZZTEST-HOSTA');const j=a&&LANE.slotOf.get(a.peer);const d=j!=null&&LOC.city.lane&&LOC.city.lane[j]?LOC.city.lane[j].door:null;return {nav:NAV?[NAV.id,NAV.n,NAV.goal]:null,door:d,note:$('noteX').textContent,hostOn:!!(a&&a.py&&realMs()>=a.py.at)};}")
    same = bool(navd['nav'] and navd['door'] and abs(navd['nav'][2][0] - navd['door'][0]) < .01 and abs(navd['nav'][2][1] - navd['door'][1]) < .01)
    det.append(f"at party time B gets the way: {nav}, way-finder {navd['nav']} = A's lane door {navd['door']}: {same}; note '{navd['note'][:60]}'")
    if not nav or not same or 'starting' not in navd['note']: probs.append(f'the way to the party: {navd}')
    # B knocks at A's door; the party host's door opens by itself
    ap = await B.ev("()=>{const a=[...MP.peers.values()].find(q=>q.nm==='ZZTEST-HOSTA');return a?a.peer:null;}")
    await B.ev("(p)=>goKnock(p)", ap); await asyncio.sleep(.6); await both(P3, 6, .3); await asyncio.sleep(.5); await both(P3, 6, .3)
    inside = await until(P3, B, "()=>CUR.id==='visit'&&VIS.st==='in'&&!fading", 40)
    host_sees = await until(P3, A, "()=>[...MP.peers.values()].some(a=>a.nm==='ZZTEST-GUESTB'&&a.guest)", 20)
    det.append(f"B knocks, A's door opens by itself: B inside {inside}, A sees the guest {host_sees}")
    if not inside or not host_sees: probs.append('getting into the party')
    # the disco floor and ball: the lights, and Dance! on the floor
    lit = await A.ev("()=>({lit:HPT.lit,tiles:HPT.tiles?HPT.tiles.length:0,ball:!!HPT.ball})")
    det.append(f"A's disco floor lights up: {lit}")
    if not lit['lit'] or lit['tiles'] < 20 or not lit['ball']: probs.append(f'the disco lights: {lit}')
    bfl = await until(P3, B, "()=>!!dnFloor()", 20)
    a_t = await A.ev("()=>{const f=dnFloor();P.x=f.x+.4;P.z=f.z+.4;__run(3);const t=findTarget();return t?[t.icon,typeof t.label==='function'?t.label():t.label,dnHere().length]:null;}")
    det.append(f"B sees the floor and ball in A's house: {bfl}; A on the floor: the button {a_t}")
    if not bfl or not a_t or a_t[1] != 'Dance!': probs.append(f'the Dance! button: {a_t}')
    await A.ev("()=>{TARGET=findTarget();useTarget();}"); await both(P3, 4, .3)
    card = await until(P3, B, "()=>(!!$('dnCard')&&!$('dnCard').hidden)", 30)
    cardx = await B.ev("()=>({txt:$('dnCard')?.textContent||'',btns:[...document.querySelectorAll('#dnCard .btn')].map(b=>[b.textContent.trim(),b.offsetWidth,b.offsetHeight])})")
    det.append(f"B gets the dance card: {card} '{cardx['txt'][:70]}' {cardx['btns']}")
    if not card or 'ZZTEST-HOSTA' not in cardx['txt'] or len(cardx['btns']) != 2: probs.append('the dance card')
    await B.tap('#dnYes'); await both(P3, 4, .3)
    on = await until(P3, A, "()=>DANCE.on&&MP.peers.size>=2", 30) and await until(P3, B, "()=>DANCE.on", 20)
    st = await A.ev("()=>!DANCE.on?{t:0,ride:P.ride&&P.ride.kind,left:0,n:0,faces:0,names:[],bar:0,btns:[],me:false,hud:false,mine:DANCE.mine,ask:!!DANCE.ask}:({t:+DANCE.t.toFixed(2),ride:P.ride&&P.ride.kind,left:DANCE.left,n:DANCE.pat.length,faces:document.querySelectorAll('#dnTop .dnFace').length,names:[$('dnMeN').textContent,$('dnYouN').textContent],bar:+DANCE.bar.toFixed(3),btns:[...document.querySelectorAll('#dnBtns .btn')].map(b=>{const r=b.getBoundingClientRect();return [Math.round(r.width),Math.round(r.height)];}),me:!!DANCE.me,hud:!$('dnHud').hidden})")
    det.append(f"the dance-off starts for both: {on}; A: countdown {st['t']} s, view {st['ride']}, on the left {st['left']}, {st['n']} arrows, {st['faces']} faces {st['names']}, bar {st['bar']} (even = middle), buttons {st['btns']}")
    if not on or st['ride'] != 'dance' or st['faces'] != 2 or abs(st['bar'] - .5) > .001 or st['n'] != 20 or len(st['btns']) != 4 or any(w < 44 or h < 44 for w, h in st['btns']) or not st['me'] or not st['hud']: probs.append(f'the start of the dance-off: {st}')
    # the round: A hits with the big buttons (real taps for the first ones), B with the arrow keys; both step in time; the bar is watched every frame
    await A.ev("()=>{window.__bars=[];const f0=dnHudTick;window.dnHudTick=function(){f0();window.__bars.push(DANCE.bar);};}")   # the bar's value after every frame of the round
    NEXT = """(k)=>{const q=DANCE.pat.filter(a=>!a.j);if(!q.length)return null;const a=q[0];const seeB=()=>{const b=[...MP.peers.values()].find(x=>x.nm==='ZZTEST-GUESTB');return !!(b&&b.dnT>0&&b.av&&(Math.abs(b.av.arms[0].rotation.z)>.4||Math.abs(b.av.arms[1].rotation.z)>.4||Math.abs(b.av.b.position.y)>.05));};
      while(DANCE.t<a.t-.03){__run(1);if(k&&seeB())window.__sawB=true;}return {i:DANCE.pat.indexOf(a),d:a.d,t:+DANCE.t.toFixed(2),sawB:!!window.__sawB};}"""
    keys = ['ArrowLeft', 'ArrowDown', 'ArrowUp', 'ArrowRight']
    hits_a = hits_b = 0; real_a = real_b = 0; moved_a = False; moved_b_seen = False; shot_done = False
    for i in range(20):
        na = await A.ev(NEXT, 1); nb = await B.ev(NEXT, 0)
        if not na or not nb: break
        if i < 3: await A.tap(f'#dnBtns [data-a="dnp:{na["d"]}"]'); real_a += 1
        else: await A.ev("(d)=>dnPress(d)", na['d'])
        if i < 3: await B.key(keys[nb['d']]); real_b += 1
        else: await B.ev("(d)=>dnPress(d)", nb['d'])
        ka = await A.ev("()=>({k:DANCE.mine.k,mv:DANCE.mvT>0,arm:Math.abs(DANCE.me.arms[0].rotation.z)+Math.abs(DANCE.me.arms[1].rotation.z)+Math.abs(DANCE.me.b.rotation.z)+Math.abs(DANCE.me.b.position.y)})")
        kb = await B.ev("()=>({k:DANCE.mine.k})")
        hits_a, hits_b = ka['k'], kb['k']
        if ka['mv']: moved_a = True
        if i == 2 and not shot_done: await A.ev("()=>__run(4)"); await A.shot('dance-off', both=False); shot_done = True
        await both(P3, 3, .12)
        if na.get('sawB'): moved_b_seen = True
    bars = await A.ev("()=>{const b=window.__bars||[];let mx=0;for(let i=1;i<b.length;i++)mx=Math.max(mx,Math.abs(b[i]-b[i-1]));return {n:b.length,maxStep:+mx.toFixed(4),first:+(b[0]||0).toFixed(3),last:+(b[b.length-1]||0).toFixed(3),min:+Math.min(...b).toFixed(3),max:+Math.max(...b).toFixed(3)};}")
    det.append(f"the round: A hit {hits_a} ({real_a} with the big buttons), B hit {hits_b} ({real_b} with the arrow keys); A's dancer moved on hits {moved_a}; A saw B's dancer move {moved_b_seen}; the score bar on A over {bars['n']} frames: biggest step {bars['maxStep']} (smooth), from {bars['first']} to {bars['last']} (range {bars['min']}..{bars['max']})")
    if hits_a < 15 or hits_b < 15 or not moved_a or not moved_b_seen: probs.append('hits or dance moves')
    if bars['maxStep'] > .03 or abs(bars['first'] - .5) > .01: probs.append(f'the score bar jumps: {bars}')
    # the end: a result card for both, coins, the old version still fine
    ended = await until(P3, A, "()=>!DANCE.on&&!!document.querySelector('#card [data-a=dnbye]')", 60, 8, .3)
    res = await A.ev("()=>({txt:document.querySelector('#card .line')?.textContent,earn:document.querySelector('#card .earn')?.textContent,ride:P.ride,coins:S.coins,onDancers:!!(P.ride&&P.ride.kind==='dance'&&DANCE.res&&DANCE.me)})")
    resb = await until(P3, B, "()=>!DANCE.on&&!!document.querySelector('#card [data-a=dnbye]')", 30, 8, .3)
    await A.shot('dance-result', both=False)
    # stage 3: the view stays on the two dancers while the result card shows; Done brings the normal view back for both
    await A.ev("()=>{const b=document.querySelector('#card [data-a=dnbye]');if(b)b.click();}"); await B.ev("()=>{const b=document.querySelector('#card [data-a=dnbye]');if(b)b.click();}"); await both(P3, 4, .1)
    back = await A.ev("()=>({ride:P.ride,res:!!DANCE.res,me:!!DANCE.me,card:$('panel').hidden||!document.querySelector('#card [data-a=dnbye]')})"); backb = await B.ev("()=>({ride:P.ride,res:!!DANCE.res,me:!!DANCE.me})")
    det.append(f"the end: A's card {ended} '{res['txt']}' / '{(res['earn'] or '')[:40]}', B's card {resb}; the view stays on the dancers while the card shows {res['onDancers']}; after Done the view is back {back['ride'] is None and not back['res'] and not back['me'] and back['card']} (B: {backb['ride'] is None and not backb['res']})")
    if not ended or not resb or not res['onDancers'] or back['ride'] is not None or back['res'] or back['me'] or not back['card'] or backb['ride'] is not None: probs.append('the end of the round')
    c2 = await C.ev("()=>({peers:MP.peers.size,seesA:[...MP.peers.values()].some(a=>a.nm==='ZZTEST-HOSTA'),cur:CUR.id,playing:PLAYING})")
    det.append(f"the old version C all along: before {c_ok}, after {c2}, page errors {C.errors[:2]}")
    if C.errors or not c2['seesA'] or not c2['playing']: probs.append(f'the old version: {C.errors[:2]} {c2}')
    errs = A.errors[:2] + B.errors[:2]
    for g in P3: await run.close(g)
    if errs: probs.append(f'browser errors: {errs}')
    return not probs, '; '.join(det) + (f' | PROBLEMS: {probs}' if probs else '')
