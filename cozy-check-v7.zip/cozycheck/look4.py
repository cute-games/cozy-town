"""Run 4, job 6 lines: N30 (sky: soft clouds, leaves from the crowns), N31 (trees by buildings, the wall streaks), N32 (the food truck's surfaces and sign)."""
import json, os
from night3 import fx, begin, fake_date_build

def _lum(h):
    r, g, b = int(h[1:3], 16), int(h[3:5], 16), int(h[5:7], 16); return .299 * r + .587 * g + .114 * b

def _patch_metrics(png, box):
    """Streakiness of a wall patch in a picture: the share of neighbouring-pixel steps brighter than 6, and the mean step (a clean toon wall: 0.7% / 0.2; the streaked wall: 4.5% / 0.9)."""
    from PIL import Image
    import numpy as np
    im = np.asarray(Image.open(png).convert('RGB')).astype(float); x1, y1, x2, y2 = box
    p = im[y1:y2, x1:x2]; lum = p @ [.299, .587, .114]; dx = np.abs(np.diff(lum, axis=1))
    return {'edge': round(float((dx > 6).mean() * 100), 2), 'step': round(float(dx.mean()), 3), 'mean': round(float(lum.mean())), 'std': round(float(lum.std()), 1), 'bluish': bool(p[..., 2].mean() > p[..., 0].mean() + 10)}

def _dark_share(png, box):
    """Share of dark pixels (luminance under 120) in a box of the picture: the sky band between the top buttons and the horizon, clear of the notepad and the right-hand buttons on an iPad."""
    from PIL import Image
    import numpy as np
    im = np.asarray(Image.open(png).convert('RGB')).astype(float); x1, y1, x2, y2 = box
    lum = im[y1:y2, x1:x2] @ [.299, .587, .114]; return round(float((lum < 120).mean() * 100), 3)

CLOUD_JS = """()=>{const bad=[],mat=m=>m.material;let n=0,outl=0,other=0;const look=c=>{c.traverse(m=>{if(!m.isMesh)return;n++;if(m.material!==CLOUD){other++;if(m.material.side===THREE.BackSide)outl++;}});};
  for(const c of clouds)look(c);for(const c of (BEACH.clouds||[]))look(c);
  const U=CLOUD.uniforms,hex=v=>'#'+v.getHexString();return {meshes:n,notCloudMat:other,outlines:outl,sky:clouds.length,beach:(BEACH.clouds||[]).length,top:hex(U.top.value),bot:hex(U.bot.value),lit:!!CLOUD.lights,toon:CLOUD.isMeshToonMaterial===true,old:!!(window.OLC&&clouds.some(c=>{let f=false;c.traverse(m=>{if(m.isMesh&&m.material===OLC)f=true;});return f;}))};}"""
LEAF_JS = """()=>{if(!window.LEAFM)return{missing:true};const a=LEAFM.geometry.attributes.org,T=leafTrees(),cam=camera.position;let maxY=0,far=0,n=0,notTree=0;const set=new Set();
  for(let i=0;i<a.count;i++){if(a.getW(i)<=0)continue;n++;const x=a.getX(i),z=a.getZ(i);maxY=Math.max(maxY,a.getY(i));far=Math.max(far,Math.hypot(x-cam.x,z-cam.z));set.add(x+','+z);
    if(!T.some(t=>Math.abs(t[0]-x)<.01&&Math.abs(t[1]-z)<.01))notTree++;}
  return {visible:LEAFM.visible,op:+LEAFM.material.uniforms.op.value.toFixed(2),near:LEAF.near,dealt:n,trees:set.size,maxY:+maxY.toFixed(2),far:+far.toFixed(1),notTree,townTrees:T.length,season:SEASON,
    leafShape:LEAFM.material.fragmentShader.includes('abs(c.x)>w')&&LEAFM.material.fragmentShader.includes('c.y*c.y'),count:a.count};}"""

async def n30(run, new_wb, FIX):
    probs = []; det = []
    if b'function leafCloud' not in new_wb or b'CLOUD=new THREE.ShaderMaterial' not in new_wb: return False, 'the soft clouds and the crown leaves are not built yet (job 6)'
    save = fx(FIX, 'save-prenight3-pets.json')
    fb = fake_date_build(new_wb, '2026-10-20T12:00:00') or new_wb   # autumn: the leaves fall
    g = await begin(run, fb, 'ipad-landscape', 'n30-sky', save)
    await g.ev("()=>{__goto('city');__setClock(null,12);wxForce('sun');P.x=41.5;P.z=-29.6;P.yaw=-1.57;P.pitch=.9;}"); await g.step(10)
    c = await g.ev(CLOUD_JS)
    det.append(f"clouds: {c['sky']} in the sky + {c['beach']} at the beach, {c['meshes']} meshes, {c['notCloudMat']} not the cloud material, {c['outlines']} outline hulls; by day top {c['top']} bottom {c['bot']}")
    if c['notCloudMat'] or c['outlines'] or c['toon'] or c['old']: probs.append(f"clouds still have outlines or a lit/toon material: {c}")
    if _lum(c['top']) < 240 or _lum(c['bot']) < 200: probs.append(f"day clouds not bright and soft: top {c['top']} bottom {c['bot']}")
    p = await g.shot('clouds-day', both=False); ds = _dark_share(p, (260, 70, 900, 370)); det.append(f"day sky picture: {ds}% dark pixels in the sky band clear of the buttons (limit 0.3%)")
    if ds > .3: probs.append(f'dark marks in the day sky (outlines or hard faces): {ds}%')
    await g.ev("()=>{wxForce('cloudy');}"); await g.step(12); c2 = await g.ev(CLOUD_JS); det.append(f"grey weather: top {c2['top']} bottom {c2['bot']}")
    if not (120 <= _lum(c2['top']) <= 238 and 100 <= _lum(c2['bot']) <= 220): probs.append(f"grey-weather clouds not grey: {c2['top']} {c2['bot']}")
    await g.shot('clouds-grey', both=False)
    await g.ev("()=>{wxForce('sun');__setClock(null,23);}"); await g.step(12); c3 = await g.ev(CLOUD_JS); det.append(f"night: top {c3['top']} bottom {c3['bot']}")
    if not (70 <= _lum(c3['top']) <= 200 and 40 <= _lum(c3['bot']) <= 160): probs.append(f"night clouds not gently lit (should be a soft blue-grey, neither black nor white): {c3['top']} {c3['bot']}")
    p = await g.shot('clouds-night', both=False)
    # leaves: from the crowns around you, never above them, leaf-shaped, none far from a tree, none without trees nearby, none outside autumn
    await g.ev("()=>{__setClock(null,12);P.x=-20;P.z=20;P.yaw=2.2;P.pitch=.35;}"); await g.step(30)
    lf = await g.ev(LEAF_JS)
    if lf.get('missing'): probs.append('no leaf cloud'); lf = {}
    else:
        det.append(f"leaves in the park: visible {lf['visible']}, {lf['dealt']} of {lf['count']} dealt to {lf['trees']} trees ({lf['townTrees']} round trees in town), highest start {lf['maxY']} m, farthest tree {lf['far']} m, not a tree: {lf['notTree']}, leaf shape {lf['leafShape']}, season {lf['season']}")
        if not lf['visible'] or lf['dealt'] < lf['count'] or lf['maxY'] > 4.2 or lf['far'] > 32 or lf['notTree'] or not lf['leafShape'] or lf['trees'] < 3: probs.append(f'leaves wrong: {lf}')
    await g.shot('leaves-park', both=False)
    old = await g.ev("()=>({diamond:!!(window.LEAFM&&LEAFM.material.fragmentShader.includes('abs(c.y)*1.6')),boxH:!!(window.LEAFM&&LEAFM.material.vertexShader.includes('mod(p.y-t*spd,H)'))})")
    if old['diamond'] or old['boxH']: probs.append('the old diamond leaf cloud around the camera is still there')
    # at the beach (no round trees near the camera) and outside autumn: no leaves
    await g.ev("()=>{__goto('beach');}"); await g.step(40); b = await g.ev(LEAF_JS); det.append(f"beach: leaves visible {b.get('visible')} (trees near: {b.get('near')})")
    if b.get('visible'): probs.append(f'leaves at the beach without round trees: {b}')
    await g.ev("()=>{__goto('city');P.x=-20;P.z=20;SEASON='winter';}"); await g.step(40); w = await g.ev(LEAF_JS); det.append(f"winter: leaves visible {w.get('visible')}")
    if w.get('visible'): probs.append('leaves fall outside autumn')
    await g.ev("()=>{SEASON='autumn';}")
    errs = g.errors[:]; await run.close(g)
    if errs: probs.append(f'browser errors: {errs[:2]}')
    return not probs, '; '.join(det) + (f' | PROBLEMS: {probs}' if probs else '')

CROWN_JS = """()=>{__goto('city');const T=leafTrees().map(t=>[t[0],t[1],t[2],'tree']),P=(window.PINES||[]).map(p=>[p[0],p[1],p[2],'pine']),all=T.concat(P),out=[];
  const crowns=(x,z,s,k)=>k==='pine'?[[x,z,1.2*s,.7*s,2.3*s],[x,z,.92*s,1.55*s,2.95*s],[x,z,.62*s,2.35*s,3.55*s]]
    :[[x,z,1.15*s,1.9*s,4.2*s],[x+.7*s,z+.15*s,.75*s,2.0*s,3.5*s],[x-.62*s,z-.3*s,.72*s,2.08*s,3.52*s],[x+.1*s,z+.4*s,.62*s,2.98*s,4.22*s]];
  let closest=null;for(const [x,z,s,k] of all){for(const [bx,bz,w,d,h,sign] of (window.BLDG||[])){const r=[bx-w/2,bz-d/2,bx+w/2,bz+d/2];
      for(const [cx,cz,cr,y0,y1] of crowns(x,z,s,k)){if(y0>h+.6)continue;const dx=Math.max(r[0]-cx,0,cx-r[2]),dz=Math.max(r[1]-cz,0,cz-r[3]),gap=Math.hypot(dx,dz)-cr-.03;   /* .03: the crown's outline hull */
        if(closest===null||gap<closest.gap)closest={gap:+gap.toFixed(2),tree:[+x.toFixed(1),+z.toFixed(1),k],building:sign||(bx+','+bz)};if(gap<0)out.push({gap:+gap.toFixed(2),tree:[+x.toFixed(1),+z.toFixed(1),k],building:sign||(bx+','+bz)});}}}
  return {trees:T.length,pines:P.length,buildings:(window.BLDG||[]).length,inside:out.sort((a,b)=>a.gap-b.gap).slice(0,8),closest};}"""

async def n31(run, new_wb, FIX):
    probs = []; det = []
    if b'const TREES=[]' not in new_wb or b'sun.shadow.normalBias=.09+' not in new_wb: return False, 'the tree list and the wall-streak fix are not built yet (job 6)'
    save = fx(FIX, 'save-prenight3-pets.json')
    s = new_wb.decode()
    if s.count('function buildingIn(g,o){') != 1 or s.count("function pine(g,x,z,s=1){") != 1: return False, 'the test cannot find buildingIn/pine to record the walls and pines'
    s = s.replace('function buildingIn(g,o){', "window.BLDG=window.BLDG||[];function buildingIn(g,o){BLDG.push([o.x,o.z,o.w,o.d,o.h||4,o.sign||'']);", 1)
    s = s.replace("function pine(g,x,z,s=1){", "window.PINES=window.PINES||[];function pine(g,x,z,s=1){PINES.push([x,z,s]);", 1)
    g = await begin(run, s.encode(), 'ipad-landscape', 'n31-trees', save)
    r = await g.ev(CROWN_JS)
    det.append(f"{r['trees']} round trees and {r['pines']} pines against {r['buildings']} buildings' walls: {len(r['inside'])} crowns inside a wall; the closest crown {r['closest']}")
    if r['inside']: probs.append(f"crowns inside walls: {r['inside'][:4]}")
    if r['buildings'] < 20 or r['trees'] < 50: probs.append(f"too few buildings or trees found to mean anything: {r['buildings']} buildings, {r['trees']} trees")
    # the wall by the corner tree at the apartments (the owner's spot): no streaks at any of these hours
    BOX = (575, 95, 690, 215)
    for hr in (12, 11.5, 12.5, 9, 15, 17.5):
        await g.ev("(h)=>{__goto('city');__setClock(null,h);wxForce('sun');P.x=41.5;P.z=-29.6;P.yaw=Math.atan2(-(34.9-P.x),-(-30.2-P.z));P.pitch=.25;}", hr); await g.step(8)
        p = await g.shot('wall-%s' % str(hr).replace('.', '-'), both=False); m = _patch_metrics(p, BOX)
        det.append(f"wall at {hr}: steps>6 {m['edge']}% (limit 1.5), mean step {m['step']} (limit .45; the streaked wall had 4.5% and .92), lum {m['mean']}")
        if not m['bluish'] or not (80 <= m['mean'] <= 245): probs.append(f'the wall patch is not the wall (framing changed?): {m}'); continue
        if m['edge'] > 1.5 or m['step'] > .45: probs.append(f'streaks on the wall at {hr}: {m}')
    nb = await g.ev("()=>{__setClock(null,12);return [sun.shadow.normalBias];}")
    errs = g.errors[:]; await run.close(g)
    if errs: probs.append(f'browser errors: {errs[:2]}')
    return not probs, '; '.join(det) + (f' | PROBLEMS: {probs}' if probs else '')

TRUCK_JS = r"""([x0,z0])=>{setLoc('city');const L=LOC.city,bb={x1:x0-1.5,x2:x0+2.4,z1:z0-2.5,z2:z0+3.1},tris=[];L.g.updateMatrixWorld(true);
  const V=[new THREE.Vector3(),new THREE.Vector3(),new THREE.Vector3()];
  L.g.traverse(m=>{if(!m.isMesh||!m.geometry||!m.geometry.attributes.position||m.userData.sign)return;const mt=m.material;if(!mt||mt.side===THREE.BackSide||mt.transparent)return;
    const pa=m.geometry.attributes.position,idx=m.geometry.index,n=idx?idx.count:pa.count,W=m.matrixWorld;
    for(let i=0;i<n;i+=3){let out=false;for(let k=0;k<3;k++){const j=idx?idx.getX(i+k):i+k;V[k].fromBufferAttribute(pa,j).applyMatrix4(W);const p=V[k];if(p.x<bb.x1||p.x>bb.x2||p.z<bb.z1||p.z>bb.z2||p.y>4.2){out=true;break;}}
      if(out)continue;const a=V[0].clone(),b=V[1].clone(),c=V[2].clone(),nrm=new THREE.Vector3().subVectors(b,a).cross(new THREE.Vector3().subVectors(c,a));if(nrm.length()<2e-6)continue;nrm.normalize();
      tris.push({a,b,c,n:nrm,o:nrm.dot(a),col:mt.color?'#'+mt.color.getHexString():'?',id:m.id});}});
  const groups=new Map();for(const t of tris){const k=[t.n.x,t.n.y,t.n.z].map(v=>Math.round(v*40)/40).join(',');if(!groups.has(k))groups.set(k,[]);groups.get(k).push(t);}
  const basis=n=>{const u=Math.abs(n.y)<.9?new THREE.Vector3(0,1,0):new THREE.Vector3(1,0,0);const e1=new THREE.Vector3().crossVectors(n,u).normalize(),e2=new THREE.Vector3().crossVectors(n,e1).normalize();return [e1,e2];};
  const proj=(t,e1,e2)=>[t.a,t.b,t.c].map(p=>[p.dot(e1),p.dot(e2)]);
  const area2=poly=>{let s=0;for(let i=0;i<poly.length;i++){const p=poly[i],q=poly[(i+1)%poly.length];s+=p[0]*q[1]-q[0]*p[1];}return s/2;};
  const ccw=poly=>area2(poly)>0?poly:poly.slice().reverse();
  const inter=(P,Q,A,B)=>{const d1=[Q[0]-P[0],Q[1]-P[1]],d2=[B[0]-A[0],B[1]-A[1]],den=d1[0]*d2[1]-d1[1]*d2[0];if(Math.abs(den)<1e-12)return P;const t=((A[0]-P[0])*d2[1]-(A[1]-P[1])*d2[0])/den;return [P[0]+d1[0]*t,P[1]+d1[1]*t];};
  const clip=(sub,cp)=>{let out=sub;for(let i=0;i<cp.length&&out.length;i++){const inp=out;out=[];const A=cp[i],B=cp[(i+1)%cp.length],side=p=>(B[0]-A[0])*(p[1]-A[1])-(B[1]-A[1])*(p[0]-A[0]);
      for(let j=0;j<inp.length;j++){const P=inp[j],Q=inp[(j+inp.length-1)%inp.length],sp=side(P),sq=side(Q);if(sp>=0){if(sq<0)out.push(inter(Q,P,A,B));out.push(P);}else if(sq>=0)out.push(inter(Q,P,A,B));}}return out;};
  const bad=[];let pairs=0;
  for(const [k,ts] of groups){if(ts.length<2)continue;const [e1,e2]=basis(ts[0].n);ts.sort((p,q)=>p.o-q.o);
    for(let i=0;i<ts.length;i++)for(let j=i+1;j<ts.length&&ts[j].o-ts[i].o<.01;j++){const A=ts[i],B=ts[j];
      const pa=ccw(proj(A,e1,e2)),pb=ccw(proj(B,e1,e2));const ax=pa.map(p=>p[0]),bx=pb.map(p=>p[0]),ay=pa.map(p=>p[1]),by=pb.map(p=>p[1]);
      if(Math.min(Math.max(...ax),Math.max(...bx))-Math.max(Math.min(...ax),Math.min(...bx))<.005||Math.min(Math.max(...ay),Math.max(...by))-Math.max(Math.min(...ay),Math.min(...by))<.005)continue;
      pairs++;const ov=Math.abs(area2(clip(pa,pb)));if(ov>1e-4)bad.push({gap:+(B.o-A.o).toFixed(4),overlap:+ov.toFixed(4),at:[+A.a.x.toFixed(2),+A.a.y.toFixed(2),+A.a.z.toFixed(2)],n:k,cols:[A.col,B.col]});}}
  return {tris:tris.length,groups:groups.size,pairs,bad:bad.sort((p,q)=>q.overlap-p.overlap).slice(0,10),badCount:bad.length};}"""

async def n32(run, live_w, new_wb, FIX, SIGNS_JS):
    probs = []; det = []
    if b'one outline around the whole' not in new_wb: return False, 'the food truck fixes are not built yet (job 6)'
    save = fx(FIX, 'save-prenight3-pets.json')
    g = await begin(run, new_wb, 'ipad-landscape', 'n32-truck', save)
    tx = await g.ev("()=>[TRUCK.x,TRUCK.z,(index=>index)(0)]"); x0, z0 = tx[0], tx[1]
    r = await g.ev(TRUCK_JS, [x0, z0])
    det.append(f"the truck at ({x0}, {z0}): {r['tris']} triangles in {r['groups']} facing directions, {r['pairs']} close same-facing pairs looked at, {r['badCount']} overlapping within 1 cm")
    if r['badCount']: probs.append(f"same-facing surfaces within 1 cm: {r['bad'][:5]}")
    trucks = await g.ev("()=>{let n=0;for(const id in LOC){const L=LOC[id];if(!L.g)continue;L.g.traverse(m=>{if(m.isMesh&&m.userData.sign&&m.userData.sign.text==='🍔 Food truck')n++;});}return n;}")
    det.append(f"food trucks in the game (by their sign): {trucks}")
    signs = await g.ev(SIGNS_JS); s = next((q for q in signs if q['text'] == '🍔 Food truck'), None)
    if not s: probs.append('the truck sign was not found')
    else:
        W, H = s['W'], s['H']; off = max(abs(s['cx'] - W / 2) / W, abs(s['cy'] - H / 2) / H)
        det.append(f"the sign: off centre {off * 100:.1f}%, crossed {sorted(set(s['crossed']))[:2]}, coplanar {s['coplanar']}")
        if off > .03 or s['crossed'] or s['coplanar']: probs.append(f'the truck sign is not clean: {s}')
    burger = await g.ev("""()=>{let m=null;LOC.city.g.traverse(o=>{if(o.isMesh&&o.userData.sign&&o.userData.sign.text==='🍔 Food truck')m=o;});if(!m)return null;const c=m.userData.sign.c,W=c.width,H=c.height,d=c.getContext('2d').getImageData(0,0,W,H).data;
      let colourful=0,white=0;for(let j=0;j<H;j++)for(let i=0;i<W*.35;i++){const k=(j*W+i)*4,r=d[k],g=d[k+1],b=d[k+2];if(Math.max(r,g,b)-Math.min(r,g,b)>60&&!(r>230&&g<140&&b<140))colourful++;if(r>235&&g>235&&b>235)white++;}return {colourful,white,W,H};}""")
    det.append(f"the burger picture on the sign (left 35%): {burger and burger['colourful']} coloured pixels besides the red board, {burger and burger['white']} white")
    if not burger or burger['colourful'] < 300: probs.append(f'the burger picture does not show on the sign: {burger}')
    for nm, px, pz, yaw, pitch, hr in (('truck-front-left', -27.3, 11.45, 1.57, .35, 10), ('truck-cab', x0, z0 + 7.5, 0, .12, 10), ('truck-evening', -27.3, 11.45, 1.57, .35, 19.5)):
        await g.ev("([x,z,yaw,pitch,h])=>{__goto('city');__setClock(null,h);wxForce('sun');P.x=x;P.z=z;P.yaw=yaw;P.pitch=pitch;}", [px, pz, yaw, pitch, hr]); await g.step(8); await g.shot(nm, both=False)
    errs = g.errors[:]; await run.close(g)
    # the live truck, for the record
    try:
        g2 = await begin(run, live_w, 'ipad-landscape', 'n32-truck-live', save); r2 = await g2.ev(TRUCK_JS, [x0, z0]); det.append(f"(the live truck had {r2['badCount']} such pairs)"); await run.close(g2)
    except Exception as e: det.append(f'(the live truck could not be measured: {str(e)[:80]})')
    if errs: probs.append(f'browser errors: {errs[:2]}')
    return not probs, '; '.join(det) + (f' | PROBLEMS: {probs}' if probs else '')
