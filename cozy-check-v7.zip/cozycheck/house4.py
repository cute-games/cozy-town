"""Run 4, job 10: N33 (every skill to 50 and stops there; +6 seed spots at gardening 10/20/30/40/50; another player sees your plants) and
N34 (2 floors at decorating 10 up to 6 at 50; the stairs work up and down on every floor; the outside shows the floors and the chosen colour, also for
others; old saves keep every piece)."""
import json
from night3 import fx, begin

async def climb(g, d):
    """hclimb(d) and wait for the climb (it has a real-time fade in the middle, so the frames are stepped with waits between them; a climb is refused while the last fade still runs, so wait for that first)."""
    for _ in range(30):
        if not await g.ev("()=>!!CLIMB||!!fading"): break
        await g.step(4); await g.wait(100)
    await g.ev("(d)=>hclimb(d)", d)
    for _ in range(60):
        await g.step(8); await g.wait(100)
        if not await g.ev("()=>!!CLIMB&&true"): break
    for _ in range(20):
        if not await g.ev("()=>!!fading"): break
        await g.step(4); await g.wait(100)
    await g.step(3)
    return await g.ev("()=>({fl:flOf(CUR,P.z),dz:+(P.z-CUR.oz).toFixed(1),att:CUR.fls.map(F=>!!F.g.parent),climb:!!CLIMB})")

async def n33(run, new_wb, FIX):
    probs = []; det = []
    if b'const YARD_POTS=' not in new_wb or b'const MAXLV=50' not in new_wb: return False, 'levels to 50 and the garden pots are not built yet (job 10)'
    lv10 = fx(FIX, 'save-prerun4-lv10.json') or fx(FIX, 'save-prenight3-pets.json')
    A = await begin(run, new_wb, 'ipad-landscape', 'n33-A', dict(lv10, name='ZZTEST-LV'))
    r = await A.ev("""()=>{const out={maxlv:MAXLV,need:[xpNeed(1),xpNeed(10),xpNeed(49)],skills:{}};for(const k of Object.keys(SKILLS)){const s=sk(k),lv0=s.lv,c0=S.coins;addXP(k,1e7);const a=[s.lv,s.xp];const c1=S.coins;addXP(k,500);out.skills[k]=[lv0,a,[s.lv,s.xp],c1-c0];}return out;}""")
    bad = [k for k, v in r['skills'].items() if v[1] != [50, 0] or v[2] != [50, 0]]
    det.append(f"skills {list(r['skills'])}: every one reaches {set(v[1][0] for v in r['skills'].values())} and stays there after more XP {set(v[2][0] for v in r['skills'].values())}; XP per level {r['need']} (10 per level as before); level-up coins paid {[v[3] for v in r['skills'].values()][:3]}…")
    if r['maxlv'] != 50 or bad: probs.append(f'skills not stopping at 50: {bad}')
    if r['need'] != [10, 100, 490]: probs.append(f'the XP rule changed: {r["need"]}')
    # the garden spots: 6 beds + 30 pots; a pot opens at gardening 10, 20, 30, 40, 50
    gd = await A.ev("""()=>{__goto('city');const L=LOC.city,out={plots:L.plots.length,pots:L.plots.filter(p=>p.pot).length,garden:S.garden.length,gates:[0,5,6,11,12,17,18,23,24,29,30,35].map(i=>plotGate(i)),open:{}};
      for(const lv of [1,9,10,19,20,49,50]){sk('garden').lv=lv;out.open[lv]=[0,5,6,11,12,17,18,23,24,29,30,35].filter(i=>plotOpen(i)).length;}
      sk('garden').lv=10;S.bag.seed_carrot=(S.bag.seed_carrot|0)+2;const rec=PLOTS.find(p=>p.pl.i===6);out.hasRec=!!rec;if(rec){usePlot(rec);const b=document.querySelector('#card [data-a="plant:carrot"]');out.panel=!!b;if(b)b.click();}
      const st=S.garden[6]||{};out.planted=st.seed||null;out.snap=gardenSnap();const s2={};laneStamp(s2);out.stampGd=s2.gd;
      const locked=PLOTS.find(p=>p.pl.i===30);out.lockedLabel=locked?plotLabel(locked):null;return out;}""")
    det.append(f"yard spots {gd['plots']} ({gd['pots']} pots), garden save slots {gd['garden']}; a spot's gardening level [beds, pots…] {gd['gates']}; spots open at level 1/9/10/19/20/49/50: {[gd['open'][str(l)] if str(l) in gd['open'] else gd['open'][l] for l in (1,9,10,19,20,49,50)]} of 12 sampled; planting in pot 7 at level 10: {gd['planted']} (panel {gd['panel']}); a level-50 pot says '{gd['lockedLabel']}'; presence gd '{(gd['stampGd'] or '')[:60]}'")
    if gd['plots'] != 42 or gd['pots'] != 30 or gd['garden'] < 6: probs.append(f"not 6 beds + 30 pots + 6 back beds (garden levels 2 and 3): {gd['plots']} spots, {gd['pots']} pots, {gd['garden']} slots")   # the save list grows only as pots are used (stage 2 end: an old save re-saves unchanged)
    if gd['gates'] != [1, 1, 10, 10, 20, 20, 30, 30, 40, 40, 50, 50]: probs.append(f'the pots open at the wrong levels: {gd["gates"]}')
    exp = {1: 2, 9: 2, 10: 4, 19: 4, 20: 6, 49: 10, 50: 12}
    got = {int(k): v for k, v in gd['open'].items()}
    if got != exp: probs.append(f'spots open per level {got}, expected {exp}')
    if gd['planted'] != 'carrot' or not gd['snap'] or '6,carrot' not in gd['snap'] or not gd['stampGd'] or '6,carrot' not in gd['stampGd']: probs.append(f"planting in a pot did not work or is not sent to friends: planted {gd['planted']}, snap {gd['snap']}, stamp {gd['stampGd']}")
    if not gd['lockedLabel'] or '50' not in gd['lockedLabel']: probs.append(f"a locked pot does not say its level: {gd['lockedLabel']}")
    # another player sees the plants: a PC-size player builds the friend's lot from that gd
    Bp = await begin(run, new_wb, 'pc-1366', 'n33-B', dict(fx(FIX, 'save-prenight3-pets.json'), name='ZZTEST-LVB'))
    vb = await Bp.ev("""(gd)=>{__goto('city');const lp=LOC.city.lane[4],cnt=()=>{let v=0,n=0;lp.g.traverse(o=>{if(o.isMesh&&o.geometry&&o.geometry.attributes.position){v+=o.geometry.attributes.position.count;n++;}});return [n,v];};
      laneHouse(lp,{k:'zz',nm:'Zed',big:1,fl:2,col:'',gd:''});const a=cnt();laneHouse(lp,{k:'zz',nm:'Zed',big:1,fl:2,col:'',gd});const b=cnt();
      const o={peer:'zz',nm:'Zed',jt:1,bh:1,gd,hc:'',hf:2};MP.peers.set('zz',o);const as=laneAssign();const mine=[...as.slot.entries()].find(e=>e[0]==='zz');MP.peers.delete('zz');return {without:a,with:b,slotGd:mine&&as.own[mine[1]].gd===gd};}""", gd['snap'])
    det.append(f"a PC-size friend builds that lot: {vb['without'][1]} vertices without the garden, {vb['with'][1]} with it (the pot's carrot shows); the lane list carries the garden {vb['slotGd']}")
    if not (vb['with'][1] > vb['without'][1] and vb['slotGd']): probs.append('a friend does not see the pot plants')
    errs = A.errors[:2] + Bp.errors[:2]; await run.close(A); await run.close(Bp)
    if errs: probs.append(f'browser errors: {errs}')
    return not probs, '; '.join(det) + (f' | PROBLEMS: {probs}' if probs else '')

async def n34(run, new_wb, FIX):
    probs = []; det = []
    if b'function houseFloors' not in new_wb or b'const HOUSE_COLS=' not in new_wb: return False, 'the house floors and colour are not built yet (job 10)'
    big = fx(FIX, 'save-prenight3-bighouse.json')
    A = await begin(run, new_wb, 'ipad-landscape', 'n34-A', dict(big, name='ZZTEST-HOUSE'))
    s0 = await A.ev("()=>({floors:homeFloors(),fls:LOC.home.fls.length,items:S.home.items.length,up:S.home.items.filter(i=>i.f).length,placed:HOME_ITEMS.size,upZ:[...HOME_ITEMS.values()].filter(r=>r.it&&r.it.f).map(r=>+(r.g.position.z-LOC.home.oz-r.it.z).toFixed(1)),coins:S.coins,price:BIG_PRICE})")
    det.append(f"an old big-house save: {s0['floors']} floors, {s0['items']} pieces kept ({s0['up']} upstairs, drawn 40 m along: {sorted(set(s0['upZ']))}), {s0['placed']} placed")
    if s0['floors'] != 2 or s0['items'] != 33 or s0['placed'] != 33 or set(s0['upZ']) != {40.0}: probs.append(f'the old save did not keep its pieces or floors: {s0}')
    # buying: floor n+1 needs decorating 10*n (and the price), up to 6
    buy = await A.ev("""()=>{const out=[];for(let n=2;n<=5;n++){sk('decor').lv=10*n-1;S.coins=BIG_PRICE;ACT.bighouse();const a=homeFloors();sk('decor').lv=10*n;ACT.bighouse();out.push([n,a,homeFloors(),S.coins,LOC.home.fls.length]);}
      S.coins=BIG_PRICE;ACT.bighouse();out.push(['at 6',homeFloors(),S.coins]);return {steps:out,items:S.home.items.length,plaque:YARD.plaque?YARD.plaque.visible:null};}""")
    det.append(f"buying floors [had, after a try one level short, after the level, coins left, floors built]: {buy['steps'][:4]}; at 6 floors: {buy['steps'][4]}; pieces still {buy['items']}")
    if any(st[1] != st[0] or st[2] != st[0] + 1 or st[3] != 0 or st[4] != st[0] + 1 for st in buy['steps'][:4]) or buy['steps'][4][1] != 6 or buy['steps'][4][2] != 2500 or buy['items'] != 33: probs.append(f'buying floors went wrong: {buy}')
    # the stairs up and down every floor (the same climb as the flats)
    await A.ev("()=>{__goto('home');}"); await A.step(4)
    ups = []
    for k in range(1, 6): ups.append(await climb(A, 1))
    downs = []
    for k in range(4, -1, -1): downs.append(await climb(A, -1))
    det.append(f"up: floors {[u['fl'] + 1 for u in ups]} at z {[u['dz'] for u in ups]} (one floor drawn at a time {all(sum(u['att']) == 1 for u in ups)}); down: floors {[d['fl'] + 1 for d in downs]}")
    if [u['fl'] for u in ups] != [1, 2, 3, 4, 5] or [d['fl'] for d in downs] != [4, 3, 2, 1, 0] or not all(abs(u['dz'] - 40 * u['fl']) < 6 for u in ups) or not all(sum(u['att']) == 1 for u in ups + downs): probs.append(f'the stairs do not work on every floor: up {ups} down {downs}')
    # decorate on floor 4: the piece lives on that floor and is drawn only there
    await A.ev("()=>{const it={t:'chair',c:'#ff6b6b',x:1.5,z:1.5,r:0,f:3,u:'zz34'};S.home.items.push(it);addHomeItem(it);}"); await A.step(2)   # a frame: the floor's visibility is applied each frame
    dec = await A.ev("()=>{const rec=[...HOME_ITEMS.values()].find(r=>r.it&&r.it.u==='zz34');return {z:+(rec.g.position.z-LOC.home.oz).toFixed(1),visOn0:rec.g.visible};}")
    for k in range(3): await climb(A, 1)
    dec2 = await A.ev("()=>{const rec=[...HOME_ITEMS.values()].find(r=>r.it&&r.it.u==='zz34');return {fl:flOf(CUR,P.z),visOn3:rec.g.visible};}")
    det.append(f"a chair placed on floor 4 stands at z {dec['z']} (hidden from floor 1 {not dec['visOn0']}, shown on floor 4 {dec2['visOn3']})")
    if abs(dec['z'] - 121.5) > .2 or dec['visOn0'] or not dec2['visOn3'] or dec2['fl'] != 3: probs.append(f'decorating on floor 4 went wrong: {dec} {dec2}')
    # the outside: my lot shows 6 floors and the chosen colour; the presence carries both; a friend's lot shows theirs
    out = await A.ev("""()=>{setHouseCol('#bfe6ff');__goto('city');laneRefresh(true);const lp=LOC.city.lane[LANE.mine];let tagY=0;lp.g.traverse(o=>{if(o.position&&o.position.y>tagY&&o.material&&o.material.map)tagY=o.position.y;});
      const st={};laneStamp(st);const hm=homeSnap(100000);return {tagY:+tagY.toFixed(1),hf:st.hf,hc:st.hc,n:hm.n,keys:Object.keys(hm).filter(k=>/^u/.test(k)),u3HasChair:/chair/.test(hm.u3||''),col:houseCol()};}""")
    det.append(f"outside: my name sign hangs at {out['tagY']} m (6 floors: 23.7), presence floors {out['hf']} colour {out['hc']}, home presence n {out['n']} with floors {out['keys']} (the chair rides in u3: {out['u3HasChair']})")
    if abs(out['tagY'] - 23.7) > .3 or out['hf'] != 6 or out['hc'] != '#bfe6ff' or out['n'] != 6 or out['keys'] != ['u', 'u2', 'u3', 'u4', 'u5'] or not out['u3HasChair']: probs.append(f'the outside or the presence is wrong: {out}')
    Bp = await begin(run, new_wb, 'pc-1366', 'n34-B', dict(fx(FIX, 'save-prenight3-pets.json'), name='ZZTEST-HOUSEB'))
    vb = await Bp.ev("""()=>{__goto('city');const o={peer:'zz',nm:'Zed',jt:1,bh:1,gd:'',hc:'#bfe6ff',hf:4};MP.peers.set('zz',o);const as=laneAssign();const j=as.slot.get('zz');const own=as.own[j];MP.peers.delete('zz');
      const lp=LOC.city.lane[5];laneHouse(lp,{k:'zz',nm:'Zed',big:1,fl:4,col:'#bfe6ff',gd:''});let tagY=0;lp.g.traverse(q=>{if(q.position&&q.position.y>tagY&&q.material&&q.material.map)tagY=q.position.y;});
      laneHouse(lp,{k:'zz',nm:'Zed',big:1,fl:1,col:'',gd:''});let tag1=0;lp.g.traverse(q=>{if(q.position&&q.position.y>tag1&&q.material&&q.material.map)tag1=q.position.y;});
      const hm={b:1,n:6,w:'#ffd6e0',f:'wood',W:6,D:5,i:'chair,#ff6b6b,1,1,0,0',u:'chair,#5fd4b0,1,1,0,0',u2:'chair,#7cc8ff,1,1,0,0',u3:'',u4:'',u5:'chair,#ffd45c,1,1,0,0'};visFill(hm);
      return {fl:own&&own.fl,col:own&&own.col,tagY4:+tagY.toFixed(1),tag1:+tag1.toFixed(1),visitFloors:LOC.visit.fls.length,visitItems:LOC.visit.items.children.map(c=>+(c.position.z-LOC.visit.oz).toFixed(0))};}""")
    det.append(f"a PC-size friend: the lane list gives Zed {vb['fl']} floors in {vb['col']}; Zed's sign at {vb['tagY4']} m (4 floors: 17.3) and {vb['tag1']} m with 1 floor (7.9); visiting a 6-floor host: {vb['visitFloors']} floors, pieces at z {vb['visitItems']}")
    if vb['fl'] != 4 or vb['col'] != '#bfe6ff' or abs(vb['tagY4'] - 17.3) > .3 or abs(vb['tag1'] - 7.9) > .3 or vb['visitFloors'] != 6 or vb['visitItems'] != [1, 41, 81, 201]: probs.append(f"a friend's floors or colour are wrong: {vb}")
    # in the visit, the stairs climb the host's floors too
    await Bp.ev("()=>{setLoc('visit');P.x=LOC.visit.ox;P.z=LOC.visit.oz;P.yaw=0;}"); await Bp.step(3)
    v1 = await climb(Bp, 1); v2 = await climb(Bp, 1)
    det.append(f"in the visit: up to floor {v1['fl'] + 1} then {v2['fl'] + 1}")
    if v1['fl'] != 1 or v2['fl'] != 2: probs.append(f'the stairs in a visited house do not work: {v1} {v2}')
    # an old save made upstairs (before run 4) keeps its pieces and starts safely
    U = await begin(run, new_wb, 'ipad-landscape', 'n34-U', dict(fx(FIX, 'save-prenight3-upstairs.json'), name='ZZTEST-UPS'))
    u = await U.ev("()=>({loc:CUR.id,items:S.home.items.length,up:S.home.items.filter(i=>i.f).length,placed:HOME_ITEMS.size,inRoom:Math.abs(P.x-LOC.home.ox)<=HOMEW&&P.z>=LOC.home.oz-HOMED&&P.z<=LOC.home.oz+40+HOMED,floors:homeFloors()})")
    det.append(f"an old upstairs save: {u['items']} pieces kept ({u['up']} upstairs), {u['placed']} placed, you start inside the house {u['inRoom']} with {u['floors']} floors")
    if u['loc'] != 'home' or u['items'] != 7 or u['placed'] != 7 or not u['inRoom']: probs.append(f'the old upstairs save went wrong: {u}')
    errs = A.errors[:2] + Bp.errors[:2] + U.errors[:2]
    for g in (A, Bp, U): await run.close(g)
    if errs: probs.append(f'browser errors: {errs}')
    return not probs, '; '.join(det) + (f' | PROBLEMS: {probs}' if probs else '')
