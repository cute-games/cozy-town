"""Run 4, job 12: N28 (the Pet Shop: two floors; each kind in its own area upstairs, no kind in another's area; clothes and snacks on shelves downstairs; adopting and buying still work)."""
import json
from night3 import fx, begin
from house4 import climb

PENS = """()=>{const L=LOC.pets;const pens=L.pens.map((p,i)=>({i,type:p.type,kinds:p.kinds||[p.type,p.type],x0:+p.x0.toFixed(2),x1:+p.x1.toFixed(2),z0:+(p.z0-UPZ).toFixed(2),z1:+(p.z1-UPZ).toFixed(2),y:p.y||0,up:p.z0>UPZ/2}));
  const animals=PEN.map(a=>({t:a.t,pen:L.pens.indexOf(a.pen),x:+(a.x-L.ox).toFixed(2),z:+(a.z-L.oz).toFixed(2),inPen:a.x>=L.ox+a.pen.x0-.45&&a.x<=L.ox+a.pen.x1+.45&&a.z>=L.oz+a.pen.z0-.45&&a.z<=L.oz+a.pen.z1+.45}));
  return {floors:L.fls?L.fls.length:1,pens,animals,bounds:[L.bounds.z1-L.oz,L.bounds.z2-L.oz]};}"""
FAMILY = {'dog': {'dog', 'pug', 'pomchi', 'sausage'}, 'cat': {'cat'}, 'bunny': {'bunny'}, 'hamster': {'hamster'}, 'capybara': {'capybara'}, 'duck': {'duck'}, 'owl': {'owl'}}

async def n28(run, new_wb, FIX):
    probs = []; det = []
    if b'function petClothesRack' not in new_wb or b"pen('owl'" not in new_wb: return False, 'the Pet Shop upstairs is not built yet (job 12)'
    save = fx(FIX, 'save-prenight3-pets.json'); save = dict(save, name='ZZTEST-PETSHOP', pets=[]); save['coins'] = 900
    g = await begin(run, new_wb, 'ipad-landscape', 'n28-petshop', save)
    await g.ev("()=>{__goto('pets');__setClock(null,12);}"); await g.step(6)
    s = await g.ev(PENS)
    kinds = sorted(set(p['type'] for p in s['pens']))
    det.append(f"{s['floors']} floors; {len(s['pens'])} areas upstairs for {kinds}; {len(s['animals'])} animals")
    if s['floors'] != 2 or len(s['pens']) != 7 or kinds != sorted(FAMILY) or not all(p['up'] for p in s['pens']): probs.append(f"not 7 areas on a second floor: {s['pens']}")
    # each area holds only its own kind; no two areas overlap
    mixed = [p for p in s['pens'] if not set(p['kinds']) <= FAMILY.get(p['type'], set())]
    if mixed: probs.append(f'a kind in another\'s area: {mixed}')
    ov = []
    for a in s['pens']:
        for b in s['pens']:
            if a['i'] < b['i'] and a['x0'] < b['x1'] and b['x0'] < a['x1'] and a['z0'] < b['z1'] and b['z0'] < a['z1']: ov.append((a['type'], b['type']))
    if ov: probs.append(f'areas overlap: {ov}')
    # the animals stay in their own area while they wander (a minute of game time)
    out = await g.ev("""()=>{const L=LOC.pets;let bad=0,n=0;for(let f=0;f<1200;f++){__run(1);for(const a of PEN){n++;const q=a.pen;if(a.x<L.ox+q.x0-.45||a.x>L.ox+q.x1+.45||a.z<L.oz+q.z0-.45||a.z>L.oz+q.z1+.45)bad++;}}
      const wrong=PEN.filter(a=>{const q=a.pen;const k=a.t;const fam={dog:['dog','pug','pomchi','sausage'],cat:['cat'],bunny:['bunny'],hamster:['hamster'],capybara:['capybara'],duck:['duck'],owl:['owl']}[q.type]||[];return fam.indexOf(k)<0;}).map(a=>a.t+' in '+a.pen.type);
      return {bad,n,wrong,byPen:L.pens.map(p=>PEN.filter(a=>a.pen===p).map(a=>a.t))};}""")
    det.append(f"60 s of wandering: {out['bad']} of {out['n']} animal-frames outside their own area; who lives where: {out['byPen']}")
    if out['bad'] or out['wrong']: probs.append(f"animals outside or in the wrong area: {out['bad']} frames, {out['wrong']}")
    # downstairs: shelves of snacks and toys, a rack of pet clothes, buying works
    down = await g.ev("""()=>{const L=LOC.pets;const it=L.inter.filter(t=>!t.hdoor);const labels=it.map(t=>typeof t.label==='function'?t.label():t.label);
      const shelves=L.cols.filter(c=>c.cr===undefined&&c.z1<L.oz-4&&c.x2-c.x1>2.5).length;
      const c0=S.coins,b0=S.bag.treat|0;openShop('pets');const btn=document.querySelector('#card [data-a="buy:treat"]');if(btn)btn.click();const bought=(S.bag.treat|0)-b0,paid=c0-S.coins;const hasClothes=!!document.querySelector('#card [data-a="buy:bow"]');closePanel();
      return {labels:labels.filter(l=>/Upstairs|Downstairs|clothes|Buy|outside/.test(l)),shelves,bought,paid,hasClothes};}""")
    det.append(f"downstairs: {down['shelves']} shelf units along the back wall (snacks, toys, clothes), spots {down['labels']}; buying a treat: +{down['bought']} for {down['paid']} coins, the shop lists pet clothes {down['hasClothes']}")
    if down['shelves'] < 3 or down['bought'] != 1 or down['paid'] <= 0 or not down['hasClothes'] or not any('Upstairs' in l for l in down['labels']) or not any('clothes' in l.lower() for l in down['labels']): probs.append(f'downstairs: {down}')
    await g.ev("()=>{P.x=LOC.pets.ox+1.5;P.z=LOC.pets.oz+3.6;P.yaw=Math.PI*.02;P.pitch=.04;}"); await g.step(4); await g.shot('petshop-downstairs', both=False)
    # the stairs: up to the animals and back down
    u = await climb(g, 1); await g.ev("()=>{P.yaw=Math.PI;P.pitch=.02;}"); await g.step(4); await g.shot('petshop-upstairs', both=False)
    d = await climb(g, -1)
    det.append(f"stairs: up to floor {u['fl'] + 1} (z {u['dz']}), down to floor {d['fl'] + 1}")
    if u['fl'] != 1 or d['fl'] != 0: probs.append(f'the stairs: {u} {d}')
    # adopting still works: from upstairs, at a pen
    ad = await g.ev("""()=>{__goto('pets');hclimb(1);return 1;}""")
    for _ in range(40):
        await g.step(6); await g.wait(80)
        if not await g.ev("()=>!!CLIMB||!!fading"): break
    ad = await g.ev("""()=>{const a=PEN.find(q=>q.t==='pug');P.x=a.x+1.2;P.z=a.z+1.2;const n0=S.pets.length;a.target.act();const open=UI.open;const b=document.querySelector('#card [data-a="adopt"]');if(b)b.click();
      return {open,adopted:S.pets.length-n0,kind:S.pets.length?S.pets[S.pets.length-1].kind||S.pets[S.pets.length-1].type:null,fl:flOf(CUR,P.z)};}""")
    det.append(f"adopting a pug upstairs: card opens {ad['open']}, pets +{ad['adopted']} ({ad['kind']})")
    if not ad['open'] or ad['adopted'] != 1 or ad['kind'] != 'pug': probs.append(f'adopting: {ad}')
    errs = g.errors[:3]; await run.close(g)
    if errs: probs.append(f'browser errors: {errs}')
    return not probs, '; '.join(det) + (f' | PROBLEMS: {probs}' if probs else '')
