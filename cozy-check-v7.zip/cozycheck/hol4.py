"""Run 4, job 11: N20 (the holiday spot: February's heart fountain and petals; the Easter month's bunny and 25 eggs, all 25 -> the bunny costume and 50 coins once a year;
December's tree and Santa, 10 coins on 1 Dec and 300 on 31 Dec once per real day; other months the flower garden as before), N21 (New Year: fireworks on the game nights
of 28 to 31 Dec; party hats on everyone and confetti on 31 Dec and 1 Jan; nothing on 2 Jan) and N22 (the school party on 1 Sep: balloons around and in the school; a teacher
gives the globe once; nothing on 2 Sep). Every date is faked through realDate(), the game's one date function."""
import json
from night3 import fx, begin

async def at(g, iso, hour=12):
    """The faked real date, the game hour, and the holiday checks run (holCheck + extraCheck) with a few frames."""
    await g.ev("([d,h])=>{realDate=()=>new Date(d);__setClock(null,h);holCheck();extraCheck();}", [iso, hour]); await g.step(6)

ST = """()=>({cur:HOL.cur,n:HOL.n,gate:fcOpen(),pieces:HOL.pieces.map(p=>p.k).reduce((m,k)=>(m[k]=(m[k]||0)+1,m),{}),
  tree:HOL.pieces.filter(p=>p.k==='christmas tree').map(p=>[p.x,p.z]),fountain:HOL.pieces.filter(p=>p.k==='heart fountain').map(p=>[p.x,p.z]),
  petals:!!(HOL.petals&&HOL.petals.parent&&HOL.petals.geometry.attributes.position.count>50),eggs:HOL.eggs?HOL.eggs.length:0,eggN:HOL.eggN,
  santa:LOC.city.inter.some(t=>t.hol&&t.icon==='🎅'),bunny:LOC.city.inter.some(t=>t.hol&&t.icon==='🐰'),eggTargets:LOC.city.inter.filter(t=>t.hol&&t.icon==='🥚'&&!(t.when&&!t.when())).length})"""

async def n20(run, new_wb, FIX):
    probs = []; det = []
    if b'function valentineBuild' not in new_wb or b'function santaTalk' not in new_wb or b'function eggHuntBuild' not in new_wb: return False, 'the holiday spot for February, Easter and December is not built yet (job 11)'
    save = fx(FIX, 'save-prenight3-pets.json')
    A = await begin(run, new_wb, 'ipad-landscape', 'n20-A', dict(save, name='ZZTEST-HOL'))
    await A.ev("()=>{__goto('city');}")
    # February
    await at(A, '2027-02-14T12:00:00'); s = await A.ev(ST)
    walk = await A.ev("()=>{const [x,z]=HOL_SPOT;let px=x,pz=z-4;for(let i=0;i<80;i++){[px,pz]=collideXZ(px,pz+.08,.3,LOC.city);}return +Math.hypot(px-x,pz-z).toFixed(2);}")
    det.append(f"14 Feb: {s['cur']}, gate open {s['gate']}, pieces {s['pieces']}, petals {s['petals']}; walking at the heart fountain stops {walk} m from its middle")
    if s['cur'] != 'valentine' or not s['gate'] or len(s['fountain']) != 1 or s['pieces'].get('heart', 0) < 4 or not s['petals'] or walk < 1.0: probs.append('February')
    await A.ev("()=>{const [x,z]=HOL_SPOT;P.x=x+1.5;P.z=z+6.5;P.yaw=Math.atan2(-(x-P.x),-(z-P.z));P.pitch=.08;}"); await A.step(4); await A.shot('valentine-fountain', both=False)
    # the Easter month (Easter Sunday 28 Mar 2027: March)
    await at(A, '2027-03-10T12:00:00'); s = await A.ev(ST)
    det.append(f"10 Mar 2027: {s['cur']}, bunny {s['bunny']}, {s['eggs']} hunt eggs ({s['eggN']} drawn, {s['eggTargets']} to pick up), decorative eggs {s['pieces'].get('egg', 0)}")
    if s['cur'] != 'easter' or not s['bunny'] or s['eggs'] != 25 or s['eggN'] != 25 or s['eggTargets'] != 25: probs.append('the Easter month')
    spotsA = await A.ev("()=>HOL.eggs.map(e=>[+e.x.toFixed(1),+e.z.toFixed(1)])")
    Bp = await begin(run, new_wb, 'pc-1366', 'n20-B', dict(save, name='ZZTEST-HOLB')); await Bp.ev("()=>{__goto('city');}")
    await at(Bp, '2027-03-25T15:00:00'); spotsB = await Bp.ev("()=>HOL.eggs.map(e=>[+e.x.toFixed(1),+e.z.toFixed(1)])")
    await at(Bp, '2026-04-10T12:00:00'); spots26 = await Bp.ev("()=>HOL.cur==='easter'?HOL.eggs.map(e=>[+e.x.toFixed(1),+e.z.toFixed(1)]):null")
    diff26 = len([p for p in (spots26 or []) if p not in spotsA])
    det.append(f"a PC-size player two weeks later finds the 25 eggs at the same spots: {spotsA == spotsB}; in April 2026 (Easter 5 Apr) {diff26} of the spots differ")
    if spotsA != spotsB or not spots26 or diff26 < 5: probs.append('the egg spots are not the same for everyone that year / the same every year')
    # the hunt: the bunny keeps the secret, every egg counts, the prize once a year
    hunt = await A.ev("""()=>{const out={};const T=()=>LOC.city.inter.find(t=>t.hol&&t.icon==='🐰');const toasts=[];const t0=toast;toast=(m)=>{toasts.push(String(m));return t0(m);};
      try{T().act();out.first=toasts[toasts.length-1];const eggs=LOC.city.inter.filter(t=>t.hol&&t.icon==='🥚');const c0=S.coins;eggs[0].act();out.one=S.egg.f.length;out.drawn1=HOL.eggN;eggs[0].act();out.twice=S.egg.f.length;
        for(const e of eggs)e.act();out.all=S.egg.f.length;out.drawnAll=HOL.eggN;out.left=LOC.city.inter.filter(t=>t.hol&&t.icon==='🥚'&&!(t.when&&!t.when())).length;out.coinsBefore=S.coins-c0;
        T().act();out.prize=toasts[toasts.length-1];out.costume=!!(S.wardrobe&&S.wardrobe.co_bunny);out.coins=S.coins-c0;out.done=S.eggDone;T().act();out.again=S.coins-c0;
        out.wear=(()=>{S.look.co='bunny';const p=makePerson(lookToPerson(S.look));let n=0;p.root.traverse(o=>{if(o.isMesh)n++;});delete S.look.co;return n;})();
        out.shop=(()=>{openClothes();const b=!!document.querySelector('#card [data-a="cloth:co_bunny"]');closePanel();return b;})();}
      finally{toast=t0;}return out;}""")
    det.append(f"hunt: bunny first: '{hunt['first'][:60]}'; egg 1 picked: {hunt['one']} found ({hunt['drawn1']} drawn), picked again: {hunt['twice']}; all: {hunt['all']} found, {hunt['drawnAll']} drawn, {hunt['left']} left to pick, coins from eggs {hunt['coinsBefore']}; the bunny: costume {hunt['costume']}, +{hunt['coins']} coins, done {hunt['done']}; asked again: {hunt['again']} coins in all; the costume draws ({hunt['wear']} parts); in the shop as yours: {hunt['shop']}")
    if 'secret' not in hunt['first'].lower() and 'surprise' not in hunt['first'].lower(): probs.append('the bunny gives the prize away')
    if hunt['one'] != 1 or hunt['twice'] != 1 or hunt['all'] != 25 or hunt['drawnAll'] != 0 or hunt['left'] != 0 or hunt['coinsBefore'] != 0: probs.append('the egg hunt counting')
    if not hunt['costume'] or hunt['coins'] != 50 or hunt['done'] != 2027 or hunt['again'] != 50 or hunt['wear'] < 10 or not hunt['shop']: probs.append('the prize')
    nxt = await A.ev("(d)=>{realDate=()=>new Date(d);holCheck();const st=eggState();return {y:st.y,f:st.f.length,done:S.eggDone,eggs:HOL.eggs?HOL.eggs.length:0};}", '2028-04-05T12:00:00')
    det.append(f"next Easter (April 2028): a fresh hunt {nxt['f']} of {nxt['eggs']} found, the prize year still {nxt['done']}")
    if nxt['y'] != 2028 or nxt['f'] != 0 or nxt['eggs'] != 25 or nxt['done'] != 2027: probs.append('the hunt does not start again next year')
    await at(A, '2027-03-10T12:00:00'); await A.ev("()=>{P.x=-18.3;P.z=-8.6;P.yaw=Math.atan2(-(-18.3-P.x),-(-12.9-P.z));P.pitch=.02;}"); await A.step(4); await A.shot('easter-bunny', both=False)
    # December: the tree at the corner, not in the park; Santa's coins once per real day
    await at(A, '2026-12-01T12:00:00'); s = await A.ev(ST)
    park = [t for t in s['tree'] if abs(t[0] + 27.5) < 2 and abs(t[1] - 13.5) < 2]
    det.append(f"1 Dec: {s['cur']}, tree at {s['tree']} (in the park: {len(park)}), presents {s['pieces'].get('present', 0)}, Santa {s['santa']}, gate open {s['gate']}")
    if s['cur'] != 'xmas' or len(s['tree']) != 1 or park or s['pieces'].get('present', 0) < 8 or not s['santa'] or not s['gate']: probs.append('December')
    santa = await A.ev("""()=>{const T=()=>LOC.city.inter.find(t=>t.hol&&t.icon==='🎅');const out=[];for(const d of ['2026-12-01T12:00:00','2026-12-01T18:00:00','2026-12-16T12:00:00','2026-12-31T12:00:00']){realDate=()=>new Date(d);holCheck();const c=S.coins;T().act();out.push(S.coins-c);}return out;}""")
    det.append(f"Santa's coins: 1 Dec {santa[0]}, again that day {santa[1]}, 16 Dec {santa[2]}, 31 Dec {santa[3]}")
    if santa != [10, 0, 155, 300]: probs.append(f'Santa coins {santa}')
    await at(A, '2026-12-10T12:00:00'); await A.ev("()=>{const [x,z]=HOL_SPOT;P.x=x+2.2;P.z=z+6.8;P.yaw=Math.atan2(-(x-P.x),-(z-P.z));P.pitch=.18;}"); await A.step(4); await A.shot('december-tree-santa', both=False)
    # other months: the flower garden as before; the window edges
    await at(A, '2027-05-10T12:00:00'); s = await A.ev(ST)
    det.append(f"10 May: holiday {s['cur']}, {s['n']} pieces, gate open {s['gate']}")
    if s['cur'] is not None or s['n'] != 0 or s['gate']: probs.append('a plain month')
    edges = []
    for iso, want in (('2027-01-31T23:00:00', None), ('2027-02-01T00:10:00', 'valentine'), ('2027-02-28T23:00:00', 'valentine'), ('2027-03-01T00:10:00', 'easter'), ('2027-03-31T23:00:00', 'easter'), ('2027-04-01T00:10:00', None),
                      ('2026-11-30T23:00:00', None), ('2026-12-01T00:10:00', 'xmas'), ('2026-12-31T23:00:00', 'xmas'), ('2027-01-01T00:10:00', None), ('2026-04-15T12:00:00', 'easter'), ('2026-03-15T12:00:00', None)):
        await A.ev("(d)=>{realDate=()=>new Date(d);holCheck();}", iso); await A.step(2); c = await A.ev("()=>HOL.cur")
        if c != want: edges.append(f'{iso[:10]}: {c} (wanted {want})')
    det.append('month edges: ' + ('all right' if not edges else '; '.join(edges)))
    if edges: probs.append('month edges')
    errs = A.errors[:2] + Bp.errors[:2]; await run.close(A); await run.close(Bp)
    if errs: probs.append(f'browser errors: {errs}')
    return not probs, '; '.join(det) + (f' | PROBLEMS: {probs}' if probs else '')

NYE = """()=>({party:PARTY.on,hats:PARTY.hats.filter(h=>h.parent).length,hatsOn:PARTY.hats.filter(h=>h.parent&&h.visible).length,ownHidden:PARTY.own.filter(h=>h.parent&&!h.visible).length,own:PARTY.own.filter(h=>h.parent).length,
  fwWant:FW.want,fwVis:!!(FW.m&&FW.m.visible),fwN:FW.n,conf:!!(CONF.m&&CONF.m.visible),confOp:+CONF.op.toFixed(2),walkers:WALKERS.length,loc:CUR.id})"""
async def n21(run, new_wb, FIX):
    probs = []; det = []
    if b'function fwTick' not in new_wb or b'function partySet' not in new_wb: return False, 'New Year is not built yet (job 11)'
    save = fx(FIX, 'save-prenight3-pets.json')
    g = await begin(run, new_wb, 'ipad-landscape', 'n21-newyear', dict(save, name='ZZTEST-NYE'))
    await g.ev("()=>{__goto('city');}")
    # fireworks: the nights of 28 to 31 Dec, not by day, not on 27 Dec or 1 Jan
    rows = []
    for iso, hour, label in (('2026-12-27T21:00:00', 21, '27 Dec night'), ('2026-12-28T21:00:00', 21, '28 Dec night'), ('2026-12-28T12:00:00', 12, '28 Dec day'), ('2026-12-31T22:00:00', 22, '31 Dec night'), ('2027-01-01T21:00:00', 21, '1 Jan night')):
        await at(g, iso, hour); await g.ev("()=>{FW.n=0;}"); await g.step(90); s = await g.ev(NYE); rows.append((label, s['fwWant'], s['fwVis'], s['fwN']))
    det.append('fireworks [want, drawn, bursts in 4.5 s]: ' + ', '.join(f'{l}: {w} {v} {n}' for l, w, v, n in rows))
    want = {'27 Dec night': False, '28 Dec night': True, '28 Dec day': False, '31 Dec night': True, '1 Jan night': False}
    if any(w != want[l] or v != want[l] or (want[l] and n < 1) or (not want[l] and n > 0) for l, w, v, n in rows): probs.append('fireworks nights')
    await at(g, '2026-12-30T21:30:00', 21.5); await g.step(60); await g.ev("()=>{P.pitch=.55;}"); await g.step(30); await g.shot('fireworks', both=False)
    # party hats and confetti: 31 Dec and 1 Jan, nothing on 30 Dec or 2 Jan; indoors no confetti
    rows = []
    for iso, label in (('2026-12-30T12:00:00', '30 Dec'), ('2026-12-31T12:00:00', '31 Dec'), ('2027-01-01T12:00:00', '1 Jan'), ('2027-01-02T12:00:00', '2 Jan')):
        await at(g, iso, 12); await g.step(40); s = await g.ev(NYE); rows.append((label, s))
    det.append('party [hats on / hats, own hats hidden / own, confetti]: ' + ', '.join(f"{l}: {s['hatsOn']}/{s['hats']} {s['ownHidden']}/{s['own']} {s['conf']}" for l, s in rows))
    for l, s in rows:
        on = l in ('31 Dec', '1 Jan')
        if s['party'] != on or s['hats'] < 20 or (on and s['hatsOn'] != s['hats']) or (not on and s['hatsOn'] != 0) or (on and s['ownHidden'] != s['own']) or (not on and s['ownHidden'] != 0) or s['conf'] != on: probs.append(f'party on {l}')
    await at(g, '2026-12-31T12:00:00', 12); await g.step(40)
    me = await g.ev("()=>{const p=makePerson(lookToPerson(S.look));const ph=PARTY.hats[PARTY.hats.length-1];return {mine:!!(ph&&ph.parent&&ph.visible),peerHat:(()=>{const q=makePerson(lookToPerson(Object.assign({},S.look,{hat:'cap'})));const own=PARTY.own[PARTY.own.length-1],par=PARTY.hats[PARTY.hats.length-1];return [own.visible,par.visible];})()};}")
    det.append(f"my own look gets a party hat {me['mine']}; a friend with a cap: cap shown {me['peerHat'][0]}, party hat shown {me['peerHat'][1]}")
    if not me['mine'] or me['peerHat'] != [False, True]: probs.append('the hats on players')
    await g.ev("()=>{const w=WALKERS.find(w=>w.state!=='home')||WALKERS[0];P.x=w.x+1.6;P.z=w.z+1.6;P.yaw=Math.atan2(-(w.x-P.x),-(w.z-P.z));P.pitch=.1;}"); await g.step(4); await g.shot('party-hats-confetti', both=False)
    await g.ev("()=>{__goto('home');}"); await g.step(60); s = await g.ev(NYE)
    det.append(f"indoors: confetti {s['conf']} (fade {s['confOp']})")
    if s['conf']: probs.append('confetti indoors')
    errs = g.errors[:2]; await run.close(g)
    if errs: probs.append(f'browser errors: {errs}')
    return not probs, '; '.join(det) + (f' | PROBLEMS: {probs}' if probs else '')

async def n22(run, new_wb, FIX):
    probs = []; det = []
    if b'function schoolBuild' not in new_wb or b'function schoolGift' not in new_wb: return False, 'the school party is not built yet (job 11)'
    save = fx(FIX, 'save-prenight3-pets.json')
    g = await begin(run, new_wb, 'ipad-landscape', 'n22-school', dict(save, name='ZZTEST-SCH'))
    await g.ev("()=>{__goto('city');}")
    await at(g, '2026-09-01T12:00:00'); s = await g.ev("()=>({on:SCH.on,pieces:SCH.pieces,out:HOL.pieces.filter(p=>p.k==='balloons').length,outside:!!(SCH.g&&SCH.g.parent),inside:!!(SCH.gin&&SCH.gin.parent&&SCH.gin.children.length),nearSchool:HOL.pieces.filter(p=>p.k==='balloons'&&Math.abs(p.x+25)<16&&Math.abs(p.z+58)<4).length})")
    det.append(f"1 Sep: party {s['on']}, {s['pieces']} balloon bunches ({s['out']} outside by the school: {s['nearSchool']} within its front; in the hall {s['inside']})")
    if not s['on'] or s['out'] < 6 or s['nearSchool'] < 6 or not s['inside']: probs.append('balloons on 1 Sep')
    await g.ev("()=>{P.x=-25;P.z=-48;P.yaw=0;P.pitch=.06;}"); await g.step(4); await g.shot('school-balloons', both=False)   # (stage 3: yaw 0 looks towards -z, at the school front; it looked away before)
    gift = await g.ev("""()=>{const toasts=[];const t0=toast;toast=(m)=>{toasts.push(String(m));return t0(m);};try{const n0=(S.home.store||[]).filter(i=>i.t==='globe').length;tcTalk();const a=(S.home.store||[]).filter(i=>i.t==='globe').length;const t1=toasts[toasts.length-1]||'';tcTalk();const b=(S.home.store||[]).filter(i=>i.t==='globe').length;
      const f=buildFurn('globe');let parts=0;f.traverse(o=>{if(o.isMesh)parts++;});return {n0,a,b,year:S.globe,toast:t1.slice(0,70),parts,furn:!!FURN.globe,shop:BUY_FURN.indexOf('globe')};}finally{toast=t0;}}""")
    det.append(f"the teacher: globes in My stuff {gift['n0']} -> {gift['a']} after talking, {gift['b']} after talking again (year {gift['year']}); '{gift['toast']}'; the globe builds with {gift['parts']} parts, in the shop {gift['shop'] >= 0}")
    if gift['a'] != gift['n0'] + 1 or gift['b'] != gift['a'] or gift['year'] != 2026 or gift['parts'] < 5 or gift['shop'] >= 0: probs.append('the globe')
    nxt = await g.ev("(d)=>{realDate=()=>new Date(d);holCheck();extraCheck();const a=(S.home.store||[]).filter(i=>i.t==='globe').length;tcTalk();return {sep2:SCH.on,g:SCH.g!==null,after:(S.home.store||[]).filter(i=>i.t==='globe').length-a};}", '2026-09-02T12:00:00')
    det.append(f"2 Sep: party {nxt['sep2']}, balloons left {nxt['g']}, a globe from the teacher {nxt['after']}")
    if nxt['sep2'] or nxt['g'] or nxt['after']: probs.append('2 Sep')
    ny = await g.ev("(d)=>{realDate=()=>new Date(d);holCheck();extraCheck();const a=(S.home.store||[]).filter(i=>i.t==='globe').length;tcTalk();return {on:SCH.on,after:(S.home.store||[]).filter(i=>i.t==='globe').length-a,year:S.globe};}", '2027-09-01T12:00:00')
    det.append(f"1 Sep 2027: party {ny['on']}, a new globe {ny['after']} (year {ny['year']})")
    if not ny['on'] or ny['after'] != 1 or ny['year'] != 2027: probs.append('next year')
    await g.ev("()=>{__goto('school');P.x=LOC.school.ox;P.z=LOC.school.oz+2.5;P.yaw=0;P.pitch=.05;}"); await g.step(4); await g.shot('school-hall-balloons', both=False)
    errs = g.errors[:2]; await run.close(g)
    if errs: probs.append(f'browser errors: {errs}')
    return not probs, '; '.join(det) + (f' | PROBLEMS: {probs}' if probs else '')
