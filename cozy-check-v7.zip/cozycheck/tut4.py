"""Run 4, job 14: N38 (the hairstylist and pizza jobs show a picture tutorial the first time and from "?")."""
import json
from night3 import fx, begin

STATE = """()=>({on:!!TUT,hidden:$('tut').hidden,i:TUT?TUT.i:-1,n:TUT?(TUT.steps||TUT_STEPS).length:0,pic:!$('tutPic').hidden&&($('tutPic').src||'').length>1500,
  words:TUT?((TUT.steps||TUT_STEPS)[TUT.i].x||'').split(/\\s+/).length:0,title:$('tutT').textContent,next:$('tutNext').textContent})"""

async def one_job(run, new_wb, FIX, job, flag):
    """A fresh player takes the job: the picture tutorial shows by itself, every step has a picture and few words; done, it stays away; "?" brings it back."""
    probs = []; det = []
    save = dict(fx(FIX, 'save-prenight3-pets.json'), name='ZZTEST-TUT-' + job); save.pop('tutDone', None); save.pop('hsTut', None); save['job'] = None
    g = await begin(run, new_wb, 'ipad-landscape', 'n38-' + job, save)
    await g.ev("(k)=>{__goto('city');__setClock(null,12);setJob(k);}", job)
    shown = None
    for _ in range(40):
        await g.step(6); await g.wait(120); s = await g.ev(STATE)
        if s['on'] and not s['hidden']: shown = s; break
    if not shown: await run.close(g); return False, f'{job}: the tutorial did not show by itself after taking the job'
    steps = []
    for k in range(shown['n']):
        s = await g.ev(STATE); steps.append((s['title'], s['pic'], s['words']))
        if k == 0: await g.shot(f'tutorial-{job}-step-1', both=False)
        if k == 1: await g.shot(f'tutorial-{job}-step-2', both=False)
        await g.ev("()=>$('tutNext').click()"); await g.step(2)
    after = await g.ev("(f)=>({on:!!TUT,hidden:$('tut').hidden,flag:!!S[f]})", flag)
    det.append(f"{job}: shows by itself {shown['n']} steps: " + ', '.join(f"'{t}' picture {p} {w} words" for t, p, w in steps) + f"; after the last step: gone {after['hidden'] and not after['on']}, remembered {after['flag']}")
    if not (3 <= shown['n'] <= 5): probs.append(f'{job}: {shown["n"]} steps (wanted 3 to 5)')
    if not all(p for _, p, _ in steps): probs.append(f'{job}: a step without a picture')
    if any(w > 9 for _, _, w in steps): probs.append(f'{job}: a step with more than 9 words')
    if after['on'] or not after['hidden'] or not after['flag']: probs.append(f'{job}: not finished or not remembered')
    # it stays away now (a second time), then the "?" on the job card brings it back
    await g.ev("()=>{TUT=null;$('tut').hidden=true;}"); await g.step(60)
    again = await g.ev(STATE)
    q = await g.ev("(k)=>{const html=jobCards();const has=html.indexOf('data-a=\"jobtut:'+k+'\"')>=0;ACT.jobtut(k);return has;}", job)
    back = None
    for _ in range(20):
        await g.step(4); await g.wait(100); s = await g.ev(STATE)
        if s['on'] and not s['hidden']: back = s; break
    det.append(f"second time by itself: {again['on']}; the job card has a ❓: {q}; ❓ brings it back: {bool(back)}")
    if again['on'] or not q or not back: probs.append(f'{job}: the ? or the repeat rule')
    errs = g.errors[:2]; await run.close(g)
    if errs: probs.append(f'{job} browser errors: {errs}')
    return not probs, '; '.join(det) + (f' | PROBLEMS: {probs}' if probs else '')

async def n38(run, new_wb, FIX):
    if b'function tutPic' not in new_wb: return False, 'the picture tutorials are not built yet (job 14)'
    ok1, d1 = await one_job(run, new_wb, FIX, 'delivery', 'tutDone')
    ok2, d2 = await one_job(run, new_wb, FIX, 'hair', 'hsTut')
    return ok1 and ok2, d1 + ' || ' + d2
