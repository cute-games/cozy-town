# Cozy Town check kit - for Claude in a new chat (check version 7, kit updated 23 Oct 2026)
Since 22 Oct (the owner): ONLY THE GITHUB VERSION EXISTS. The game is index.html on branch main of cute-games/cozy-town (live at cute-games.github.io/cozy-town).
The old Claude copy (artifact) is dropped: no syncing, no publishing, no checks on it. Rules for updates: CLAUDE.md and HANDOFF.md in the repo.
The kit still tests an offline test copy of the game: strip_online.py removes the online part (online-part.json: 8 lines at the top - manifest, icons,
Home Screen meta, theme-color - and 47 lines of Firebase scripts) and stops if they are not found. The "--live-claude/--new-claude" names mean that offline copy.
1. Get the kit from the repo (no Artifact read of the final-check page needed):
   curl -sL https://raw.githubusercontent.com/cute-games/cozy-town/main/cozy-check-v7.zip -o kit.zip && unzip -q kit.zip -d /home/claude/kit   (or use the repo clone)
2. Newest live version, read right before the check:
   curl -s https://raw.githubusercontent.com/cute-games/cozy-town/main/index.html -o /home/claude/kit/live/github-live.html
   python3 cozycheck/strip_online.py live/github-live.html live/claude-form-of-github-live.html      (this is --live-claude)
3. The new version: the new GitHub file (the pull request's branch tip) -> new/github-new.html;
   python3 cozycheck/strip_online.py new/github-new.html new/claude-new.html      (this is --new-claude)
4. Backup before an update (owner's OK 23 Oct): a dated branch on GitHub, backup-YYYY-MM-DD, made from main (git push origin origin/main:refs/heads/backup-YYYY-MM-DD,
   or on github.com: branch menu -> type the name -> "Create branch from main"). Fetch its index.html from raw.githubusercontent.com/cute-games/cozy-town/backup-YYYY-MM-DD/index.html
   and pass it with --backup and --backup-title "backup-YYYY-MM-DD". A2 compares it with the live GitHub file. To restore: a pull request that puts that branch's index.html back on main.
5. Run (background; runs die between chat messages, so run the same command again to continue; finished stages are skipped):
   cd /home/claude/kit && setsid nohup python3 -u cozycheck/cozy_check2.py --live-claude live/claude-form-of-github-live.html --new-claude new/claude-new.html \
      --live-web live/github-live.html --backup BACKUP.html --backup-title "backup-YYYY-MM-DD" --out /home/claude/kit/run --tag TAG [--full] > run.log 2>&1 < /dev/null &
   Poll rarely (each poll is a chat turn that costs tokens): sleep as long as the tool allows between looks; read only the tail of run.log.
   --full = the full sweep for big updates (decision 7 Oct): every screen on all 10 device sizes.
   Safari's engine (WebKit) is not installed in this container, so C1-WK stays NOT RUN; real iPads and iPhones cover it in the notebook.
   OUT/github-index.html (= new offline copy + the same online part) must be byte for byte new/github-new.html.
6. Paste the block from "===== COZY TOWN FINAL CHECK =====" to "RESULT:" exactly as printed.
7. After the owner merges the pull request: run again with --github <raw GitHub fetch of main> to fill F3 (the GitHub file is exactly the tested file).
Changes in version 7 (23 Oct, owner's OK): A1 reads GitHub only; A2 = dated backup branch; stage 'claude' (C7) and F2 removed; F3 = the GitHub file after upload
is exactly the tested file; the old step 8 (publish and re-check the Claude copy) removed. Old kits (cozy-check-v4/v5/v5.1/v6.zip, cozy-night-kit.zip) are history only.
Setup notes: Playwright 1.56 + Chromium in /opt/pw-browsers. Container network allows npm/pypi/github only, so the kit carries
three.js r128 (npm three@0.128.0) and the Baloo 2 font (npm @fontsource/baloo-2). Test copies get a fake Firebase / fake room (fakenet.js).
Fixtures: cozycheck/fixtures/ holds saved games made by older versions (names start with ZZTEST); B1 loads them all in the new version.
Add a rich save made by each new live version.
B1 exception (the owner's OK, 9 Oct): a save that never had a player id ('pid') may get a new one. A save that has one must keep it exactly.
Changes in version 3 (9 Oct): stage 'book' with W1 (the What's new book: 9 pages, pictures, Next/Back/swipe/arrow keys/Escape/✕/tap outside/Let's play!, Next stays in place) and W2 ("Designed by Izabele 💗" on screen, clear of buttons and the version label) on iPad, iPhone upright and sideways, PC. When a new book replaces this one, change the page count in s_book.
Changes in version 2 (9 Oct): B1 player-id exception · A2 backs up the live GitHub file (GitHub first) · --full sweep option · strip_online.py,
online-part.json and the old test saves added to the kit.

Changes in version 4 (16 Oct): E1 can take agreed per-area limits: --e1-limits "city:0.35:0.60,beach:0.35:0.60" (owner's OK 16 Oct,
for night 3: the town and the beach may have up to 35% more pieces and 60% more triangles; every other area stays at 10%).
The limits used are printed on the E1 line. Without --e1-limits the check is exactly version 3.

Changes in version 5 (17 Oct, night 3): stage 'night3' (night3.py) with lines N1 to N14 for the night-3 jobs: holidays from the real calendar
(faked dates: the test copy replaces the game's one date function realDate), Rosie silent, friends in view, walkers give way, benches, grandmas,
kitchen snapping, 2-room designer orders, new foods and the food truck, weather and seasons, new pets and breeds, the house at 12x10 with an
upstairs, the hairstylist job, and 'smooth and light' (E1 measured with Halloween, rain and the animals on). Every line starts as FAIL and passes
only on proof. Four new fixtures made by the starting version of night 3 (save-prenight3-*.json): a crowded big house, a designer order in progress,
pets of every kind with outfits, a player saved upstairs. B1: a save that never had laneT (the time it moved to Friends Lane) may get one, like pid.

More B1 rules in version 5 (17 Oct, night 3), each written next to its code in checks.py: lists are compared entry by entry; a pet's spot (x, z) is
not compared (pets keep a 0.8 m gap, so one saved inside another steps aside at load); the day's quests (q.list, with q.used and qhist, the ones already drawn and the history) may differ when the unchanged
game also re-draws them on this load (the new version has more things to draw from); a bigger house that shrank to 12x10 counts every piece
(placed or in My stuff) and ignores coordinates. Test pages get window.__run(n): runs n game frames without drawing (fast on a slow machine).

Changes in version 5.1 (17 Oct, after the night-3 merge, a chat): the web part is put into the new Claude file by the two lines it sat between
(a line diff of the old and new Claude files), not by its old line number. Night 3 added 2 lines above the Firebase block, so version 5 placed
the Firebase scripts before the What's new book and three.js and tested that file (new GitHub 1566924e) instead of the real one (709bf763,
Firebase after three.js as always). checks.apply_web_part stops ('STOP: the web part cannot be placed') if a neighbour line changed or new lines
sit between them. OUT/github-index.html is now byte for byte the real GitHub file (step 6 above).
(17 Oct note on the artifact page frame and F2: moot since version 7, F2 is gone.)

Run 4, stage 2 (18 Oct 2026), still check version 6: the run-4 lines of the stage's jobs are written (hol4.py N20-N22, house4.py N33-N34, pets4.py N28, furn4.py N36, tut4.py N38, photo4.py N25, tree4.py N37, party4.py N39; three test players
in the fake room for N39, one of them on the old live file). A3 and the pizza tutorial: the owner's item 30 made it 5 picture steps (it was 9 text steps), so the full check names the four
old steps as agreed: --agreed-removals "tutorial_steps:#5,tutorial_steps:#6,tutorial_steps:#7,tutorial_steps:#8" (the kit's existing switch; nothing else is excused).

Run 4 finish (20 Oct 2026), still check version 6 (no check line weaker; the stages' results stay comparable with the 18 Oct runs):
- N15 (run4.py): its "no day number on the screen" test read the clock chip with the old rule (time and weekday only). That test runs on the morning
  after the bed test's night, so a check whose shared game day began as a Friday met the Saturday Pet Show 🏆 ("09:40 🏆 Sat") and failed with an
  empty list of day numbers (the live check of 20 Oct, 19:19 UTC). Old: ^\d{1,2}:\d\d (Mon|…|Sun)$. New: ^\d{1,2}:\d\d (🏆 )?(Mon|…|Sun)$, the rule
  N15's two-device test has used since stage 1. A day number in the chip, the HUD, the phone, the calendar or the messages still fails.
- Crawl (crawl.py): a target is found again by its label (the n-th of that label; else the one at the same spot) each time the crawler comes back to it,
  not by its index in a list fetched earlier. The list changes by itself while the crawl goes round (people who walk about, like the grandmas with their
  "Say hi", come and go), so an old index drifted onto another target: the 20 Oct crawl reported Zoomy Zac's football buttons under "Talk to Sir Barkley"
  and an unreachable Lady Fluffington (a probe reached all three judges). A target that has gone is "skipped: gone", as before.
- C2b (cozy_check2.py): the town part rides the Beach Bus once like a player (the clock is set to the next moment the bus stands at the park stop,
  said in the test log; then the use button at its door and the whole ride), and the beach's own spots are crawled. Before, the crawl never rode the
  bus, so C2b never reached the beach in any full check (stages 1 and 2). The bus ride and the beach's screens are not added to the device tours' list.
- Crawl (cozy_check2.py): every crawl part plays at 10:00 of the shared game day (said in the test log), as K1 plays at noon. The one clock sets the
  hour from the real time and a third of every game day is night, when the shops, the salon and the designer's clients are shut: a crawl that ran
  at game night could not reach the salon or a client's house (C2b). The bus ride tries the door up to three times (people walk past the stop).
- Tours (crawl.py): a thing that is only there on some days or hours (the Pet Show entry on Saturdays, a football match by day) is met on the game
  weekday and hour the iPad crawl met it (its recipe keeps them), when it is not there by its label at the tour's own time.
- Tours (crawl.py), the second fix: the recipe keeps the game day too, read before the crawler walks to the thing, and a tour meets it on that very
  day and hour (the weekday rule stays for a recipe without a day). The bus comes on other days in other weeks, so "the next Tuesday" two game days
  later had no bus: 5 of 7 tours of the 20 Oct rerun said "Get on the bus (free 🎟️): thing not found".
- Crawl (crawl.py): when the use button does not take the target from any of the six sides (someone passing stood right there: in the 20 Oct
  Saturday rerun a passer-by, whose path runs 0.38 m from an apartment door, took that door's button for a moment, and C2 said "Go inside":
  unreachable), the crawler waits 2 s of game time and tries the six sides once more before it says unreachable.

Added 31 Oct 2026 (Pets and Farm Update, stage 1): stage 'pfu' (pfu.py) with lines P1 saves (save version 2 and a round trip), P2 night skip,
P3 morning bus home, P4 hats sit on the hair; later stages add their lines there. Quick kit: --only files,counts,saves,night3,run4,pfu.
Fixtures added: save-prepet1-designer2.json (N8 needs it; it was only in tools/check-fixtures), save-prepfu-main.json (made by main a47bb1a, 31 Oct)
and the saves of each finished stage of the update (save-pfu<N>-*.json).
Added 1 Nov 2026 (stage 2, the pet brain): P5 one need and food groups, P6 sickness (built, switched off until the vet clinic), P7 vet booking,
P8 bowl, naps and the healthy week, P9 friends see your pets for real and pet them, P10 the moves pack on every pet and its cost, P11 pets not
left behind on long walks. PFU_ONLY=P5,P9 runs some of them. Fixture save-pfu2-stage2.json.
