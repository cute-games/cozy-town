"""Crawl the game like a player: every area, every tappable spot, every panel, the buttons inside.
Real taps on touch devices, keys on PC. Moving next to a thing is done directly (walking is tested on its own)."""
import asyncio, json, hashlib, time

INSTR = r"""()=>{if(window.__instr)return;window.__instr=1;window.__toasts=0;window.__floats=0;
  const t0=window.toast;window.toast=function(){window.__toasts++;window.__lastToast=String(arguments[0]||'');return t0.apply(this,arguments);};
  const f0=window.floatText;if(f0)window.floatText=function(){window.__floats++;return f0.apply(this,arguments);};
  window.__goto=(loc)=>{try{if(CUT&&typeof endCut==='function')endCut();}catch(e){}try{closePanel();}catch(e){}try{if(DECO.on)decoEnd();}catch(e){}
    P.sit=null;P.ride=null;setLoc(loc);if(loc==='city'){P.x=-17;P.z=-4.6;P.yaw=0;}else{const d=DOORS[loc],L=LOC[loc];if(d){P.x=L.ox+d.inside[0];P.z=L.oz+d.inside[1];P.yaw=d.inside[2];}else{P.x=L.ox;P.z=L.oz;}}P.pitch=0;};
  window.__hash=s=>{let h=0;for(let i=0;i<s.length;i++)h=(h*31+s.charCodeAt(i))|0;return (h>>>0).toString(36)+':'+s.length;};}"""

SIG = r"""()=>({loc:CUR&&CUR.id,ui:UI.open,card:UI.open?__hash($('card').innerHTML):'',cut:!!CUT,cr:!!CR,deco:!!DECO.on,climb:!!CLIMB,
  sit:!!P.sit,ride:!!P.ride,coins:S.coins,toasts:window.__toasts,floats:window.__floats,tut:!$('tut').hidden,dtut:!$('dtut').hidden,note:!$('note').hidden,
  bag:__hash(JSON.stringify(S.bag)),home:__hash(JSON.stringify(S.home)),pets:__hash(JSON.stringify(S.pets||[])),job:__hash(JSON.stringify([S.job,S.jobAsk,S.dl,S.ds,S.tc])),
  nav:!!(typeof NAV!=='undefined'&&NAV),hud:$('hud').hidden,run:!!IN.run,look:__hash(JSON.stringify(S.look)),q:__hash(JSON.stringify(S.q||{})),
  set:__hash(JSON.stringify(SET)),pad:__hash(JSON.stringify(PAD.pages?PAD.pages.length:0)),fr:__hash(JSON.stringify(S.fr||{})),
  x:Math.round(P.x*4),z:Math.round(P.z*4),y:Math.round((P.jy||0)*20)+':'+Math.round((P.vy||0)*2),held:typeof HELD!=='undefined'&&HELD?1:0,tasks:$('tasks').className,ph:typeof PH!=='undefined'?String(PH.app):''})"""

def changed(a, b, ignore=()):
    return [k for k in a if k not in ignore and a.get(k) != b.get(k)]

class Crawler:
    def __init__(self, g, depth=1, per_label=2, budget_s=2400, shots=True, recurse=True):
        self.g = g; self.depth = depth; self.per_label = per_label; self.t0 = time.time(); self.budget = budget_s; self.recurse = recurse
        self.shots = shots
        self.res = {'tested': [], 'dead': [], 'unreachable': [], 'stuck': [], 'skipped': [], 'covered': [], 'areas': [], 'views': 0}
        self.views = set(); self.visited = set(); self.recipes = []

    def late(self):
        if time.time() - self.t0 > self.budget:
            if not self.res.get('unfinished'): self.res['unfinished'] = f'time budget of {self.budget} s ran out'
            return True
        return False

    async def settle(self, frames=6, wait_ms=650):
        g = self.g
        await g.step(frames); await g.wait(wait_ms); await g.step(frames)
        for _ in range(12):
            busy = await g.ev("()=>!!fading||!!CLIMB")
            if not busy: break
            await g.wait(300); await g.step(10)

    async def sig(self): return await self.g.ev(SIG)

    async def use_action(self):
        """Press the on-screen 'use' button with a finger, or E on the keyboard."""
        g = self.g
        if g.p['touch']:
            r = await g.tap('#act')
            if r and r.startswith('covered'): self.res['covered'].append(r)
            return r == 'ok'
        await g.key('KeyE'); return True

    async def recover(self, loc):
        g = self.g
        st = await g.ev("()=>({cut:!!CUT,ui:UI.open,lock:UI.lock,cr:!!CR,deco:!!DECO.on,loc:CUR.id,sit:!!P.sit,ride:!!P.ride,tut:!$('tut').hidden,dtut:!$('dtut').hidden,note:!$('note').hidden})")
        if st['cut']:
            for _ in range(30):
                await g.step(20)
                if not await g.ev("()=>!!CUT"): break
                acts = await g.ev("()=>[...document.querySelectorAll('#card [data-a]')].filter(b=>b.offsetParent).map(b=>b.dataset.a)")
                for a in ('pstap', 'clawtap', 'cutbye', 'psbye', 'revbye', 'tbye', 'clawdone', 'psskip', 'close'):
                    if a in acts: await g.tap(f'#card [data-a="{a}"]'); break
            if await g.ev("()=>!!CUT"):
                self.res['stuck'].append(f'{loc}: a cut-scene did not end')
                await g.ev("()=>{try{endCut();}catch(e){}}")
        if st['cr']:
            acts = await g.ev("()=>[...document.querySelectorAll('#card [data-a]')].map(b=>b.dataset.a)")
            await g.tap('#card [data-a="crcancel"]' if 'crcancel' in acts else '#card [data-a="crdone"]'); await self.settle()
        if st['tut']: await g.tap('#tutSkip'); await self.settle(3, 200)
        if st['dtut']: await g.tap('#dtSkip'); await self.settle(3, 200)
        if st['note']: await g.tap('#note'); await self.settle(2, 100)
        if await g.ev("()=>UI.open"):
            acts = await g.ev("()=>[...document.querySelectorAll('#card [data-a]')].filter(b=>b.offsetParent).map(b=>b.dataset.a)")
            done = False
            for a in ('close', 'cutbye', 'psbye', 'revbye', 'tbye', 'pback', 'cback', 'cloback', 'tback', 'fback'):
                if a in acts:
                    await g.tap(f'#card [data-a="{a}"]'); await self.settle(3, 300); done = True; break
            if not done or await g.ev("()=>UI.open"):
                if not g.p['touch']: await g.key('Escape')
                await self.settle(3, 300)
            if await g.ev("()=>UI.open&&!UI.lock"): await g.ev("()=>closePanel()")
            if await g.ev("()=>UI.open"): await g.ev("()=>{UI.lock=false;closePanel();}")
        if await g.ev("()=>DECO.on"): await g.tap('#bDeco'); await self.settle(3, 200)
        if await g.ev("()=>!!(P.sit||P.ride)"):
            if g.p['touch']: await g.tap('#act')
            else: await g.key('KeyE')
            await self.settle(3, 200)
            await g.ev("()=>{P.sit=null;if(P.ride)stopRide();}")
        if await g.ev(f"()=>CUR.id!=={json.dumps(loc)}"):
            await g.ev(f"()=>__goto({json.dumps(loc)})"); await self.settle(3, 400)

    async def shot(self, label, key=None, recipe=None):
        k = key or (await self.g.ev("()=>CUR.id+'|'+(UI.open?__hash($('card').innerHTML):'-')+'|'+$('toast').textContent.slice(0,40)"))
        if k in self.views: return None
        self.views.add(k); self.res['views'] += 1
        if recipe is not None: self.recipes.append(dict(recipe, label=label))
        return await self.g.shot(label, both=True) if self.shots else 'counted'

    async def targets(self):
        return await self.g.ev(r"""()=>{const lab=t=>{try{return String(typeof t.label==='function'?t.label():t.label||'')}catch(e){return '?'}};
          window.__T=targets();return window.__T.map((t,i)=>({i,label:lab(t),when:!t.when||!!t.when(),static:CUR.inter.includes(t)}));}""")

    async def approach(self, i):
        g = self.g
        for k in range(6):
            ok = await g.ev(r"""([i,k])=>{const t=window.__T[i];if(!t)return 'gone';if(t.when&&!t.when())return 'not-now';P.sit=null;if(P.ride){try{stopRide();}catch(e){}}
              let tx=t.x,tz=t.z;if(t.rect){tx=(t.rect.x1+t.rect.x2)/2;tz=(t.rect.z1+t.rect.z2)/2;}
              const a=[0,Math.PI/2,-Math.PI/2,Math.PI,Math.PI/4,-Math.PI/4][k];let dx=P.x-tx,dz=P.z-tz;const d=Math.hypot(dx,dz)||1;dx/=d;dz/=d;
              const c=Math.cos(a),s=Math.sin(a);const ux=dx*c-dz*s,uz=dx*s+dz*c;const want=t.rect?0.2:Math.max(0.55,Math.min(1.1,(t.r||1.5)*0.5));
              P.x=tx+ux*want;P.z=tz+uz*want;P.yaw=Math.atan2(-(tx-P.x),-(tz-P.z));P.pitch=-0.15;window.__want=t;return 'ok';}""", [i, k])
            if ok != 'ok': return ok
            await g.step(2)
            if await g.ev("()=>TARGET===window.__want&&!$('actWrap').hidden"): return 'ok'
        return 'unreachable'

    async def run(self):
        g = self.g
        await g.ev(INSTR)
        await self.crawl_hud()
        await self.recover('city')
        await self.crawl_loc('city')
        missing = await g.ev("()=>Object.keys(LOC)")
        self.res['areas_not_reached'] = [l for l in missing if l not in self.visited]
        return self.res

    async def crawl_hud(self):
        g = self.g
        for sel, name in (('#bPhone', 'phone'), ('#bBag', 'bag'), ('#bMenu', 'settings'), ('#bChat', 'chat')):
            if self.late(): return
            vis = await g.center(sel)
            if not vis: self.res['skipped'].append(f'HUD {name}: not on screen'); continue
            async def opener(sel=sel):
                await self.recover(await g.ev("()=>CUR.id")); r = await g.tap(sel); await self.settle(4, 350); return r
            r = await opener()
            if r != 'ok': self.res['covered'].append(f'HUD {name}: {r}'); continue
            if not await g.ev("()=>UI.open"): self.res['dead'].append(f'HUD {name} button: nothing opened'); continue
            self.res['tested'].append(f'HUD {name}')
            rec = {'kind': 'hud', 'sel': sel, 'path': []}
            await self.shot(f'hud-{name}', recipe=rec)
            if self.depth >= 1: await self.crawl_panel(f'hud-{name}', opener, [], self.depth, rec)
            await self.recover(await g.ev("()=>CUR.id"))
        for sel, name in (('#bRun', 'run'), ('#tasks', 'tasks'), ('#bJump', 'jump')):
            if not await g.center(sel): continue
            a = await self.sig(); r = await g.tap(sel); await g.step(3); b = await self.sig()
            ch = changed(a, b, ('toasts',))
            (self.res['tested'] if ch or name == 'jump' else self.res['dead']).append(f'HUD {name} button' + ('' if ch else ' (no change seen)'))
            if name == 'run': await g.tap(sel); await g.step(2)

    async def crawl_panel(self, where, opener, path, depth, rec=None):
        """Tap the buttons of the open panel. path = taps that led here from the opener."""
        g = self.g
        btns = await g.ev(r"""()=>[...document.querySelectorAll('#card [data-a]')].map((b,i)=>({i,a:b.dataset.a,
            on:b.classList.contains('on')||b.disabled||b.getAttribute('aria-pressed')==='true'||(b.classList.contains('butter')&&[...b.parentElement.children].some(x=>x!==b&&x.classList.contains('white'))),
            vis:!!b.offsetParent&&b.getBoundingClientRect().width>0,txt:(b.textContent||b.getAttribute('aria-label')||'').trim().slice(0,24)}))""")
        groups = {}
        for b in btns:
            if not b['vis']: continue
            groups.setdefault(b['a'].split(':')[0], []).append(b)
        chosen = []
        for k, lst in groups.items():
            if k in ('close',): continue
            if len(lst) <= 12: chosen += lst
            else: chosen += [lst[round(i * (len(lst) - 1) / 11)] for i in range(12)]
        chosen.sort(key=lambda b: ('tab' in b['a'].split(':')[0], 0))   # tabs last, so the other buttons are tried on the first tab
        for b in chosen:
            if self.late(): return
            if b['a'] == 'wipe':
                pass
            base = await self.sig()
            sel = f'#card [data-a="{b["a"]}"]'
            r = await g.tap(sel)
            if r is None:
                await self.reopen(opener, path); r = await g.tap(sel)
                if r is None:
                    kind = b['a'].split(':')[0]
                    if any(t.split(' > ')[-1].startswith(kind + ':') or t.split(' > ')[-1].startswith(kind + ' ') for t in self.res['tested']):
                        self.res.setdefault('used_up', []).append(f'{where} > {b["a"]}: gone after an earlier tap of the same kind (that kind was tested)'); continue
            if r != 'ok':
                self.res['covered' if r and r.startswith('covered') else 'unreachable'].append(f'{where} > {b["a"]} "{b["txt"]}": {r}')
                continue
            await self.settle(4, 450)
            if b['a'] == 'wipe': await g.ev("()=>{WIPE=false;}")
            after = await self.sig()
            ch = changed(base, after)
            label = f'{where} > {b["a"]} "{b["txt"]}"'
            tries = 1
            while not ch and not b['on'] and tries < 3 and await g.center(sel):
                # some buttons pick a random line; the same line twice looks like nothing happened, so try again before calling it dead
                await g.tap(sel); await self.settle(3, 300); after = await self.sig(); ch = changed(base, after); tries += 1
            if not ch:
                if b['on']: self.res['tested'].append(label + ' (already chosen)')
                else: self.res['dead'].append(label + f' (tapped {tries} times)')
            elif tries > 1:
                self.res.setdefault('repeats', []).append(label + f': changed only on tap {tries}')
            else:
                self.res['tested'].append(label)
                if ('card' in ch or 'ui' in ch or 'loc' in ch or 'cut' in ch or 'cr' in ch) and await g.ev("()=>UI.open||!!CUT||!!CR"):
                    sub = dict(rec or {}, path=path + [b['a']]) if rec else None
                    s = await self.shot(f'{where}-{b["a"]}', recipe=sub)
                    if s and depth > 1 and await g.ev("()=>UI.open&&!CUT"):
                        await self.crawl_panel(f'{where} > {b["a"]}', opener, path + [b['a']], depth - 1, sub)
            if await g.ev("()=>!!CUT||!!CR"): await self.recover(await g.ev("()=>CUR.id"))
            same = after['ui'] and after['card'] == base['card'] and not after['cut'] and not after['cr'] and after['loc'] == base['loc']
            if not same: await self.reopen(opener, path)

    async def reopen(self, opener, path):
        g = self.g
        await opener()
        for a in path:
            r = await g.tap(f'#card [data-a="{a}"]')
            if r != 'ok': return False
            await self.settle(3, 350)
        return True

    async def run_areas(self, areas, hud=False):
        g = self.g
        await g.ev(INSTR)
        if hud: await self.crawl_hud()
        for a in areas:
            if self.late(): break
            await self.crawl_loc(a)
        return self.res

    async def crawl_loc(self, loc):
        g = self.g
        if loc in self.visited or self.late() or loc == 'studio': return
        self.visited.add(loc)
        if loc not in self.res['areas']: self.res['areas'].append(loc)
        await self.recover(loc)
        await self.shot(f'area-{loc}', key='area|' + loc, recipe={'kind': 'area', 'loc': loc, 'path': []})
        ts = await self.targets()
        seen = {}
        for t in ts:
            if self.late(): return
            lab = t['label'] or '(no label)'
            if not t['when']: self.res['skipped'].append(f'{loc} "{lab}": not available right now'); continue
            n = seen.get(lab, 0)
            if n >= self.per_label: continue
            seen[lab] = n + 1
            await self.recover(loc)
            await self.targets()
            ap = await self.approach(t['i'])
            if ap != 'ok':
                (self.res['unreachable'] if ap == 'unreachable' else self.res['skipped']).append(f'{loc} "{lab}": {ap}'); continue
            base = await self.sig()
            if not await self.use_action():
                self.res['covered'].append(f'{loc} "{lab}": the use button was covered'); continue
            await self.settle(6, 700)
            after = await self.sig()
            ch = changed(base, after, ('x', 'z'))
            where = f'{loc} "{lab}"'
            if not ch: self.res['dead'].append(where); continue
            self.res['tested'].append(where)
            rec = {'kind': 'target', 'loc': loc, 'tlabel': lab, 'nth': n, 'path': []}
            if after['cr'] or after['loc'] == 'studio':
                # the mirror room only exists while the mirror is open; the game sends you back to town when it closes
                if 'studio' not in self.res['areas']: self.res['areas'].append('studio')
                await self.shot(f'{loc}-{lab}-mirror', recipe=rec)
                await self.recover(loc); continue
            if 'loc' in ch and after['loc'] != loc:
                new = after['loc']
                if new not in self.res['areas']: self.res['areas'].append(new)
                if self.recurse: await self.crawl_loc(new)
                else: await self.shot(f'{loc}-{lab}-arrived-in-{new}', key='arrive|' + new, recipe=rec)
                await self.recover(loc); continue
            if after['cut'] or after['climb']:
                await self.shot(f'{loc}-{lab}-start', recipe=rec)
                await self.recover(loc); continue
            if after['ui']:
                await self.shot(f'{loc}-{lab}', recipe=rec)
                if self.depth >= 1:
                    tidx = t['i']
                    async def opener(loc=loc, tidx=tidx, lab=lab):
                        await self.recover(loc); await self.targets()
                        if await self.approach(tidx) == 'ok':
                            await self.use_action(); await self.settle(6, 600)
                    await self.crawl_panel(where, opener, [], self.depth, rec)
            else:
                await self.shot(f'{loc}-{lab}', recipe=rec)
            await self.recover(loc)


async def replay(cr, rec):
    """Open one recorded screen again on another device: same area, same thing, same button taps (real taps)."""
    g = cr.g
    loc = rec.get('loc', 'city')
    await cr.recover(loc)
    if rec['kind'] == 'hud':
        if await g.tap(rec['sel']) != 'ok': return 'HUD button not tappable'
        await cr.settle(4, 350)
    elif rec['kind'] == 'target':
        ts = await cr.targets(); n = -1; idx = None
        for t in ts:
            if (t['label'] or '(no label)') == rec['tlabel'] and t['when']:
                n += 1
                if n == rec['nth']: idx = t['i']; break
        if idx is None: return 'thing not found'
        if await cr.approach(idx) != 'ok': return 'could not get next to it'
        if not await cr.use_action(): return 'use button covered'
        await cr.settle(6, 700)
    for a in rec.get('path', []):
        r = await g.tap(f'#card [data-a="{a}"]')
        if r != 'ok': return f'button {a}: {r}'
        await cr.settle(4, 450)
    return 'ok'
