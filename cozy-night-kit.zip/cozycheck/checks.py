"""Cozy Town final check: the individual checks. Each returns (ok, detail). ok is False unless proven."""
import asyncio, json, os, re, hashlib, difflib, time
from harness import md5b, PROFILES
from crawl import INSTR

WEB_HOSTS_OK = {'cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js', 'fonts.googleapis.com', 'fonts.gstatic.com'}

# ---------- files ----------
def web_part(claude_html: str, web_html: str):
    """The GitHub file = the Claude file + added lines. Returns the added blocks [(after_line_no, [lines])] or None if lines were removed/changed."""
    a = claude_html.split('\n'); b = web_html.split('\n')
    sm = difflib.SequenceMatcher(a=a, b=b, autojunk=False)
    blocks = []
    for tag, i1, i2, j1, j2 in sm.get_opcodes():
        if tag == 'equal': continue
        if tag != 'insert': return None
        blocks.append((i1, b[j1:j2]))
    return blocks

def apply_web_part(claude_html: str, blocks):
    a = claude_html.split('\n'); out = []; bi = 0
    blocks = sorted(blocks)
    for i, line in enumerate(a + [None]):
        while bi < len(blocks) and blocks[bi][0] == i:
            out += blocks[bi][1]; bi += 1
        if line is not None: out.append(line)
    return '\n'.join(out)

def outside_addresses(html: str):
    found = set()
    for m in re.finditer(r'''(?:src|href)\s*=\s*["'](https?://[^"']+)["']''', html):
        u = m.group(1).split('?')[0]; found.add(re.sub(r'^https?://', '', u))
    for m in re.finditer(r'''(?:fetch|import|XMLHttpRequest)\s*\(\s*["'](https?://[^"']+)''', html):
        found.add(re.sub(r'^https?://', '', m.group(1)))
    return found

def host_ok(u):
    return any(u == h or u.startswith(h + '/') or u == h.split('/')[0] for h in WEB_HOSTS_OK)

# ---------- counts ----------
def compare_counts(old, new, agreed_removals=()):
    missing = {}; grew = {}
    for k, v in old.items():
        nv = set(new.get(k, []))
        miss = [x for x in v if x not in nv and f'{k}:{x}' not in agreed_removals]
        if miss: missing[k] = miss
        if len(new.get(k, [])) > len(v): grew[k] = f'{len(v)} -> {len(new.get(k, []))}'
    for k in new:
        if k not in old: grew[k] = f'new list ({len(new[k])})'
    return missing, grew

# ---------- saves ----------
VOLATILE = {'t', 'time', 'hunger', 'px', 'pz', 'yaw', 'mpcode'}
def save_diff(a, b, path=''):
    """Everything in save a must still be in save b, the same. Returns a list of differences."""
    out = []
    if isinstance(a, dict):
        if not isinstance(b, dict): return [f'{path or "save"}: was an object, now {type(b).__name__}']
        for k, v in a.items():
            if not path and k in VOLATILE: continue
            if k not in b: out.append(f'{path}{k}: missing'); continue
            out += save_diff(v, b[k], f'{path}{k}.')
        return out
    if a != b: out.append(f'{path[:-1]}: {json.dumps(a)[:60]} -> {json.dumps(b)[:60]}')
    return out

async def start_from_save(g):
    await g.manual(); await g.ev(INSTR)
    for _ in range(12):
        st = await g.ev("()=>({title:!$('title').hidden,playing:PLAYING,ui:UI.open})")
        if st['playing'] and not st['title']: break
        if st['title']: await g.tap('#tPlay')
        await g.wait(700); await g.step(6)
    await g.step(10)

async def check_saves(run, old_web, new_web, fixtures):
    """B1/B2: each saved game made by an older version loads in the new version with nothing lost; the new version writes to the same save key."""
    details = []; ok = True
    for fname, fx in fixtures:
        go = await run.open(old_web, 'web', 'ipad-landscape', 'light', 'save-old', save=fx)
        await start_from_save(go); a = await go.state(); await go.shot('save-loaded-old'); await run.close(go)
        gn = await run.open(new_web, 'web', 'ipad-landscape', 'light', 'save-new', save=fx)
        await start_from_save(gn); b = await gn.state(); await gn.shot('save-loaded-new')
        await gn.step(230)
        wrote = await gn.ev("()=>{try{const o=JSON.parse(localStorage.getItem('cozytown-save-1'));return o&&o.name}catch(e){return null}}")
        await run.close(gn)
        d = save_diff(a, b)
        keyok = wrote == fx.get('name')
        ok = ok and not d and keyok and b.get('name') == fx.get('name')
        details.append(f'{fname}: name {b.get("name")!r}, coins {b.get("coins")}, furniture {len((b.get("home") or {}).get("items", []))}, pets {len(b.get("pets") or [])}; '
                       f'{len(d)} differences{(": " + "; ".join(d[:4])) if d else ""}; new version saves under the same key: {"yes" if keyok else "NO"}')
    return ok, ' | '.join(details)

# ---------- two players ----------
async def check_two_players(run, old_web, new_web, fxA, fxB):
    """D1-D3: an old-version player and a new-version player meet in the test room."""
    a = await run.open(old_web, 'web', 'ipad-landscape', 'light', 'A-old', save=fxA)
    await a.manual()   # pause A's own game loop so B can start without waiting for the CPU
    b = await run.open(new_web, 'web', 'pc-1366', 'dark', 'B-new', save=fxB)
    await start_from_save(a); await start_from_save(b)
    for _ in range(8):
        await a.step(8); await b.step(8); await asyncio.sleep(0.3)
    nA, nB = fxA['name'], fxB['name']
    seeA = await a.ev(f"()=>[...MP.peers.values()].some(p=>p.nm==={json.dumps(nB)}&&!!p.av)")
    seeB = await b.ev(f"()=>[...MP.peers.values()].some(p=>p.nm==={json.dumps(nA)}&&!!p.av)")
    # B walks forward with the keyboard; A must see B's new spot
    before = await a.ev(f"()=>{{const p=[...MP.peers.values()].find(p=>p.nm==={json.dumps(nB)});return p?[p.rx,p.rz]:null}}")
    await b.page.keyboard.down('KeyW'); await b.step(30); await b.page.keyboard.up('KeyW')
    for _ in range(4): await b.step(4); await a.step(4); await asyncio.sleep(0.2)
    after = await a.ev(f"()=>{{const p=[...MP.peers.values()].find(p=>p.nm==={json.dumps(nB)});return p?[p.rx,p.rz]:null}}")
    moved = bool(before and after and (abs(before[0] - after[0]) + abs(before[1] - after[1])) > 0.5)
    # A says "Hi!" from the chat panel with a real tap; B must hear it
    await a.ev(INSTR); await b.ev(INSTR)
    chat_ok = False; chat_detail = ''
    r = await a.tap('#bChat'); await a.step(4); await a.wait(300)
    if r == 'ok' and await a.ev("()=>UI.open"):
        await a.shot('chat-open')
        r2 = await a.tap('#card [data-a="mpsay:0"]')
        await a.step(4)
        for _ in range(4): await b.step(4); await a.step(2); await asyncio.sleep(0.2)
        heard = await b.ev(f"()=>({{t:window.__lastToast||'',bub:[...MP.peers.values()].some(p=>p.nm==={json.dumps(nA)}&&!!p.bub)}})")
        chat_ok = r2 == 'ok' and (heard['bub'] or nA in heard['t'])
        chat_detail = f'chat tap {r2}, B saw: {heard["t"][:40]!r}{" + bubble" if heard["bub"] else ""}'
        await a.recover_panel() if hasattr(a, 'recover_panel') else await a.ev("()=>closePanel()")
    else: chat_detail = f'chat button: {r}'
    lane = await a.ev("()=>LANE.own.filter(Boolean).length")
    laneB = await b.ev("()=>LANE.own.filter(Boolean).length")
    await a.shot('two-players-A-sees-B'); await b.shot('two-players-B-sees-A')
    # D3: B visits A's house from the phone (real taps); A lets B in (real tap on the ding-dong card)
    await b.ev("()=>closePanel()"); await a.ev("()=>closePanel()"); await b.step(3); await a.step(3)
    r1 = await b.tap('#bPhone'); await b.step(3); await b.wait(300)
    r2 = await b.tap('#card [data-a="phapp:mp"]'); await b.step(3); await b.wait(300)
    await b.shot('friends-app-on-B', both=True)
    r3 = await b.tap('#card [data-a^="mpvisit:"]')
    card = None; r4 = 'no card'
    for _ in range(24):
        await b.step(6); await b.wait(200); await a.step(6)
        if not card and await a.center('#kcYes'):
            card = True; await a.shot('ding-dong-card-on-A', both=True); r4 = await a.tap('#kcYes')
        if await b.ev("()=>CUR.id==='visit'"): break
    inside = await b.ev("()=>CUR.id"); visited = inside == 'visit'
    if visited:
        await b.step(10); await b.shot('B-inside-A-house', both=True)
    await run.close(a); await run.close(b)
    ok1 = seeA and seeB and moved and chat_ok
    return (ok1, f'A (old version, iPad) sees B: {seeA}; B (new version, PC) sees A: {seeB}; A saw B walk: {moved}; {chat_detail}'), \
           (lane >= 2 and laneB >= 2, f'Friends Lane houses taken: A sees {lane}, B sees {laneB} (need 2 each)'), \
           (visited, f'B knocked from the phone ({r1}/{r2}/{r3}); ding-dong card on A: {"yes, tapped " + str(r4) if card else "never showed"}; B ended up in: {inside}')

# ---------- walking ----------
async def check_walk(g):
    await g.ev(INSTR); await g.ev("()=>__goto('city')"); await g.step(3)
    p0 = await g.ev("()=>[P.x,P.z]")
    if g.p['touch']:
        cdp = await g.page.context.new_cdp_session(g.page)
        x, y = g.p['w'] * 0.18, g.p['h'] * 0.75
        await cdp.send('Input.dispatchTouchEvent', {'type': 'touchStart', 'touchPoints': [{'x': x, 'y': y, 'id': 1}]})
        await g.step(1)
        await cdp.send('Input.dispatchTouchEvent', {'type': 'touchMove', 'touchPoints': [{'x': x, 'y': y - 50, 'id': 1}]})
        await g.step(30)
        await cdp.send('Input.dispatchTouchEvent', {'type': 'touchEnd', 'touchPoints': []})
        how = 'joystick drag'
    else:
        await g.page.keyboard.down('KeyW'); await g.step(30); await g.page.keyboard.up('KeyW'); how = 'W key'
    p1 = await g.ev("()=>[P.x,P.z]")
    d = ((p1[0] - p0[0]) ** 2 + (p1[1] - p0[1]) ** 2) ** 0.5
    return d > 1.0, f'{how}: moved {d:.1f} m in 1.5 s'

# ---------- drawing work ----------
SPOTS = ['city', 'home', 'market', 'cafe', 'school']
async def weight(g):
    await g.ev(INSTR); out = {}
    for loc in SPOTS:
        out[loc] = await g.ev("""(loc)=>{__goto(loc);for(let i=0;i<4;i++){window.__t=Math.max(window.__t||0,performance.now())+50;frame(window.__t);}
          const real=window.__realRender||renderer.render;renderer.render=real;const t0=performance.now();for(let i=0;i<4;i++){window.__t+=50;frame(window.__t);}const ms=(performance.now()-t0)/4;
          return {calls:renderer.info.render.calls,tris:renderer.info.render.triangles,ms:Math.round(ms)};}""", loc)
    return out

def compare_weight(old, new, limit=0.10, time_limit=0.25):
    worse = []
    for loc, o in old.items():
        n = new.get(loc)
        if not o or not n: worse.append(f'{loc}: not measured'); continue
        for k, lim in (('calls', limit), ('tris', limit)):
            if o[k] and n[k] > o[k] * (1 + lim): worse.append(f'{loc} {k} {o[k]} -> {n[k]}')
        if o['ms'] and n['ms'] > o['ms'] * (1 + time_limit) + 5: worse.append(f'{loc} time/frame {o["ms"]} -> {n["ms"]} ms')
    return worse

# ---------- test log ----------
def check_log(path):
    if not os.path.exists(path): return False, 'no test log'
    lines = open(path).read().splitlines()
    acts = [l for l in lines if ' ACTION ' in l]; und = [l for l in lines if ' UNDONE ' in l]
    return (len(acts) > 0 and len(und) >= len(acts)), f'{len(acts)} test actions, {len(und)} undone'


# ---------- drawing work, measured on the scenery itself (same result every run for the same file) ----------
STATIC_JS = r"""()=>{const out={};const add=(name,g)=>{if(!g)return;let meshes=0,tris=0;g.traverse(o=>{if(!(o.isMesh||o.isInstancedMesh||o.isSkinnedMesh))return;meshes++;
   const geo=o.geometry;if(!geo)return;const n=geo.index?geo.index.count:(geo.attributes&&geo.attributes.position?geo.attributes.position.count:0);tris+=(n/3)*(o.isInstancedMesh?o.count:1);});
   out[name]={meshes,tris:Math.round(tris)};};
 for(const id in LOC)add(id,LOC[id].g);add('outside (town scenery)',typeof outside!=='undefined'?outside:null);return out;}"""

async def weight_static(g):
    return await g.ev(STATIC_JS)

def compare_static(old, new, limit=0.10):
    worse = []
    for k, o in old.items():
        n = new.get(k)
        if not n: worse.append(f'{k}: missing'); continue
        for f in ('meshes', 'tris'):
            if o[f] and n[f] > o[f] * (1 + limit): worse.append(f'{k} {"pieces" if f == "meshes" else "triangles"} {o[f]} -> {n[f]}')
    return worse
