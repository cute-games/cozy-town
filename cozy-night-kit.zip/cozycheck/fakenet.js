/* Cozy Town check: runs inside TEST COPIES only, never in the real game.
   1) lets the check step the game loop itself (fast, no 1 fps wait)
   2) gives the GitHub version a fake Firebase, and the Claude version a fake room,
      both talking to the check's own in-memory "server" (window.__relay), so two
      test players can meet without touching the real shared world. */
(() => {
  const FLAVOR = window.__COZY_FLAVOR || 'web';
  const _raf = window.requestAnimationFrame.bind(window);
  const L = window.__loop = { manual: false, cb: null };
  window.requestAnimationFrame = function (cb) { if (L.manual) { L.cb = cb; return 1; } return _raf(cb); };

  const send = (o) => (window.__relay ? window.__relay(JSON.stringify(o)) : Promise.resolve());
  const listeners = {};
  const copy = (v) => (v === undefined || v === null) ? null : JSON.parse(JSON.stringify(v));
  const snap = (v) => ({ val: () => copy(v), exists: () => v != null });
  window.__relayPush = (path, val) => {
    const S = listeners[path];
    if (S) for (const cb of [...S]) { try { cb(snap(val)); } catch (e) { console.error(e); } }
  };
  const norm = (p) => String(p).replace(/^\/+|\/+$/g, '');
  function ref(p) {
    p = norm(p);
    return {
      key: p.split('/').pop(),
      child: (k) => ref(p + '/' + k),
      set: (v) => send({ op: 'set', path: p, val: v }),
      update: (d) => send({ op: 'update', path: p, val: d }),
      remove: () => send({ op: 'remove', path: p }),
      onDisconnect: () => ({ remove: () => send({ op: 'ondisc', path: p }) }),
      on: (ev, cb) => {
        (listeners[p] = listeners[p] || new Set()).add(cb);
        if (p === '.info/serverTimeOffset') { setTimeout(() => cb(snap(0)), 0); return cb; }
        if (p === '.info/connected') { setTimeout(() => cb(snap(true)), 0); return cb; }
        send({ op: 'listen', path: p });
        return cb;
      },
      off: (ev, cb) => { const S = listeners[p]; if (S) { if (cb) S.delete(cb); else S.clear(); } },
    };
  }

  if (FLAVOR === 'web') {
    const TS = { '.sv': 'timestamp' };
    const db = { ref };
    const database = function () { return db; };
    database.ServerValue = { TIMESTAMP: TS };
    const app = { name: '[DEFAULT]', options: {} };
    const FAKE = {
      apps: [], SDK_VERSION: 'cozycheck-fake',
      initializeApp() { if (!FAKE.apps.length) FAKE.apps.push(app); return app; },
      app() { return app; }, database,
    };
    const NOOP = new Proxy(function () {}, {
      get: (t, k) => (k === Symbol.toPrimitive ? () => '' : NOOP), apply: () => NOOP, construct: () => NOOP,
    });
    const FB = new Proxy(FAKE, { get(t, k) { return (k in t) ? t[k] : NOOP; } });
    Object.defineProperty(window, 'firebase', { configurable: true, get() { return FB; }, set(v) { window.__realFirebaseIgnored = true; } });
  } else {
    const me = 'c' + Math.random().toString(36).slice(2, 10);
    function group(world) {
      const base = 'rooms/' + world, mine = base + '/' + me;
      let cb = null, prev = new Set(), dead = false;
      const onVal = (s) => {
        if (dead || !cb) return;
        const v = s.val() || {}, peers = [], ids = new Set();
        for (const id in v) { ids.add(id); peers.push({ peer: id, presence: v[id], isMe: id === me, sameTab: id === me }); }
        const left = []; for (const id of prev) if (!ids.has(id)) left.push({ peer: id });
        prev = ids; try { cb({ peers, left }); } catch (e) { console.error(e); }
      };
      ref(base).on('value', onVal);
      send({ op: 'ondisc', path: mine });
      return {
        onPeers(f) { cb = f; setTimeout(() => send({ op: 'listen', path: base }), 0); return () => { dead = true; ref(base).off('value', onVal); send({ op: 'remove', path: mine }); }; },
        presence(st) { return send({ op: 'update', path: mine, val: st }); },
        emit() { return Promise.resolve(); }, on() { return () => {}; },
        leave() { return send({ op: 'remove', path: mine }); },
      };
    }
    const ROOM = { join: async (w) => group(String(w)) };
    window.claude = { use: (name) => Promise.resolve(name === 'room' ? ROOM : null) };
  }
})();
