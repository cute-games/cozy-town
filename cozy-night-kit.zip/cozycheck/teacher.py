"""Teacher job play-through (real taps on touch devices, keys and mouse on PC). Records what happened at each step."""
import asyncio, json, math, time
from crawl import Crawler, INSTR

KIDS_JS = r"""()=>{const C=CUT;if(!C||!C.tch)return null;const r=renderer.domElement.getBoundingClientRect(),v=new THREE.Vector3();
  return {stage:C.stage,caught:C.caught||0,kids:C.kids.map(k=>{v.set(0,1.0,0);k.p.root.localToWorld(v);v.project(camera);
    return {nm:k.nm,goof:!!k.goof,x:r.left+(v.x+1)/2*r.width,y:r.top+(1-v.y)/2*r.height,warn:k.warn};})};}"""

PAPER_JS = r"""()=>{const C=CUT;if(!C||!C.tch||!UI.open)return null;const k=C.kids[C.pi];
  const btn=[...document.querySelectorAll('#card [data-a^="tmk:"]')].map(b=>{const r=b.getBoundingClientRect();return {a:b.dataset.a,w:Math.round(r.width),h:Math.round(r.height),x:Math.round(r.left),y:Math.round(r.top)};});
  const txt=[...document.querySelectorAll('#card .tq *')].filter(e=>!e.children.length&&e.textContent.trim()&&!e.closest('button')).map(e=>{const cs=getComputedStyle(e);return {t:e.textContent.trim().slice(0,30),c:cs.color,fs:cs.fontSize,fw:cs.fontWeight};});
  const qtext=[...document.querySelectorAll('#card .tq')].map(q=>{let best=null;for(const e of q.querySelectorAll('*')){if(e.closest('button'))continue;if([...e.childNodes].some(n=>n.nodeType===3&&n.textContent.trim().length>2)){best=e;break;}}
    if(!best)return null;const cs=getComputedStyle(best);return {t:best.textContent.trim().slice(0,40),c:cs.color,fs:cs.fontSize,fw:cs.fontWeight};}).filter(Boolean);
  return {pi:C.pi,n:C.kids.length,ask:!!C.ask,right:k.hw.map(q=>q.ans===q.a),mk:k.mk.slice(),btn,txt:txt.slice(0,8),qtext,acts:[...document.querySelectorAll('#card [data-a]')].map(b=>b.dataset.a)};}"""

def contrast(c1, c2='rgb(255, 254, 246)'):
    def rgb(c): return [float(x) for x in c[c.index('(') + 1:c.index(')')].split(',')[:3]]
    def L(c):
        v = [x / 255 for x in rgb(c)]; v = [x / 12.92 if x <= 0.03928 else ((x + 0.055) / 1.055) ** 2.4 for x in v]
        return 0.2126 * v[0] + 0.7152 * v[1] + 0.0722 * v[2]
    a, b = L(c1), L(c2); return round((max(a, b) + 0.05) / (min(a, b) + 0.05), 2)

async def intro_as_teacher(g, name):
    """The opening, picking the teacher job on Rosie's job question (real taps)."""
    for _ in range(60):
        st = await g.ev("""()=>({title:!$('title').hidden,panel:!$('panel').hidden,cr:!!CR,playing:PLAYING,intro:!!(S&&S.intro),crName:!!$('crName'),
          acts:[...document.querySelectorAll('#card [data-a]')].filter(b=>b.offsetParent).map(b=>b.dataset.a),tut:!$('tut').hidden,dtut:!$('dtut').hidden})""")
        if st['playing'] and st['intro'] and not st['panel'] and not st['cr'] and not st['tut'] and not st['dtut']: return True
        if st['title']: await g.tap('#tPlay'); await g.wait(1500); await g.step(5); continue
        if st['tut']: await g.tap('#tutSkip'); await g.step(3); continue
        if st['dtut']: await g.tap('#dtSkip'); await g.step(3); continue
        if st['panel']:
            if st['crName'] and not await g.ev("()=>$('crName').value"):
                await g.tap('#crName'); await g.page.keyboard.type(name); await g.step(1)
            job = next((a for a in st['acts'] if a.startswith('job:') and 'teach' in a), None)
            pick = job or next((a for o in ('crdone', 'iname', 'inext', 'imake', 'tutgo', 'close') for a in st['acts'] if a == o), None)
            if pick:
                if job: await g.shot('teacher-job-choice', both=True)
                await g.tap(f'#card [data-a="{pick}"]'); await g.wait(700); await g.step(8); continue
        await g.wait(400); await g.step(6)
    return False

async def one_class(g, cr, n, log, out, variant):
    """Play one whole class. variant: which extra buttons to try on the homework papers."""
    rep = {'class': n}
    # 1) wait for the school's message
    for _ in range(90):
        await g.step(20)
        if await g.ev("()=>!$('note').hidden"):
            await g.shot(f'class{n}-school-message', both=True); await g.tap('#note'); await g.step(3)
        if await g.ev("()=>!!(S.tc&&S.tc.o)"): break
    o = await g.ev("()=>S.tc&&S.tc.o?{subj:S.tc.o.subj,name:SUBJ[S.tc.o.subj].n}:null")
    if not o: rep['problem'] = 'no message from the school came'; return rep
    rep['subject'] = o['name']
    # 2) the hallway, then the right classroom door with a real tap
    await g.ev("()=>__goto('school')"); await cr.settle(3, 300)
    ts = await cr.targets()
    door = next((t for t in ts if o['name'].lower() in t['label'].lower() and t['when']), None)
    rep['door_label'] = door['label'] if door else None
    if not door: rep['problem'] = f'no door for the {o["name"]} room in the hallway: {[t["label"] for t in ts]}'; return rep
    if await cr.approach(door['i']) != 'ok': rep['problem'] = 'could not get to the classroom door'; return rep
    await cr.use_action(); await cr.settle(8, 900)
    rep['room'] = await g.ev("()=>CUR.id"); await g.shot(f'class{n}-classroom', both=True)
    # 3) the desk
    ts = await cr.targets()
    desk = next((t for t in ts if t['when'] and any(w in t['label'].lower() for w in ('desk', 'teach', 'lesson', 'class'))), None)
    rep['desk_label'] = desk['label'] if desk else None
    if not desk: rep['problem'] = f'no desk to sit at: {[t["label"] for t in ts]}'; return rep
    if await cr.approach(desk['i']) != 'ok': rep['problem'] = 'could not get to the desk'; return rep
    await cr.use_action(); await cr.settle(6, 600)
    if not await g.ev("()=>!!(CUT&&CUT.tch)"): rep['problem'] = 'sitting at the desk did not start the lesson'; return rep
    # 4) the lesson: tap every kid who goofs off, wherever they sit
    taps = []; shot_lesson = False; t0 = time.time()
    while time.time() - t0 < 240:
        k = await g.ev(KIDS_JS)
        if not k or k['stage'] != 'lesson':
            if k and k['stage'] in ('intro', 'start', 'sit'): await g.step(10); continue
            break
        goof = [x for x in k['kids'] if x['goof']]
        if goof and not shot_lesson: await g.shot(f'class{n}-lesson-goofing', both=True); shot_lesson = True
        if not goof: await g.step(10); continue
        kid = goof[0]; before = k['caught']                     # always the newest position, like a player looking at the screen
        await g.tap_xy(kid['x'], kid['y']); await g.step(2)
        k2 = await g.ev(KIDS_JS)
        ok = bool(k2 and k2['caught'] > before)
        still = bool(k2 and any(x['nm'] == kid['nm'] and x['goof'] for x in k2['kids']))
        if not ok and not still: continue   # the kid stopped goofing by itself just then: not a miss
        if not ok:   # a player taps again when the first tap catches the kid mid-move: one more tap at the newest position
            k3 = await g.ev(KIDS_JS); again = next((x for x in (k3 or {}).get('kids', []) if x['nm'] == kid['nm'] and x['goof']), None)
            if again:
                b3 = k3['caught']; await g.tap_xy(again['x'], again['y']); await g.step(2); k2 = await g.ev(KIDS_JS); ok = bool(k2 and k2['caught'] > b3)
                still = bool(k2 and any(x['nm'] == kid['nm'] and x['goof'] for x in k2['kids']))
                if not ok and not still: continue
        why = None
        if not ok:
            why = await g.ev("""([x,y])=>{const el=document.elementFromPoint(x,y);const C=CUT;const r=renderer.domElement.getBoundingClientRect(),v=new THREE.Vector3();
              let best=null,bd=1e9;for(const k of C.kids){v.set(0,1.0,0);k.p.root.localToWorld(v);v.project(camera);const sx=r.left+(v.x+1)/2*r.width,sy=r.top+(1-v.y)/2*r.height,d=Math.hypot(sx-x,sy-y);if(d<bd){bd=d;best=k.nm;}}
              return {on_top:el?(el.id||el.className||el.tagName):'none',nearest:best,dist:Math.round(bd),stage:C.stage};}""", [kid['x'], kid['y']])
        side = 'left' if kid['x'] < g.p['w'] * 0.42 else 'right'
        taps.append({'kid': kid['nm'], 'side': side, 'x': round(kid['x']), 'y': round(kid['y']), 'stopped': ok, 'why': why})
        if not ok: await g.step(10)
    rep['goof_taps'] = taps
    rep['missed_left'] = sum(1 for t in taps if not t['stopped'] and t['side'] == 'left')
    rep['missed_right'] = sum(1 for t in taps if not t['stopped'] and t['side'] == 'right')
    # 5) homework papers: mark every answer with real taps; try the extra buttons on some papers
    for _ in range(80):
        if await g.ev("()=>!!(CUT&&CUT.tch&&UI.open&&document.querySelector('#card [data-a^=\"tmk:\"]'))"): break
        await g.step(10); await g.wait(100)
    papers = []; wrong_tried = False; extras = []
    for _ in range(12):
        pp = await g.ev(PAPER_JS)
        if not pp or not any(a.startswith('tmk:') for a in pp['acts']) and 'tnext' not in pp['acts']: break
        if pp['pi'] == 0 and not papers: await g.shot(f'class{n}-homework-paper', both=True)
        b2 = pp['btn'][:2]; gap = (b2[1]['x'] - (b2[0]['x'] + b2[0]['w'])) if len(b2) == 2 else None
        qd = []
        if pp['pi'] == 0:   # read the questions in dark mode too: the paper stays light, so the text must stay dark
            await g.page.emulate_media(color_scheme='dark'); pd = await g.ev(PAPER_JS); qd = (pd or {}).get('qtext', [])[:3]
            await g.page.emulate_media(color_scheme=g.theme)
        papers.append({'kid': pp['pi'], 'buttons': b2, 'gap': gap, 'text': pp['txt'][:4], 'qtext': pp['qtext'][:3] + qd})
        if variant == 'extras' and pp['pi'] == 0:
            for a in ('tkey', 'tkey'):
                if a in pp['acts']: r = await g.tap(f'#card [data-a="{a}"]'); await cr.settle(2, 200); extras.append(f'{a}:{r}')
        for i, right in enumerate(pp['right']):
            if pp['mk'][i]: continue
            if not wrong_tried:
                r = await g.tap(f'#card [data-a="tmk:{i}:{"x" if right else "ok"}"]'); await cr.settle(2, 250)
                hint = await g.ev("()=>!!document.querySelector('#card .thint')"); extras.append(f'wrong mark on purpose -> hint shown: {hint}'); wrong_tried = True
                if hint: await g.shot(f'class{n}-homework-hint', both=True)
            r = await g.tap(f'#card [data-a="tmk:{i}:{"ok" if right else "x"}"]'); await cr.settle(2, 250)
            if r != 'ok': extras.append(f'tmk:{i} tap {r}'); rep.setdefault('covered', []).append(f'paper {pp["pi"]} answer {i}: {r}')
        if variant == 'extras' and pp['pi'] == 1:
            for a in ('tgm', 'tgm', 'tback', 'tnext'):
                pa = await g.ev("()=>[...document.querySelectorAll('#card [data-a]')].map(b=>b.dataset.a)")
                if a in pa: r = await g.tap(f'#card [data-a="{a}"]'); await cr.settle(2, 250); extras.append(f'{a}:{r}')
        if variant == 'stop' and pp['pi'] == 1:
            for a in ('tstop', 'tstopn', 'tstop'):
                pa = await g.ev("()=>[...document.querySelectorAll('#card [data-a]')].map(b=>b.dataset.a)")
                if a in pa: r = await g.tap(f'#card [data-a="{a}"]'); await cr.settle(2, 250); extras.append(f'{a}:{r}')
            await g.shot(f'class{n}-stop-grading-question', both=True)
            r = await g.tap('#card [data-a="tstopy"]'); await cr.settle(4, 400); extras.append(f'tstopy:{r}'); break
        r = await g.tap('#card [data-a="tnext"]'); await cr.settle(3, 300)
        if r != 'ok': extras.append(f'tnext tap {r}'); break
    rep['papers'] = papers; rep['extras'] = extras
    # 6) the end of class
    for _ in range(40):
        if await g.ev("()=>!!document.querySelector('#card [data-a=\"tbye\"]')"): break
        await g.step(10); await g.wait(100)
    await g.shot(f'class{n}-summary', both=True)
    r = await g.tap('#card [data-a="tbye"]'); await cr.settle(4, 500)
    rep['ended'] = r == 'ok' and not await g.ev("()=>!!CUT")
    rep['pay'] = await g.ev("()=>S.coins")
    return rep

async def play_teacher(run, build, prof='ipad-landscape', theme='light', classes=3):
    g = await run.open(build, 'web', prof, theme, 'teacher'); await g.manual()
    out = {'device': prof, 'classes': []}
    out['intro_ok'] = await intro_as_teacher(g, 'ZZTEST-TEACH'); await g.ev(INSTR)
    out['job'] = await g.ev("()=>S.job")
    cr = Crawler(g, depth=0, per_label=1, budget_s=3600)
    variants = ['extras', 'plain', 'stop']
    for n in range(1, classes + 1):
        rep = await one_class(g, cr, n, run.log, out, variants[(n - 1) % 3])
        out['classes'].append(rep)
        if rep.get('problem'): break
        if await g.ev("()=>tc().done>=TC_MAX"):
            run.log.note('teacher test: moved the clock to the next morning by code so a third class can come')
            await g.ev("()=>{S.time=7.9;S.day++;newDay();change();}"); await g.step(10)
    out['errors'] = list(g.errors)
    await run.close(g)
    return out
