# Cozy Town: BIG NIGHT UPDATE (plan for the night session)

Work alone all night. Never ask questions, never stop. Important work: Claude Opus 5.5 at max effort.
The game is one file: index.html in this repo (the GitHub version = the game + a small web part with Firebase for playing together).
Keep family names out of this public repo.

## Start
1. Live version at the start must be update A: md5 e5097a1091c6c320a40af6c389b7f925. If index.html differs, read it and merge; never overwrite someone else's work.
2. Backup: git tag `prenight-big-update` on the starting commit, and keep a copy as tools/prenight-index.html.
   "Go back to PRENIGHT BIG UPDATE" = restore that file.
3. The check tools are in the cozycheck folder of cozy-night-kit.zip. Run cozycheck/cozy_check2.py (usage at the top of the file; it needs Playwright with Chromium; the folder carries three.js r128 and the Baloo 2 font, so test copies never need the internet).
4. Count what is in the game before and after (check line A3).

## Rules
- One job = one commit. If a job breaks something, undo only that job; the night continues.
- After each job: quick check (files, counts, saves, two players, plus the areas the job touched). At the end: the full check on the final version. If the full check fails, undo the job that caused it.
- Old saves must keep working (check B1). Never skipped.
- Make obvious decisions yourself. Unclear ones go on the morning list.
- Finished jobs only. A half-done job is undone, not shipped.

## Jobs, in this order (stop adding jobs when time runs short; the order is the priority)
1. Pets keep a gap: they stay a bit further away; standing still = they stay put ("stay"); walking further = they follow.
2. Trees don't pop in when you move. Then a time-boxed glitch sweep (things in walls, flicker, stuck spots); unfixed ones go on the list.
3. Football: looks like a real football (not spiky); tap = soft pass, hold = strong shot; aim arrow; glow when kickable; slightly bigger kick area; gentle auto-aim toward the goal on touch.
4. One clock for everyone (GitHub version): same time for all players; day 10 real minutes, night 5; the clock pauses when nobody plays (it travels with the players' saves, so no new Firebase settings); remove the "Always day" setting.
5. Sleeping together: beds work from 21:00, wake at 7:00, no pocket money; the night skips only when every active player is in bed; show "2 of 3 in bed"; a button rings the others' phones: "Friends want to skip the night, waiting on you!" (one ring per call, at most once a minute per player); a caller who calls too often sees "Friend is busy doing something. We can't sleep! 😢 Let's stay up ALL NIGHT! 🤪".
6. Away or offline: no tap, click or key for 3 minutes -> "Still there?" -> 30 s later, save and go to the title screen. Lost internet -> "Reconnecting..." for 20 s -> save, title screen: "Your internet connection was lost 😢". Inactive players don't count for "everyone in bed".
7. Pizza day: 12:00-21:00, closed Saturday and Sunday. Each player up to 3 a day; then the chef: "Right! That's enough. Chill for today!" Replies: "Yay! Chef, bye!" (done for today) or "PIZZAS MUST BE DELIVERED" -> "You absolute maniac! Fine! I'll bake THREE more. Three! And not ONE more!" (6 total); after the 6th: "That's it, see ya!". If 21:00 comes mid-shift, the order in hand may be finished, then "Today's done, great work! Ciao!". Chef stars raise pay per pizza: 0 stars pays less than every other job per day, 5 stars a little more than all of them; the 3 extra pizzas are on top. The pizza job never changes the clock.
8. Daytime activities: jobs and the pet show (Saturdays) happen in the daytime; shops 8:00-20:00.
9. Cozy nights: fewer walkers and cars, car head and tail lights as glow (not real lights, keep iPad smooth), still cozy.
10. Second floor in the big house: like the apartments (floor 1 > stair-step animation > floor 2); decorate upstairs; visiting friends can go upstairs; furniture quests count both floors.
11. Beach: first new place; opens when a skill is maxed. Old saves keep working. Designer's wishes: none yet, pick something cozy and sensible.
12. Tennis court (only after the beach works): good-looking court that feels good to play, with a coach nearby to play with.
13. Nicer buildings: before and after screenshots; the old look stays in the backup.
14. Suggestions board in the park: cozy wooden board on two legs next to an oak tree, cork board with pinned notes. Players write ideas; notes show right away; hide bad words, links, phone numbers and addresses. Everyone has 3 hearts, can move them, can put all 3 on one note. On Sundays the mayor (Rosie) reads the notes and thinks all day about what to build, mentioning the most-hearted idea the most. Notes are stored in Firebase: if the database refuses the write, build it, keep it hidden, and say in the morning which Firebase rule is needed.

## Not tonight
Firefighters, police, doctors; the rest of the bigger town; a private world; pizza for two players.

## Morning report (write tools/NIGHT-REPORT.md)
1. Every change: item, old -> new.
2. Check output per job, exactly as printed, and the final full check.
3. Before/after pictures of the buildings (tools/pictures/).
4. Glitches found and not fixed.
5. Everything NOT VERIFIED (how football feels, sound, real devices).
6. "Try it for real" tasks to play and tick off.
7. How to go back: restore tools/prenight-index.html.
The final game file: index.html at the tip of the night's commits. The owner uploads it to GitHub himself if it isn't pushed.
