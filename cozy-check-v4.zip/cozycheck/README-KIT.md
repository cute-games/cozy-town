# Cozy Town check kit - for Claude in a new chat (check version 4, kit updated 16 Oct 2026)
Since 9 Oct (the owner): GITHUB FIRST. Updates land in the GitHub repo cute-games/cozy-town (night runs in Claude Code, or a chat). The Claude version
(https://claude.ai/artifact/G7QNxp44zcJHkvSzZmRyk7) is an exact copy of the GitHub file without the online part, made right after each GitHub update.
An update is done only when both match. The online part = online-part.json: 8 lines at the top (manifest, icons, Home Screen meta, theme-color)
and 47 lines of Firebase scripts, as split on 7 Oct (update A). strip_online.py removes exactly those lines and stops if they are not found.
1. Artifact read this page (the "Cozy Town - final check" link in project memory). index.html lands in /mnt/user-data/outputs/artifacts/<slug>/.
2. Unpack:  python3 -c "import re,base64,io,zipfile;h=open('INDEX_HTML').read();b=re.search(r'id=\"kit\"[^>]*>([^<]+)<',h).group(1);zipfile.ZipFile(io.BytesIO(base64.b64decode(b))).extractall('/home/claude/kit/cozycheck')"
3. Newest live versions, read right before the check:
   curl -s https://raw.githubusercontent.com/cute-games/cozy-town/main/index.html -o /home/claude/kit/live/github-live.html
   python3 cozycheck/strip_online.py live/github-live.html live/claude-form-of-github-live.html      (this is --live-claude)
   Artifact read the Claude version -> live/claude-real.html. It must be the same file as live/claude-form-of-github-live.html.
   If it is not, find out why before going on: nothing may exist only in the Claude version (merge, never overwrite).
4. The new version: the new GitHub file (the pull request's branch tip, or the file to upload) -> new/github-new.html;
   python3 cozycheck/strip_online.py new/github-new.html new/claude-new.html      (this is --new-claude)
5. Before an update: publish a dated private backup artifact of the live GitHub file ("... backup YYYY-MM-DD (GitHub file, ...)"), read it back,
   pass it with --backup and --backup-title. A2 compares it with the live GitHub file.
6. Run (background; runs die between chat messages, so run the same command again to continue; finished stages are skipped):
   cd /home/claude/kit && setsid nohup python3 -u cozycheck/cozy_check2.py --live-claude live/claude-form-of-github-live.html --new-claude new/claude-new.html \
      --live-web live/github-live.html --backup BACKUP.html --backup-title "TITLE" --out /home/claude/kit/run --tag TAG [--full] > run.log 2>&1 < /dev/null &
   (poll: sleep 240; tail run.log). --full = the full sweep for big updates (decision 7 Oct): every screen on all 10 device sizes.
   Safari's engine (WebKit) is not installed in this container, so C1-WK stays NOT RUN; real iPads and iPhones cover it in the notebook.
   OUT/github-index.html (= new Claude file + the same online part) must be byte for byte new/github-new.html.
7. Paste the block from "===== COZY TOWN FINAL CHECK =====" to "RESULT:" exactly as printed.
8. After the GitHub update (the owner merges the pull request or uploads the file): back up the Claude version (dated private artifact, read back,
   same file as live/claude-real.html), publish new/claude-new.html to the Claude version, read it back; then run again with
   --published <Claude read-back> --github <raw GitHub fetch> to fill F2 and F3.
Night runs: this kit is in the repo as cozy-check-v4.zip (night 3 on). The old cozy-night-kit.zip (version 1) is history only.
In Claude Code there is no Artifact tool: the newest live version is the repo's main branch (git), and the private backup is made by a chat.
Setup notes: Playwright 1.56 + Chromium in /opt/pw-browsers. Container network allows npm/pypi/github only, so the kit carries
three.js r128 (npm three@0.128.0) and the Baloo 2 font (npm @fontsource/baloo-2). Test copies get a fake Firebase / fake room (fakenet.js).
Fixtures: cozycheck/fixtures/ holds saved games made by older versions (names start with ZZTEST); B1 loads them all in the new version.
Add a rich save made by each new live version.
B1 exception (the owner's OK, 9 Oct): a save that never had a player id ('pid') may get a new one. A save that has one must keep it exactly.
Changes in version 3 (9 Oct): stage 'book' with W1 (the What's new book: 9 pages, pictures, Next/Back/swipe/arrow keys/Escape/✕/tap outside/Let's play!, Next stays in place) and W2 ("Designed by Izabele 💗" on screen, clear of buttons and the version label) on iPad, iPhone upright and sideways, PC. When a new book replaces this one, change the page count in s_book.
Changes in version 2 (9 Oct): B1 player-id exception · A2 backs up the live GitHub file (GitHub first) · --full sweep option · strip_online.py,
online-part.json and the old test saves added to the kit.

Changes in version 4 (16 Oct): E1 can take agreed per-area limits: --e1-limits "city:0.35:0.60,beach:0.35:0.60" (owner's OK 16 Oct,
for night 3: the town and the beach may have up to 35% more pieces and 60% more triangles; every other area stays at 10%).
The limits used are printed on the E1 line. Without --e1-limits the check is exactly version 3.
